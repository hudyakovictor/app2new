# ARCHITECTURE.md — Полная архитектура пайплайна DEEPUTIN

> **ВАЖНО:** Этот файл — главный источник контекста для любого AI, работающего с проектом.
> Читайте его ПЕРВЫМ при начале работы.

---

## 1. Общая цель проекта

DEEPUTIN (deep + putin — игра слов) — форензик-пайплайн верификации личности по фотографиям.
Анализирует 1700+ фото В.В. Путина (1998–2026) с двойниками:
- **UDMURT** (2012–2021) — двойник в силиконовой маске
- **VAS** (2023–2026) — двойник в силиконовой маске

**Финальный вопрос пайплайна:** «Этот человек — Владимир Путин?»
**Гипотезы:**
- H0_SAME — один и тот же человек
- H1_SYNTHETIC — силиконовая маска на похожем черепе
- H2_DIFFERENT — разные люди (двойник)
- H_UNCERTAIN — данных недостаточно

---

## 2. Шесть стадий пайплайна

### Нaming convention: `s{N}_{name}`

| # | Имя | Назначение | НЕ делает |
|---|-----|-----------|-----------|
| **s1** | `extraction` | Извлечение данных (face, quality, pose, mesh) | Не решает кто на фото |
| **s2** | `metrics` | Сырые метрики (geometry + texture) | Не решает кто на фото |
| **s3** | `identity` | **Предварительное** предположение: PUT/UDMURT/VAS? real/silicone? | Не финальный вердикт! |
| **s4** | `compare` | Попарное сравнение + хронология + кластеры + аномалии | Не финальный вердикт! |
| **s5** | `verdict` | **ФИНАЛЬНЫЙ** вердикт: H0/H1/H2 (с учётом ВСЕХ данных) | — |
| **s6** | `report` | Отчёт, экспорт, визуализация | — |

**Ключевое правило:** s3_identity ≠ s5_verdict.
s3 — это ГИПОТЕЗА на основе ограниченных данных одного фото.
s5 — это ФИНАЛЬНОЕ решение на основе ВСЕХ evidence.

---

## 3. Структура папок

```
DEEPUTIN/
├── s1_extraction/
│   ├── modules/
│   │   ├── extract_face.py          ← детекция лица
│   │   ├── extract_quality.py       ← оценка качества по face_mask.png (НЕ по фото!)
│   │   ├── extract_pose.py          ← поза головы
│   │   ├── extract_reconstruction.py ← 3D-меш
│   │   ├── engine.py                ← главный движок
│   │   └── schemas.py               ← Pydantic-схемы
│   ├── configs/
│   │   ├── s1_config.yaml
│   │   └── quality_thresholds.yaml
│   ├── tests/
│   │   ├── test_extract_face.py
│   │   ├── test_extract_quality.py
│   │   └── fixtures/
│   └── test_ui/
│       ├── app.py
│       └── pages/
│
├── s2_metrics/
│   ├── modules/
│   │   ├── extract_geometry.py      ← геометрические метрики
│   │   ├── extract_texture.py       ← текстурные метрики (топ-20)
│   │   ├── extract_quality.py       ← метрики качества
│   │   ├── engine.py
│   │   └── schemas.py
│   ├── configs/
│   │   ├── s2_config.yaml
│   │   ├── geometry_metrics.yaml
│   │   ├── texture_metrics.yaml     ← топ-20 метрик кожи
│   │   └── quality_weights.yaml
│   ├── tests/
│   └── test_ui/
│
├── s3_identity/
│   ├── modules/
│   │   ├── detect_person.py         ← PUT/UDMURT/VAS (предварительно)
│   │   ├── classify_skin.py         ← real/silicone (предварительно)
│   │   ├── engine.py
│   │   └── schemas.py
│   ├── configs/
│   │   ├── s3_config.yaml
│   │   ├── identity_thresholds.yaml
│   │   └── skin_thresholds.yaml
│   ├── tests/
│   └── test_ui/
│
├── s4_compare/
│   ├── modules/
│   │   ├── pairwise_comparison.py  ← попарное сравнение
│   │   ├── chronological_tracker.py ← хронологическое отслеживание
│   │   ├── cluster_analyzer.py     ← кластерный анализ ("group of brothers")
│   │   ├── trend_detector.py       ← детекция тренда / change points
│   │   ├── anomaly_detector.py     ← детекция аномалий
│   │   ├── flag_propagator.py      ← передача флагов между фото
│   │   ├── anomaly_scorer.py       ← расчёт Anomaly Score
│   │   ├── engine.py
│   │   └── schemas.py
│   ├── configs/
│   │   ├── s4_config.yaml
│   │   ├── cluster_config.yaml
│   │   ├── trend_config.yaml
│   │   └── weights.yaml
│   ├── tests/
│   └── test_ui/
│
├── s5_verdict/
│   ├── modules/
│   │   ├── bayesian_engine.py      ← байесовский вывод
│   │   ├── chronology_analyzer.py  ← хронологический анализ
│   │   ├── anomaly_detector.py     ← финальная детекция аномалий
│   │   ├── engine.py
│   │   └── schemas.py
│   ├── configs/
│   │   ├── s5_config.yaml
│   │   ├── bayes_config.yaml
│   │   └── chronology_config.yaml
│   ├── tests/
│   └── test_ui/
│
├── s6_report/
│   ├── modules/
│   │   ├── report_generator.py
│   │   ├── export.py
│   │   ├── visualization.py
│   │   ├── engine.py
│   │   └── schemas.py
│   ├── configs/
│   │   └── s6_config.yaml
│   ├── tests/
│   └── test_ui/
│
├── shared/
│   ├── utils/
│   │   ├── io.py                   ← чтение/запись файлов
│   │   ├── logging.py              ← логирование
│   │   └── validation.py           ← валидация данных
│   └── configs/
│       └── pipeline.yaml           ← глобальные настройки
│
└── main_runner.py                  ← главный пульт управления
```

### Именование модулей

| Формат | Пример | Назначение |
|--------|--------|------------|
| `extract_{entity}.py` | `extract_face.py` | Извлечение данных |
| `detect_{entity}.py` | `detect_person.py` | Детекция |
| `classify_{entity}.py` | `classify_skin.py` | Классификация |
| `analyze_{entity}.py` | `analyze_quality.py` | Анализ |
| `compare_{entity}.py` | `compare_geometry.py` | Сравнение |
| `engine.py` | `engine.py` | Главный движок стадии |
| `schemas.py` | `schemas.py` | Pydantic-схемы данных |

---

## 4. Концепция «Персональный паспорт фото»

Каждое фото получает «паспорт» — набор данных, который тянется за ним через всю хронологию.

```
photo_2015_06_10:
  ├── photo_id: "main_2015_06_10"
  ├── date: "2015-06-10"
  ├── pose: "frontal"
  ├── epoch: "recent"
  │
  ├── Значения (из s2):
  │   ├── geometry: {cheekbone: 0.05, orbit: 0.0008, jaw: 0.004}
  │   └── texture: {wrinkles: 0.1, pores: 0.1}
  │
  ├── Качество (из s1):
  │   └── quality: 0.90
  │
  ├── Identity (из s3):
  │   ├── geometry_verdict: "DOUBLE"
  │   └── skin_verdict: "silicone"
  │
  ├── Флаги (из s4):
  │   ├── flags_from_prev: ["sudden_smoothing:high"]
  │   ├── flags_from_next: ["form_return:medium"]
  │   └── flags_from_history: ["match_2001_03_23:high"]
  │
  ├── Кластер (из s4):
  │   └── cluster: "frontal_UDMURT"
  │
  ├── История (из s4):
  │   ├── best_match_in_past: "photo_2001_03_23" (similarity: 0.92)
  │   └── worst_match_in_past: "photo_2020_05_15" (similarity: 0.45)
  │
  └── Anomaly Score: 1.75
```

### Уровни критичности флагов

| Уровень | Пример | Описание |
|---------|--------|----------|
| `low` | Поры чуть изменились | Могут быть артефакты |
| `medium` | Морщины появились за месяц | Подозрительно |
| `high` | Морщины исчезли за 3 дня | Очень подозрительно |
| `critical` | Кости изменились за неделю | Биологически невозможно |

### Типа флагов

| Тип | Источник | Интерпретация |
|-----|----------|---------------|
| `flags_from_prev` | Сравнение с предыдущим фото | «Фото отличается от предыдущего» |
| `flags_from_next` | Сравнение со следующим фото | «Фото отличается от следующего» |
| `flags_from_history` | Сравнение с историческими фото | «Фото =/≠ фото из прошлого» |

### Anomaly Score

```
Anomaly Score = sum(flag.severity for all flags)

low      = 0.1
medium   = 0.3
high     = 0.7
critical = 1.0

Пример:
  flags: ["sudden_smoothing:high", "form_return:medium"]
  score: 0.7 + 0.3 = 1.0
```

---

## 5. Концепция «Группа братьев» (кластерный анализ)

### Принцип

Каждое фото входит в «группу братьев» — фото с похожими ракурсами и значениями.
Кластеры НЕ задаются заранее — они ВЫЯВЛЯЮТСЯ из данных по линии графика.

### Визуальный кластерный анализ (без явной кластеризации)

```
cheekbone_R (frontal) по хронологии:

0.25 │
     │    ●────●────●────●────●
0.20 │    PUT (естественное старение — наклон вниз)
     │         ╲
0.15 │          ╲
     │           ╲  ← CHANGE POINT!
0.10 │            ╲
     │             ●
0.05 │─────────────●────●────●────●
     │             UDMURT (стабильно, маска — плато)
0.00 │
     └──────────────────────────────────────────
     2001  2003  2005  2007  2009  2012  2015  2018
```

### Что мы видим

| Элемент на графике | Интерпретация |
|---------------------|---------------|
| **Плато** (горизонтальная линия) | Один и тот же человек (стабильные значения) |
| **Скачек** (резкий переход между уровнями) | Смена человека (PUT → UDMURT или наоборот) |
| **Наклон** (плавное изменение) | Естественное старение (PUT) |
| **Плоская линия без наклона** | Маска (UDMURT/VAS) |

### Алгоритм определения уровней

```python
def detect_levels(photos_sorted_by_date, metric_name):
    """Определить уровни (кластеры) по линии графика"""

    values = [p.values[metric_name] for p in photos_sorted_by_date]
    dates = [p.date for p in photos_sorted_by_date]

    # 1. Найти точки изменения (change points)
    change_points = find_change_points(values)

    # 2. Определить уровни между точками изменения
    levels = []
    for i in range(len(change_points) - 1):
        start = change_points[i]
        end = change_points[i + 1]
        level_values = values[start:end]
        level = {
            "start_date": dates[start],
            "end_date": dates[end],
            "mean": np.mean(level_values),
            "std": np.std(level_values),
            "is_stable": np.std(level_values) < 0.02,
            "photos_count": end - start
        }
        levels.append(level)

    return levels
```

### Правила определения класса по уровню

```python
def classify_by_level(photo, levels):
    """Определить класс фото по уровню на графике"""

    for level in levels:
        if level.start_date <= photo.date <= level.end_date:
            if level.is_stable and level.mean < 0.1:
                return "DOUBLE"   # UDMURT/VAS (стабильный низкий уровень)
            elif not level.is_stable or level.mean > 0.15:
                return "PUT"      # (наклон или высокий уровень)
    return "UNCERTAIN"
```

---

## 6. Хронологическое отслеживание и передача флагов

### Flow обработки

```
Сортируем все фото по дате: A → B → C → D → E

Проход 1 (хронологически, A → E):
  Для каждого фото:
    1. Сравниваем с предыдущим фото → flags_from_prev
    2. Ищем лучшее совпадение в истории → best_match_in_past
    3. Определяем кластер → cluster

Проход 2 (обратно, E → A):
  Для каждого фото:
    1. Сравниваем со следующим фото → flags_from_next
```

### Правила начисления флагов

```python
def compute_flags(prev_photo, current_photo, delta_days):
    flags = []

    # Если предыдущее фото уже с флагами → усиливаем
    if prev_photo.flags:
        severity_boost = get_max_severity(prev_photo.flags)
        flags.append(f"continues_anomaly:{severity_boost}")

    # Проверяем изменения
    delta_values = compute_delta(prev_photo.values, current_photo.values)

    # Костные изменения
    if delta_values["cheekbone"] > threshold:
        if delta_days < 30:
            flags.append("impossible_change:critical")
        elif delta_days < 365:
            flags.append("bone_change:high")
        else:
            flags.append("bone_change:medium")

    # Текстурные изменения
    if delta_values["wrinkles"] > threshold:
        if delta_days < 7:
            flags.append("sudden_smoothing:critical")
        elif delta_days < 90:
            flags.append("sudden_smoothing:high")
        else:
            flags.append("sudden_smoothing:medium")

    return flags
```

### Типы аномалий

| Тип | Пример | Флаг |
|-----|--------|------|
| Резкое сглаживание | Морщины 0.3 → 0.1 за 3 дня | `sudden_smoothing` |
| Резкое появление | Поры 0.1 → 0.4 за 3 дня | `sudden_appearance` |
| Нарушение тренда | Значения шли по линии, потом резко сдвинулись | `aging_break` |
| Возврат к форме | Значения вернулись к тому, что были раньше | `form_return` |
| Невозможные изменения | Костные структуры изменились так, как невозможно | `impossible_change` |
| Чередование лиц | То PUT, то UDMURT, то опять PUT | `face_switching` |

---

## 7. Двухрежимный test_ui

### Принцип

Каждая стадия имеет test_ui с двумя режимами:

```
┌─────────────────────────────────────────────────────────────────┐
│  test_ui:                                                      │
│  Режим: [🔧 Калибровка] [▶️ Верификация]                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [🔧 КАЛИБРОВКА]                                                │
│  • Загружаем ТЕСТОВЫЕ данные (заранее подготовленные)           │
│  • Двигаем ползунки порогов                                     │
│  • Видим как меняется точность                                  │
│  • Сохраняем конфиг                                             │
│  • НЕ записываем в production                                   │
│                                                                 │
│  [▶️ ВЕРИФИКАЦИЯ]                                                │
│  • Загружаем РЕАЛЬНЫЕ данные из предыдущей стадии               │
│  • Прогоняем через текущую стадию                               │
│  • Видим результаты                                             │
│  • НЕ записываем в production (только проверка)                 │
│  • Если всё ок → отмечаем стадию как "ready"                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Flow калибровки

```
1. Запускаешь test_ui для s3_identity
2. Выбираешь режим "Калибровка"
3. Видишь тестовые данные (PUT/UDMURT/VAS)
4. Двигаешь ползунки порогов
5. Видишь как меняется точность
6. Нажимаешь "Сохранить"
7. Конфиг s3_identity/configs/identity_thresholds.yaml обновляется
```

### Flow верификации

```
1. Запускаешь test_ui для s3_identity
2. Выбираешь режим "Верификация"
3. Загружаешь реальные данные из s2_metrics
4. Прогоняешь через s3_identity
5. Видишь: 85 PUT, 10 UDMURT, 5 VAS
6. Видишь: аномалии (PUT с silicone кожей?)
7. НЕ записываешь в production
8. Если всё логично → отмечаешь s3 как "ready"
```

---

## 8. Resumable Pipeline

### Принцип

Pipeline можно остановить на любой стадии и запустить с любого места.
Предыдущие стадии НЕ перезапускаются.

### Каждая стадия логирует checkpoint

```
s1_extraction/checkpoint.json:
{
  "status": "completed",
  "processed": 1712,
  "failed": 3,
  "output_dir": "storage/s1_output/",
  "timestamp": "2026-07-07T12:00:00Z"
}
```

### main_runner.py

```bash
# Полный запуск
python main_runner.py

# Запуск с конкретной стадии
python main_runner.py --from-stage 3

# Запуск только конкретной стадии
python main_runner.py --stage 3 --only

# Запуск на малом датасете (для отладки)
python main_runner.py --from-stage 3 --batch-size 10

# Запуск на одном фото
python main_runner.py --from-stage 3 --photo main_2001_03_23

# Проверка checkpoint
python main_runner.py --status

# Сброс checkpoint (пересчёт)
python main_runner.py --reset-stage 3
```

### Логирование на каждой стадии

```
[Stage 3] Processing photo: main_2001_03_23.jpg
  Expected: geometry_verdict=PUT, skin_verdict=real
  Actual:   geometry_verdict=PUT, skin_verdict=real ✅
  Time: 0.23s
  Memory: 128MB

[Stage 3] Processing photo: main_2015_06_10.jpg
  Expected: geometry_verdict=PUT, skin_verdict=real
  Actual:   geometry_verdict=DOUBLE, skin_verdict=silicone ⚠️
  Flag: sudden_smoothing:high
  Time: 0.31s
  Memory: 132MB
```

---

## 9. Калибровочные данные

### Текстура (skin verdict)

- **Датасет:** 50 Real Skin + 41 Silicone Mask = 91 фото
- **Метод:** Quality-Compensated Shift Verdict Model
- **Топ-20 метрик:** из unified_test/clean_feature_leaderboard.csv
- **AUC:** 0.9912, LOO-CV accuracy: 96.70%
- **Стресс-тест:** 100% accuracy на всех 16 условиях (noise/blur/combo)
- **Скрипт:** stage3_texture_prep/scripts/quality_compensated_verdict.py
- **Скрипт:** stage3_texture_prep/scripts/build_texture_reference.py

### Геометрия (identity verdict)

- **Датасет:** PUT (1912 фото), UDMURT (2012–2021), VAS (2023–2026)
- **Метод:** 3-tier identity discriminator (PUT vs UDMURT vs VAS)
- **Топ-10 метрик:** из stage3_geomety_info/geometry_leaderboard_top10.csv
- **Минимальный набор (3 метрики → 99.99%):**
  - cheekbone_R_normal_mean_y > 0.048 → DOUBLE
  - orbit_R_bbox_volume_ratio < 0.001 → NOT_PUT
  - chin_normal_mean_x > 0.016 → VAS
- **Cohen's d:** до 5.35
- **Скрипт:** stage3_geomety_info/scripts/identity_discrimination_verdict.py

### Веса evidence (конфигурируемые)

```yaml
# shared/configs/weights.yaml
evidence_weights:
  chronological: 1.0    # сравнение с предыдущим фото
  cluster: 0.7          # сравнение с кластером
  historical: 0.5       # сравнение с историей

channel_weights:
  geometry: 0.7
  texture: 0.3
  chronology: 0.5
```

---

## 10. Ключевые конфиги

### s3_identity/configs/identity_thresholds.yaml

```yaml
identity:
  put_vs_double:
    cheekbone_R_threshold: 0.048    # Cohen's d = 5.35, accuracy = 99.9%
    orbit_R_threshold: 0.001        # accuracy = 96.0%
    jaw_L_threshold: 0.005          # accuracy = 93.5%

  udmurt_vs_vas:
    chin_x_vas_threshold: 0.016     # accuracy = 75.4%
    chin_x_udm_threshold: 0.007     # accuracy = 70.9%
    jaw_R_udm_threshold: 0.033      # accuracy = 84.4%
```

### s3_identity/configs/skin_thresholds.yaml

```yaml
skin:
  hf_discount_threshold: 0.6   # ниже — дисконтируем HF-метрики
  hf_zero_threshold: 0.4       # ниже — обнуляем HF-метрики
  min_confidence: 0.3          # ниже — uncertain
  silicone_threshold: 0.65     # выше — silicone
  real_threshold: 0.35         # ниже — real
```

### s4_compare/configs/cluster_config.yaml

```yaml
cluster:
  enabled: true
  comparison_method: "trend"   # centroid / nearest / trend
  similarity_threshold: 0.8
  trend_break_threshold: 0.1
  weights:
    chronological: 1.0
    cluster: 0.7
    historical: 0.5
```

---

## 11. Flow данных

```
s1_extraction  →  face_detection, quality, pose, reconstruction
        ↓
s2_metrics     →  geometry_metrics (zone morphometry) + texture_metrics (топ-20)
        ↓
s3_identity    →  предположительно: PUT/UDMURT/VAS? real/silicone?
        ↓
s4_compare     →  попарное сравнение + хронология + кластеры + аномалии
        ↓
s5_verdict     →  ФИНАЛЬНО: H0_SAME / H1_SYNTHETIC / H2_DIFFERENT
        ↓
s6_report      →  отчёт, экспорт, визуализация
```

### Связь между стадиями

```
s1 → s2: face_mask.png, info.json (quality, pose, reconstruction)
s2 → s3: metrics.csv (geometry + texture values)
s3 → s4: identity_verdict.json (PUT/UDMURT/VAS + real/silicone)
s4 → s5: evidence.json (pairwise + flags + cluster + anomalies)
s5 → s6: verdict.json (H0/H1/H2 + confidence + evidence chain)
```

---

## 12. История решений

| Дата | Решение | Причина |
|------|---------|---------|
| 2026-07-07 | identity ≠ verdict | s3 — гипотеза, s5 — финальное решение |
| 2026-07-07 | Качество = по face_mask.png, не по фото | Нас интересует качество кожи, а не фона |
| 2026-07-07 | Веса evidence конфигурируемые | Разные сценарии требуют разных весов |
| 2026-07-07 | Cluster без явной кластеризации | Визуальный анализ по линии графика |
| 2026-07-07 | Двухрежимный test_ui | Калибровка + верификация отдельно |
| 2026-07-07 | Resumable pipeline | Остановка + запуск с любой стадии |
| 2026-07-07 | Флаги с уровнями критичности | low/medium/high/critical |
| 2026-07-07 | 3 типа флагов | from_prev, from_next, from_history |

---

*Последнее обновление: 2026-07-07*
*Создано в ходе обсуждения архитектуры пайплайна NEWWAP*
