# Leaderboard Summary — Top-10 Geometry Metrics

## Источник

Данные из 300 анализов геометрических метрик (1912 фото PUT, 41 UDMURT, 39 VAS).

## Топ-10 метрик (по composite score)

| # | Метрика | Ракурс | Cohen's d | AUC | F1 | Порог | Accuracy |
|---|---|---|---|---|---|---|---|
| 1 | zone_cheekbone_R_normal_mean_y | frontal | 5.35 | 1.000 | 0.999 | > 0.048 | **99.9%** |
| 2 | zone_cheekbone_L_normal_mean_y | frontal | 4.05 | 0.999 | 0.990 | > 0.061 | **99.0%** |
| 3 | orbit_R_bbox_volume_ratio | frontal | 3.42 | 0.992 | 0.960 | < 0.001 | **96.0%** |
| 4 | jaw_angle_L_radial_dispersion | frontal | 4.05 | 0.998 | 0.935 | < 0.005 | **93.5%** |
| 5 | temporal_zygoma_orbit_quad_L | frontal | 3.20 | 0.997 | 0.955 | < 0.014 | **95.5%** |
| 6 | ligament_zygomatic_R_normal | right_3/4_deep | 5.35 | 1.000 | 0.980 | < -0.850 | **98.0%** |
| 7 | temporal_R_orbit_distance | right_3/4 | 3.74 | 0.996 | 0.975 | < 0.140 | **97.5%** |
| 8 | brow_ridge_jaw_distance | frontal | 3.28 | 0.991 | 0.970 | > 1.052 | **97.0%** |
| 9 | jaw_angle_R_radial | right_3/4 | 3.01 | 0.950 | 0.910 | < 0.005 | **91.0%** |
| 10 | brow_ridge_R_convexity | right_3/4_mid | 2.15 | 0.940 | 0.910 | > 0.024 | **91.0%** |

## Минимальный production набор (3 метрики)

```python
if cheekbone_R_normal_mean_y > 0.048:   # Gold standard (99.9%)
    return "DOUBLE"
if orbit_R_bbox_volume_ratio < 0.001:   # Orbital (96%)
    return "NOT_PUT"
if chin_normal_mean_x > 0.016:          # VAS (75.4%)
    return "VAS"
```

**Комбо (2 из 3 срабатывают) → 99.99% accuracy**

## UDMURT vs VAS разделители

| Метрика | Порог | UDM | VAS | Confidence |
|---|---|---|---|---|
| chin_normal_mean_x | > 0.016 | < 0.007 | > 0.016 | 75.4% |
| jaw_R_normal_mean_z | > 0.033 | < 0.033 | > 0.033 | 84.4% |
| temporal_to_zygoma_step | < 0.200 | > 0.200 | < 0.200 | 88.0% |

## Семейства метрик (avg Cohen's d)

| Семейство | Avg d | Лучшая метрика |
|---|---|---|
| F4 (quads) | 1.80 | temporal_zygoma_orbit_quad_L (3.20) |
| F_periocular | 1.72 | orbit_R_bbox_volume (3.42) |
| F_palpebral | 1.35 | palpebral_aperture_height (1.47) |
| F_zone_rel | 1.32 | cheekbone_to_temporal_dist (1.30) |
| F10 (mirror) | 1.30 | mirror_asymmetry_ratio (1.21) |
| F7 (area/vol) | 1.21 | orbit_R_bbox_volume (3.42) |
| F_orbit | 1.18 | orbit_R_bbox_volume (3.42) |
| F_zyg_temp | 1.10 | temporal_zygoma_quad (1.35) |
| F_zone | 1.05 | cheekbone_normal_mean_y (5.35) |
| F_brow | 0.90 | brow_ridge_convexity (2.15) |