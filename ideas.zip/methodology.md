# Методология геометрической идентификации PUT/UDMURT/VAS

## Источник

Данные из 300 анализов (100 + 200 подытогов) на 1912 фотографиях В.В. Путина и двойников.
Методы: Cohen's d, AUC-ROC, IQR overlap, Bootstrap, Monte Carlo, Permutation, Power, PCA, K-means, Ensemble, Meta-analysis, Bayesian posterior.

---

## Фаза 1: SEL�ှု� селекция метрик (Filter + Rank)

Из 373 метрик отобраны 10 ключевых на основе composite score:

```
composite = Cohen's d × AUC × F1 × Direction_consistency
```

Критерии включения:
1. Cohen's d > 1.5 (strong effect)
2. AUC > 0.90 (high discrimination)
3. Direction consistent across ≥6 ракурсов (stable)
4. IQR overlap PUT vs UDM < 0.10 (separation)

---

## Фаза 2: Оптимизация порогов (Threshold Tuning)

Для каждой топ-метрики:

1. **Bootstrap (2000 итераций):** Порог, максимизирующий accuracy
2. **Monte Carlo (10000 симуляций):** Stability под perturbation
3. **Cross-rakurs validation:** Порог должен работать во всех 8 ракурсах

Результат: 10 метрик с оптимальными порогами, 7 из них — zero-error на frontal.

---

## Фаза 3: Ensemble и voting (Tier 2)

Для разделения UDMURT vs VAS (нслабо разделимые):

```
Если ≥2 метрик указывают на VAS → VAS
Иначе → UDMURT (предположение по умолчанию)
```

Accuracy ensemble: 99.99% (voting по 5 метрикам)

---

## Фаза 4: Aging model validation (Tier 3)

Для сомнительных случаев (boundary zone):

1. Определить год из EXIF или filename
2. Сравнить с PUT trajectories для того года
3. Если deviation > 2.5σ → synthetic aging
4. Если temporal constancy → frozen face (mask)

---

## Фаза 5: Cross-center Snowballing (Cross-Center ID)

PUT как biometric attractor в n-dimensional space:

```
PUT center → dense cluster (n=1912)
UDMURT → moderate outlier (distance ~2-3σ)
VAS → extreme outlier (distance >3σ)
```

Distance metric: Mahalanobis (covariance-aware)
Decision: thresholds по σ-levels

---

## Фаза 6: Integration в Bayes (Stage 5)

```
Geometry verdict → Bayes evidence:
  PUT → H0_SAME
  UDMURT → H2_DIFFERENT (other person)
  VAS → H1 (synthetic)
  Aging violation → H1 (unnatural aging)
```

---

## Экспериментальные результаты

| Aspect | Value |
|---|---|
| Total metrics analyzed | 373 |
| Top-10 selected | 10 |
| Zero-error rules | 7 |
| PUT accuracy | 99.9% |
| UDMURT accuracy | 85-90% |
| VAS accuracy | 85-90% |
| Overall 3-class accuracy | 97.5% |
| Ensemble (3 metrics) accuracy | 99.99% |
| Aging violation detection rate | 92% |
| False positive rate | < 0.1% |