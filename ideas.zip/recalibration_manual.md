# Руководство по калибровке геометрического engine (PUT/UDMURT/VAS)

## Когда перекалибровать

- Точность на новом датасете < 0.95
- False positive > 0.5%
- PUT accuracy < 0.98 (golden standard)
- UDMURT/VAS confusion > 15%

## Быстрый diagnostic (5 минут)

```bash
# 1. Запустить diagnostic
python scripts/diagnostic.py \
    --reference reference_geometry.json \
    --test-data /path/to/new_metrics.csv \
    --output diagnostic_report.json
```

Проверить:
- PUT accuracy
- UDMURT/VAS confusion matrix
- aging violation false positive rate

## Перекалибровка thresholds

### Шаг 1: Пересборка reference

```bash
python scripts/build_geometry_reference.py \
    --calibration-dir /path/to/calibration \
    --evidence-table METRIC_EVIDENCE_TABLE.csv \
    --output reference_geometry_new.json
```

### Шаг 2: Ручная настройка порогов

Если PUT accuracy < 0.98 — вероятно, пороги слишком "входящие" для DOUBLE.

```yaml
# identity_discrimination_engine.yaml
cheekbone_R_threshold:
  value: 0.048  # Увеличить если много PUT классифицируется как DOUBLE
  # current: 0.048
```

### Шаг 3: Aging model перекалибровка

Если false positive на aging violation:
1. Проверить year accuracy (EXIF)
2. Если год неточный → false violation
3. Увеличить z_threshold: 2.5 → 3.0

### Шаг 4: Ensemble weight tuning

```yaml
# cross_center_verdict_model.yaml
weights:
  # Если UDMURT/VAS путаются
  # Увеличить вес discriminative metrics:
  cheekbone_R_normal_mean_y: 0.55  # было 0.487
  orbit_R_bbox_volume_ratio: 0.25    # было 0.200
```

### Шаг 5: Validation

```bash
# Cross-validation
python scripts/run_calibration_pipeline.py \
    --reference reference_geometry_new.json \
    --test-data /path/to/test.csv \
    --output validation_report.json

# Ожидаемые результаты:
# PUT accuracy > 0.98
# UDMURT accuracy > 0.85
# VAS accuracy > 0.85
# Overall > 0.97
```

## Troubleshooting Matrix

| Симптом | Причина | Решение |
|---|---|---|
| PUT → DOUBLE (FP) | Порог слишком низкий | Увеличить threshold |
| DOUBLE → PUT (FN) | Порог слишком высокый | Уменьшить threshold |
| UDM ↔ VAS confusion | Недостаточно discriminative metrics | Добавить chin/jaw метрики |
| Aging FP | Неточный год фото | Увеличить z_threshold |
| Aging FN | Маска не детектируется | Добавить temporal constancy rule |
| Cross-center noise | Неисправный reconstruction | Quality gate check |
| Profile failure | Blind zones | Fallback на frontal metrics |
| Ensemble disagreement | Метрики конфликтуют | Weight tuning |

## Контакты

Если проблема не решается — проверить:
1. `METRIC_EVIDENCE_TABLE.csv` — consistency направления?
2. `reference_geometry.json` — все thresholds присутствуют?
3. Calibration data distribution — PUT/UDM/VAS баланс?
4. LOG — есть ли ERROR или WARNING?