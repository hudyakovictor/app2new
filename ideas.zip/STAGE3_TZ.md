# ТЗ — Этап 3 «CALIBRATION»: модель шума ракурса/эпохи по калибровочному датасету

Версия: 1.0. Продолжение `STAGE2_TZ.md`. Основано на анализе текущего `backend/` (NEWWAP),
`aboutplatform.txt`, `AGENTS.md`, `REFACTOR_PLAN.md`, `stage3_texture_prep/INDEX.md`,
`stage3_geomety_info/README (5).md`. Формат — самодостаточное инженерное ТЗ: цель,
границы, входы/выходы, пошаговый алгоритм, контракты данных, обработка ошибок,
критерии приёмки, тест-план, порядок переноса кода.

---

## 1. Цель этапа

Построить две независимые, но структурно однотипные **модели шума** — геометрическую
и текстурную — из калибровочного датасета. Эти модели замораживаются до начала
попарного сравнения и вердикта (Этап 4) и служат единственным источником истины
для ответа на вопрос: «является ли наблюдаемая разница между двумя фото одного
ракурса статистически ожидаемой для естественной вариативности данного человека,
или она выходит за пределы шума, характерного для этой эпохи/ракурса?»

Без Этапа 3 невозможно отличить:
- **нормальный шум съёмки** (разное освещение, разная камера, JPEG-артефакты плёнки 2000 года)
  от
- **форензик-значимого отклонения** (силиконовая маска на похожем черепе, цифровая
  постобработка, подмена лица).

Этап 3 **не принимает** решений «настоящее/поддельное» по конкретному фото —
он строит **эталонную модель ожидаемого шума**, которую Этап 4 будет использовать
как нулевую гипотезу при сравнении.

---

## 2. Входы и выходы

### 2.1 Вход

Этап 3 потребляет результаты Этапов 1 и 2 для **всех** фото калибровочного датасета
(`dataset=calibration`), а также метаданные калибровочных пар:

```
# На каждое calibration-фото:
storage/calibration/{photo_id}/
├── info.json                  # из Этапа 1: pose, bucket, date, quality, expression flags
├── reconstruction_v1.pkl      # из Этапа 1: канон-меш
├── face_mask.png              # из Этапа 1: RGBA-кроп кожи
└── metrics.csv                # из Этапа 2: сырые метрики geometry + texture

# Метаданные калибровочного датасета:
calibration_manifest.json      # список calibration photo_id с ground-truth: real/silicone
calibration_pairs.json         # пары (real_photo_id, silicone_photo_id), сматченные по bucket+epoch
                               #   (формируется скриптом select_calibration_pairs.py)
```

Важно: калибровочный датасет содержит фотографии **одного и того же человека**
(автора платформы) с документированными углами наклона головы в имени файла +
контрольную группу силиконовых масок (41 фото). Именно этот датасет позволяет
измерить «естественную вариативность» одного человека — baseline, относительно
которого будут оцениваться изменения субъекта (Путина) на основном датасете.

### 2.2 Выход

Два JSON-файла — единственные артефакты, которые Этап 4 обязан читать для
калибровочной информации:

```
storage/calibration/
├── reference_geometry.json    # модель шума для геометрических метрик
└── reference_texture.json     # модель шума для текстурных метрик
```

#### 2.2.1 `reference_geometry.json` — спецификация

```json
{
  "version": "1.0",
  "built_at": "2026-07-07T12:00:00Z",
  "source": "calibration dataset (224 photos: 183 real + 41 silicone)",
  "cohorts": {
    "real_epoch_recent": {
      "n": 50,
      "description": "Real skin, epoch ≥ 2015 (цифровые фото высокого качества)",
      "by_bucket": {
        "frontal": {
          "zone_morphology_cheek_median": {
            "mean": 0.0, "std": 0.0, "median": 0.0,
            "p5": 0.0, "p95": 0.0, "n_valid": 0
          },
          "...": "..."
        },
        "left_threequarter_light": { "...": "..." }
      }
    },
    "real_epoch_legacy": {
      "n": 30,
      "description": "Real skin, epoch < 2015 (плёночные сканы, низкое качество)",
      "by_bucket": { "...": "..." }
    },
    "real_pooled": {
      "n": 183,
      "description": "Все real фото pooled (для метрик, где эпоха слабо влияет)",
      "by_bucket": { "...": "..." }
    },
    "silicone_mask": {
      "n": 41,
      "description": "Силиконовые маски (контрольная группа)",
      "by_bucket": { "...": "..." }
    }
  },
  "noise_model_by_epoch": {
    "recent": {
      "q_noise_mean": 0.25, "q_noise_std": 0.05,
      "q_blur_mean": 0.15, "q_blur_std": 0.04,
      "q_overall_mean": 0.60, "q_overall_std": 0.08
    },
    "legacy": {
      "q_noise_mean": 0.55, "q_noise_std": 0.15,
      "q_blur_mean": 0.40, "q_blur_std": 0.10,
      "q_overall_mean": 0.30, "q_overall_std": 0.10
    }
  },
  "noise_model_by_bucket": {
    "frontal": {
      "intra_bucket_variance": { "median_cv": 0.05, "p95_cv": 0.15 },
      "inter_epoch_shift": { "...": "..." }
    },
    "left_profile": { "...": "..." }
  },
  "mesh_zone_coverage": {
    "total_zones": 24,
    "valid_zones": 14,
    "placeholder_zones": ["zone_3", "zone_7", "..."],
    "min_vertices_per_valid_zone": 50
  },
  "zone_weights": {
    "bone": 1.0,
    "ligament": 0.7,
    "soft_tissue": 0.4
  },
  "metrics": {
    "included_metric_families": [
      "zone_morphology", "mirror_asymmetry", "orbit_special",
      "brow_lid", "nose_bridge", "mandible", "palpebral_aperture",
      "distances", "angles", "triangles", "curvature_normals"
    ],
    "excluded_from_calibration": [
      "dense_residuals", "pair_zone_residuals"
    ],
    "excluded_zones": [
      "lip", "mouth_corner", "nasolabial", "forehead_wrinkle"
    ]
  }
}
```

#### 2.2.2 `reference_texture.json` — спецификация

```json
{
  "version": "1.0",
  "built_at": "2026-07-07T12:00:00Z",
  "source": "calibration dataset (224 photos) + stress-test augmented (320 images)",
  "cohorts": {
    "real_epoch_recent": {
      "n": 50,
      "by_bucket": {
        "frontal": {
          "glcm_dissimilarity_d5_a0": {
            "mean": 1.827, "std": 0.198,
            "median": 1.810, "p5": 1.550, "p95": 2.180
          },
          "glcm_homogeneity_d5_a0": {
            "mean": 0.517, "std": 0.034,
            "median": 0.514, "p5": 0.470, "p95": 0.580
          },
          "homo_local_var_w15_cv": {
            "mean": 1.887, "std": 0.270,
            "median": 1.850, "p5": 1.520, "p95": 2.390
          }
        }
      }
    },
    "real_epoch_legacy": { "...": "..." },
    "silicone_mask": {
      "n": 41,
      "by_bucket": {
        "frontal": {
          "glcm_dissimilarity_d5_a0": {
            "mean": 1.323, "std": 0.189,
            "median": 1.300, "p5": 1.070, "p95": 1.670
          },
          "glcm_homogeneity_d5_a0": {
            "mean": 0.604, "std": 0.035,
            "median": 0.600, "p5": 0.550, "p95": 0.660
          }
        }
      }
    }
  },
  "top_discriminative_metrics": [
    {
      "name": "glcm_dissimilarity_d5_a0",
      "auc": 0.962,
      "cohens_d": 2.60,
      "separation": 2.61,
      "direction": "higher_real",
      "robustness_15_stress_auc": 1.000
    }
  ],
  "stress_robustness": {
    "tested_conditions": 16,
    "degradation_levels": {
      "noise_sigma": [0.005, 0.015, 0.030, 0.050, 0.080],
      "blur_sigma": [0.8, 1.5, 2.5, 3.5, 5.0]
    },
    "collapse_threshold": {
      "condition": "combo_s5 (σ_noise=0.080, σ_blur=5.0)",
      "top10_auc": 0.922,
      "status": "collapse"
    },
    "always_robust_metrics": [
      "feat_diffuse_specular_ratio", "patch_64_std_mean",
      "contrast_michelson_mean", "contrast_weber_mean", "hist_cv",
      "entropy_w15_median", "color_g_mean"
    ]
  },
  "shift_model": {
    "description": "Degradation-Aware Shift Verdict Model — компенсация деградации качества",
    "quality_weights": {
      "q_overall": 0.40, "q_noise": 0.35, "q_blur": 0.25
    },
    "hf_metrics": [
      "glcm_dissimilarity_d5_a0", "glcm_dissimilarity_d3_a0",
      "lbp_uniform_r5_std", "grad_sobel_mag_skewness"
    ],
    "robust_metrics": [
      "color_b_mean", "hessian_s4.0_ratio", "contrast_michelson_mean",
      "contrast_weber_mean", "hist_cv", "entropy_w15_median"
    ],
    "discount_thresholds": {
      "hf_partial_discount_at_effective_quality": 0.6,
      "hf_full_discount_at_effective_quality": 0.4
    },
    "formula": "shift_score = Σ (metric_value - reference_mean) / reference_std × metric_coef × effective_quality"
  },
  "quality_thresholds": {
    "min_skin_pixel_count": 5000,
    "min_mask_integrity_ratio": 0.85,
    "exposure_clip_percentile_low": 2,
    "exposure_clip_percentile_high": 98
  }
}
```

---

## 3. Архитектура: разделение геометрии и текстуры

Этап 3 строится как **два параллельных, независимых конвейера** с общим оркестратором:

```
                    ┌──────────────────────────┐
                    │  calibration_manifest.json│  список всех calibration photo_id
                    │  + ground truth labels    │  (real / silicone)
                    └──────────┬───────────────┘
                               │
               ┌───────────────┴───────────────┐
               │                               │
    ┌──────────▼──────────┐      ┌────────────▼────────────┐
    │  Geometry Pipeline   │      │   Texture Pipeline       │
    │                      │      │                          │
    │  1. Собрать все      │      │  1. Собрать все          │
    │     geometry-метрики │      │     texture-метрики      │
    │     из metrics.csv   │      │     из metrics.csv       │
    │     per bucket       │      │     per bucket           │
    │                      │      │                          │
    │  2. Кластеризовать   │      │  2. Кластеризовать       │
    │     по epoch         │      │     по epoch             │
    │                      │      │                          │
    │  3. Построить        │      │  3. Построить            │
    │     когорты          │      │     когорты              │
    │     (real/silicone)  │      │     (real/silicone)      │
    │                      │      │                          │
    │  4. Вычислить        │      │  4. Вычислить            │
    │     noise_model      │      │     noise_model          │
    │     (per epoch,      │      │     (per epoch,          │
    │      per bucket)     │      │      per bucket)         │
    │                      │      │                          │
    │  5. Записать         │      │  5. Применить            │
    │     reference_       │      │     stress_robustness    │
    │     geometry.json    │      │     matrix               │
    │                      │      │                          │
    └──────────┬───────────┘      │  6. Построить            │
               │                  │     shift_model          │
               │                  │                          │
               │                  │  7. Записать             │
               │                  │     reference_           │
               │                  │     texture.json         │
               │                  └────────────┬─────────────┘
               │                               │
               └───────────────┬───────────────┘
                               │
                    ┌──────────▼───────────┐
                    │  CalibrationValidator │  кросс-валидация обеих моделей,
                    │                       │  проверка на переобучение,
                    │                       │  bootstrap CI на метрики
                    └──────────────────────┘
```

Разделение критически важно, потому что:
- Геометрический шум зависит от ракурса (profile даёт больше неопределённости, чем frontal) и
  разрешения реконструкции;
- Текстурный шум зависит от эпохи/качества фото (плёночные сканы vs цифровые) и освещения;
- Модели строятся и валидируются независимо, одна не блокирует другую;
- Это прямое требование REFACTOR_PLAN.md: разделить `pipeline/calibration.py`,
  `core/calibration.py`, `core/fuzzy_bayes/calibration_pairs.py`, `core/texture_calibration.py`
  — четыре места с пересекающейся ответственностью.

---

## 4. Пошаговый алгоритм

### Шаг 0: Валидация входных данных

```
для каждого photo_id из calibration_manifest:
    проверить наличие info.json, metrics.csv
    проверить info.readiness.geometry != "unavailable" (для geometry pipeline)
    проверить info.readiness.texture  != "unavailable" (для texture pipeline)
    если отсутствует → photo_id помечается как skipped, причина логируется
```

### Шаг 1: Сбор сырых метрик из metrics.csv

Для **geometry pipeline**:
- Из `metrics.csv` каждого calibration-фото читаются все строки с `metric_family` из списка
  `included_metric_families` (см. §2.2.1);
- Строки группируются по `pose_bucket` → `metric_name` → значения;
- Отбрасываются метрики из `excluded_zones` (зоны, чувствительные к мимике: lip, mouth_corner,
  nasolabial, forehead_wrinkle — весовая модель bone > ligament > soft tissue);
- Отбрасываются метрики с `source_space != "canon_bucket"` (только канон-пространство);
- Для метрик, принадлежащих `placeholder_zones` (зоны с 2-3 вершинами — 10 из 24 зон),
  значение записывается как `null`, зона помечается в `mesh_zone_coverage.placeholder_zones`.

Для **texture pipeline**:
- Из `metrics.csv` каждого calibration-фото читаются все строки с `metric_family ∈ {texture_roi,
  spectral_zone}` и текстурные признаки из `skin_authenticity` (GLCM/LBP/Gabor/etc.);
- Строки группируются по `pose_bucket` → `metric_name` → значения;
- Применяется **preprocessing маски** (см. STAGE2_TZ.md §6.2): clipping exposure extremes
  (p2–p98), removal of small disconnected fragments, min skin pixel threshold;
- Вычисляется `mask_integrity_ratio` — доля наибольшего связного компонента маски.

### Шаг 2: Кластеризация фото по эпохам

```
epoch(date) =
    "legacy"  если date.year < 2015
    "recent"  если date.year >= 2015
```

Порог 2015 выбран из практики: именно в этот период произошёл массовый переход
от плёночных сканов к цифровым фото в основном датасете (Путин). Для калибровочного
датасета автора порог может быть другим — выносится в конфиг `calibration_config.json`.

Для каждой ячейки `(cohort, epoch, bucket)` должно быть не менее `min_samples = 5` фото.
При недостатке — ячейка объединяется с соседней эпохой или помечается как
`underpopulated` (с пониженным весом в downstream).

### Шаг 3: Построение когорт

**Три когорты для геометрии:**
- `real_epoch_recent` — real фото эпохи recent
- `real_epoch_legacy` — real фото эпохи legacy
- `silicone_mask` — все силиконовые фото (независимо от эпохи — их мало, 41 шт.)

**Три когорты для текстуры (аналогично):**
- `real_epoch_recent`, `real_epoch_legacy`, `silicone_mask`

Для каждой когорты, каждого bucket и каждой метрики вычисляются:
```
mean, std, median, p5, p95, n_valid
```

Статистики считаются робастно: через trimmed mean (trim 10%) и MAD-based std вместо
sample std — для устойчивости к выбросам (единичные фото с аномальным освещением).

### Шаг 4: Построение noise_model

**4a. Noise model by epoch** — агрегация quality-метрик по эпохам:

```
для каждой эпохи e:
    q_noise_mean[e]  = mean(info.quality.noise_index   для всех фото эпохи e)
    q_noise_std[e]   = std(info.quality.noise_index)
    q_blur_mean[e]   = mean(info.quality.blur_index)
    q_blur_std[e]    = std(info.quality.blur_index)
    q_overall_mean[e] = mean(info.quality.overall_score)
    q_overall_std[e]  = std(info.quality.overall_score)
```

**4b. Noise model by bucket** — intra-bucket вариативность:

```
для каждого bucket b:
    для каждой метрики m:
        pooled = все real-значения m в bucket b (обе эпохи)
        cv[m]  = std(pooled) / |mean(pooled)|  # coefficient of variation
    intra_bucket_variance[b].median_cv = median(cv по всем m)
    intra_bucket_variance[b].p95_cv    = p95(cv по всем m)
```

**4c. Inter-epoch shift by bucket:**

```
для каждого bucket b, каждой метрики m:
    shift[b][m] = mean(m в recent) - mean(m в legacy)
    shift_normalized[b][m] = shift[b][m] / pooled_std(b, m)
```

Метрики, где `|shift_normalized| > 2.0` — кандидаты на «эпохально-чувствительные» —
для них в Этапе 4 должен применяться разный reference в зависимости от эпохи фото.

### Шаг 5 (только texture): Stress robustness matrix

Для текстуры дополнительно применяется стресс-тест (результаты из `stage3_texture_prep/`):

1. Для каждой из топ-20 дискриминативных метрик (из `clean_feature_leaderboard.csv`)
   вычисляется AUC на 16 условиях деградации (clean + noise s1–s5 + blur s1–s5 + combo s1–s5).
2. Метрики, сохраняющие AUC ≥ 0.90 на всех 16 условиях, помечаются как `always_robust`.
3. Определяется `collapse_threshold` — наихудшее условие, где top-10 AUC падает ниже 0.95.
4. Формируются два списка: `hf_metrics` (высокочастотные, чувствительные к шуму) и
   `robust_metrics` (оптические/цветовые, устойчивые).

### Шаг 6 (только texture): Построение shift_model

На основе стресс-теста фиксируются коэффициенты Degradation-Aware Shift Verdict Model:

```
effective_quality = w1 × q_overall + w2 × (1 - q_noise_level) + w3 × (1 - q_blur_level)
где w1=0.40, w2=0.35, w3=0.25 (определены эмпирически из стресс-теста)

При effective_quality < 0.6: hf_metrics дисконтируются пропорционально качеству
При effective_quality < 0.4: hf_metrics исключаются полностью (weight = 0)
robust_metrics — без дисконтирования на всём диапазоне quality
```

Это ключевая инновация: вместо статических порогов (которые ломаются при шуме/blur),
система отслеживает **смещение** метрик с поправкой на качество. Без этого механизма
старые плёночные фото 1999 года будут систематически классифицироваться как
«подозрительные» из-за высокого шума — ровно тот риск, который описан в ТЗ платформы.

### Шаг 7: Запись выходных файлов

- `reference_geometry.json` — JSON с форматированием (indent=2), кодировка UTF-8.
- `reference_texture.json` — JSON с форматированием (indent=2), кодировка UTF-8.

Оба файла содержат поле `built_at` с ISO-8601 timestamp и `version` для отслеживания.

### Шаг 8: Валидация моделей

```
1. Bootstrap CI (n=1000) на ключевые метрики — проверка стабильности mean/std
2. Cross-validation (leave-one-bucket-out): для каждого bucket
   обучить модель на остальных 8 бакетах, проверить, что
   intra_bucket_variance предсказуема
3. Проверка на переобучение: сравнить mean/std когорт на
   тренировочной (80%) и тестовой (20%) выборках
4. Negative control: запустить модель на заведомо «чужих» фото
   (другой человек) — shift должен быть значимым
```

---

## 5. Контракты данных

### 5.1 Конфигурация этапа (`calibration_config.json`)

```json
{
  "epoch_split_year": 2015,
  "min_samples_per_cell": 5,
  "trim_percent": 10,
  "bootstrap_iterations": 1000,
  "cross_validation_folds": 9,
  "zone_weight_model": {
    "bone": 1.0,
    "ligament": 0.7,
    "soft_tissue": 0.4
  },
  "expression_excluded_zones": [
    "lip", "mouth_corner", "nasolabial", "forehead_wrinkle"
  ],
  "min_skin_pixel_count": 5000,
  "min_mask_integrity_ratio": 0.85,
  "exposure_clip_percentile": [2, 98],
  "stress_test": {
    "noise_sigmas": [0.005, 0.015, 0.030, 0.050, 0.080],
    "blur_sigmas": [0.8, 1.5, 2.5, 3.5, 5.0]
  },
  "shift_model_weights": {
    "q_overall": 0.40,
    "q_noise": 0.35,
    "q_blur": 0.25
  }
}
```

### 5.2 Формат `calibration_manifest.json`

```json
{
  "version": "1.0",
  "photos": [
    {
      "photo_id": "cal_2023_frontal_01",
      "dataset": "calibration",
      "ground_truth": "real",
      "bucket": "frontal",
      "date": "2023-05-15",
      "yaw_deg": 2.3,
      "pitch_deg": -1.1,
      "roll_deg": 0.5
    },
    {
      "photo_id": "cal_silicone_frontal_01",
      "dataset": "calibration",
      "ground_truth": "silicone",
      "bucket": "frontal",
      "date": "2024-01-20",
      "yaw_deg": 1.8,
      "pitch_deg": 0.3,
      "roll_deg": -0.7
    }
  ]
}
```

### 5.3 Формат `calibration_pairs.json` (формируется `select_calibration_pairs.py`)

```json
{
  "pairs": [
    {
      "id": "pair_001",
      "real_photo_id": "cal_2023_frontal_01",
      "silicone_photo_id": "cal_silicone_frontal_01",
      "bucket": "frontal",
      "epoch": "recent",
      "confidence": 0.95,
      "shared_metrics": [
        "zone_morphology_cheek_median",
        "glcm_dissimilarity_d5_a0"
      ]
    }
  ],
  "coverage": {
    "buckets_covered": 7,
    "epochs_covered": ["recent", "legacy"],
    "total_pairs": 40
  }
}
```

Критерии отбора пар (из `select_calibration_pairs.py`):
1. Оба фото имеют ≥ 5 метрик с AUC ≥ 0.85;
2. Пара покрывает редкую комбинацию bucket×epoch;
3. `quality_index` обоих фото ≥ 0.7;
4. Не более 3 пар с одинаковым photo_id (diversity).

---

## 6. Обработка ошибок и граничные случаи

| Ситуация | Действие |
|----------|----------|
| Ячейка `(cohort, epoch, bucket)` имеет < 5 фото | Объединить с соседней эпохой (legacy→recent или наоборот); если всё ещё < 5 — пометить `underpopulated`, присвоить weight = 0.5 в downstream |
| Для метрики все значения в когорте одинаковы (std=0) | Пометить как `degenerate`, исключить из downstream comparison, залогировать |
| `mask_integrity_ratio` < 0.85 для текстурной когорты | Исключить фото из когорты (не из всего пайплайна — geometry может быть OK) |
| `placeholder_zone` (2-3 вершины) | Записать mean/std как `null`, пометить зону в `mesh_zone_coverage.placeholder_zones` |
| Отсутствует calibration-фото для целого bucket в silicone-когорте | Пометить bucket как `no_silicone_baseline`, в Этапе 4 skin verdict для этого bucket будет `uncertain` |
| Расхождение между train (80%) и test (20%) > 20% по ключевым метрикам | Флаг `overfit_warning`, модель всё равно записывается, но с diagnostics |
| Bootstrap CI шириной > 30% от значения mean | Метрика помечается `high_variance`, в downstream получает пониженный confidence |

---

## 7. Порядок переноса кода (из REFACTOR_PLAN.md)

### 🟢 Перенести как есть

| Модуль | Комментарий |
|--------|-------------|
| `pipeline/person_baseline.py` (`build_person_baselines`) | Медианный intra-band error по person/bucket — прямая реализация идеи калибровки шума |
| `pipeline/mesh_units.py` | Константы перевода mesh→мм, критичны для геометрических референсов |
| `pipeline/pose_gate.py` | Чистая, с тестами — используется для верификации, что калибровочная пара действительно в одном ракурсе |
| `core/contracts.py` (`MeasurementResult`, `ResultStatus`, `AdmissibilityDecision`) | Типизированные контракты — расширить на CalibrationResult |
| `core/utils.py`: `parse_date_from_name`, `subject_age_years_at`, `stable_photo_id` | Для построения временны́х меток когорт |
| `forensic/negative_control.py`, `forensic/prior_sensitivity.py`, `forensic/bootstrap_ci.py`, `forensic/chrono_cluster.py` | Статистический аппарат валидации — CI, PELT-breakpoints, кластеризация |

### 🟡 Перенести с рефакторингом

| Модуль | Комментарий |
|--------|-------------|
| `pipeline/calibration.py` (`CalibrationAnalyzer`, `CalibrationProtocol`, `find_calibration_match`) | Рабочая реализация подбора калибровочных пар и вычитания шума. Нужно **объединить** с `core/calibration.py` и `core/fuzzy_bayes/calibration_pairs.py` в единый пакет `calibration/` |
| `core/fuzzy_bayes/calibration_pairs.py`, `calibration_quality.py`, `ref_quality.py` | Логика оценки качества пар — переносить после пересборки reference_v4 |
| `pipeline/mask_anomaly/baseline_cache.py`, `config.py`, `scorer.py` | Referenced baseline 1999–2001 — верифицировать сквозной путь end-to-end тестом |
| `metrics/catalog_specs.py`, `metrics/policy.py` | Использовать для определения included/excluded метрик и политик ракурса |
| `metrics/csv_reader.py` | Чтение metrics.csv — простое, перенести |
| `pipeline/zones.py` (`EXCLUDED_ZONES`, `apply_expression_exclusion_mask`, `zone_bone_weight`) | Весовая модель зон — прямая реализация идеи «исключать мимические зоны» |

### 🔴 Переписать заново

| Модуль | Комментарий |
|--------|-------------|
| `core/texture_baseline.py`, `core/texture_calibration.py`, `core/texture_live_reference.py` | Фейковый reference_v4 (photo_count=0 для synthetic, 5 live cohorts = один список). Данные невалидны — логику агрегации взять за основу, но наполнение пересобрать из `FORENSIC_DECISION_ENGINE.md` |
| `core/calibration.py` (отдельный от pipeline) | Пересекается с pipeline/calibration.py — объединить |

### Новое (не существует в текущем коде)

- `calibration/geometry_builder.py` — сборка reference_geometry.json по алгоритму §4
- `calibration/texture_builder.py` — сборка reference_texture.json + shift_model
- `calibration/validator.py` — кросс-валидация, bootstrap CI, negative control
- `calibration/epoch_splitter.py` — логика разделения на эпохи
- `calibration/config.py` — calibration_config.json

---

## 8. Критерии приёмки (Definition of Done)

1. **Geometry reference**: для каждой из ≥ 7 ячеек `(cohort, bucket)` с n ≥ 5
   посчитаны mean/std/median/p5/p95 по всем included-метрикам; placeholder-зоны
   явно помечены; `noise_model_by_bucket` содержит валидные значения CV.
2. **Texture reference**: для каждой когорты посчитаны статистики по топ-20
   дискриминативных метрик; `shift_model` содержит корректные коэффициенты;
   `stress_robustness` содержит AUC на всех 16 условиях.
3. **Воспроизводимость**: повторный запуск на том же calibration-датасете даёт
   reference-файлы, идентичные с точностью до floating-point tolerance = 1e-6
   (детерминированные алгоритмы, без случайных seed).
4. **Bootstrap-стабильность**: для топ-10 метрик каждой когорты 95% CI шириной
   не более 25% от mean.
5. **Cross-validation**: leave-one-bucket-out — intra_bucket_variance
   предсказывается с ошибкой не более 30% относительного отклонения.
6. **Negative control**: на 10 «чужих» фото (не автор, не Путин) shift > 2σ
   от reference как минимум по 3 метрикам.
7. **Silicone separation**: ни одна метрика в `silicone_mask` когорте не
   перекрывается с `real_pooled` более чем на 20% площади распределений
   (Cohen's d > 1.0 для всех топ-10 метрик).
8. **Интеграция с Этапом 4**: `reference_geometry.json` и `reference_texture.json`
   проходят валидацию по JSON Schema (соответствующей §2.2.1/§2.2.2);
   Этап 4 успешно загружает оба файла и применяет `shift_model` для
   quality-compensated verdict.

---

## 9. Тест-план

### 9.1 Юнит-тесты

- `epoch_splitter` — граничные даты (ровно 2015-01-01, день до/после).
- `build_person_baselines` — параметризованный тест: синтетический набор
  метрик с известной intra-band вариативностью.
- `compute_cohort_stats` — trimmed mean совпадает с эталонным расчётом
  (scipy.stats.trim_mean) с tolerance = 1e-9.
- `shift_model` — для синтетического quality (0.3, 0.5, 0.7) проверка
  корректного дисконтирования hf_metrics.
- `zone_weight_model` — проверка, что мимические зоны исключаются,
  костные получают полный вес.

### 9.2 Интеграционные тесты

- Полный прогон geometry pipeline на calibration-датасете (224 фото) —
  выходной `reference_geometry.json` соответствует схеме.
- Полный прогон texture pipeline — выходной `reference_texture.json`
  соответствует схеме.
- Проверка: `real_epoch_recent` и `real_epoch_legacy` имеют значимые
  различия по качественным метрикам (Mann-Whitney p < 0.01 для
  `q_overall_score`).
- Проверка: `silicone_mask` значимо отличается от `real_pooled`
  по ≥ 15 из топ-20 метрик.

### 9.3 Регрессионные тесты

- Повторный прогон — идентичность reference-файлов (SHA256 совпадает
  после нормализации floating-point).
- Добавление одного нового фото в calibration-датасет — reference
  обновляется, но без катастрофических изменений (> 3σ) в существующих
  статистиках.

---

## 10. Что явно НЕ входит в Этап 3

- Попарное сравнение фото друг с другом (ICP, mesh evidence) — **Этап 4**.
- Принятие вердикта «живая кожа/силикон» по конкретному фото — **Этап 4**.
- Байесовский синтез H0/H1/H2 — **Этап 5**.
- Хронологический анализ (кривая старения, скачки) — **Этап 5**.
- Построение отчётов, персон, эпох — **Этап 6**.
- Вычисление метрик (geometry/texture) заново — метрики уже посчитаны на **Этапе 2**;
  Этап 3 только агрегирует.
- Само создание calibration-датасета (фото автора, силиконовые маски) — это
  внешний процесс, не часть пайплайна; Этап 3 потребляет уже готовый датасет.

---

## 11. Зависимости от других этапов

```
Этап 1 (PREP)
    ↓ info.json, reconstruction_v1.pkl, face_mask.png
Этап 2 (METRICS)
    ↓ metrics.csv (geometry + texture)
Этап 3 (CALIBRATION)         ← мы здесь
    ↓ reference_geometry.json + reference_texture.json
Этап 4 (PAIR & VERDICT)
    ↓ pairwise evidence + skin verdict per photo
Этап 5 (BAYES & CHRONO)
    ↓ forensic verdict + timeline anomalies
Этап 6 (REPORT)
```

---

*Версия: 1.0. Основано на REFACTOR_PLAN.md, stage3_texture_prep/INDEX.md, stage3_geomety_info/README (5).md.*

---

## Дополнение: Правки из аудита аналитиков (applicable к Этапу 3)

### 🔴 П1-01: Полная пересборка reference-данных
**Что**: `reference_v4` содержит фиктивные данные — synthetic photo_count=0, 5 live-когорт все =610.
**Как**:
1. Пересобрать `reference_texture.json` и `reference_geometry.json` из **реальных** калибровочных фото
2. Источник: 223 CALIB + 41 MASK (реальные фото из датасета)
3. Каждая когорта должна содержать честный `photo_count`, медианы и AUC
4. Файл `reference_v4` **удалить**, заменить на новый `reference_v5`
5. Тест: `assert reference_data['synthetic']['photo_count'] > 0`

### 🔴 П1-04 (часть калибровки): Объединение 4 калибровочных модулей
**Что**: Калибровка размазана по 4 модулям (1774 строки суммарно).
**Как**:
1. Создать единый фасад `calibration/__init__.py` с API:
   - `find_pair(photo, angle) → CalibrationPair`
   - `noise_model(bucket) → NoiseModel`
   - `epoch_baseline(year) → EpochBaseline`
2. Старые модули (`pipeline/calibration.py`, `core/calibration.py`, `fuzzy_bayes/calibration_pairs.py`, `texture_calibration.py`) — приватные, делегирующие через фасад
3. Все импортёры перевести на фасад

### 🟡 П2-13 (часть): Evidence Log — Stage 3 output
На выходе Этапа 3 сохранять `evidence_stage3.json`:
```json
{
  "calibration_status": "REBUILT",
  "cohorts": {"live": 5, "synthetic": 2, "total_photos": 264},
  "noise_model": {"frontal": {"sigma": 0.32}, "profile_deep": {"sigma": 0.58}},
  "reference_quality": "REAL_DATA"
}
```
