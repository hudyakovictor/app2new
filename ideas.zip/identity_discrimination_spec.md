# Identity Discrimination Spec — 3-Person Classification

## Three-Tier Classifier

### Tier 1: PUT vs Silicone (All Doubles)

**Цель:** Отличить PUT от любого двойника

**Golden Standard (99.9%):**
```
cheekbone_R_normal_mean_y > 0.048 → DOUBLE (Путин не может быть >0.048)
```

**Supporting Rules:**
```
cheekbone_L_normal_mean_y > 0.061 → DOUBLE (99.0%)
orbit_R_bbox_volume_ratio < 0.001 → NOT_PUT (96.0%)
jaw_angle_L_radial_dispersion < 0.005 → NOT_PUT (93.5%)
```

**Decision:** Weighted voting (Composite Score weights)
- Если суммарный weight DOUBLE ≥ 0.5 → DOUBLE
- Иначе → PUT (default)

### Tier 2: UDMURT vs VAS

**Цель:** Разделить двоек

**Thresholds:**
```
chin_normal_mean_x > 0.016 → VAS (75.4%)
chin_normal_mean_x > 0.007 → UDMURT/VAS (70.9%)
jaw_R_normal_mean_z > 0.033 → LIKELY_DOUBLE (84.4%)
brow_ridge_normal_angle > 42° → UDMURT (предпочтительный ракурс)
```

**Decision:** Simple majority voting
- Если ≥2 метрик указывают на VAS → VAS
- Иначе → UDMURT

### Tier 3: Aging Model Violation

**Цель:** Подтвердить synthetic/unnatural

**Rules:**
```
Deviation from PUT trajectory (per year)
  z = (observed - expected_PUT) / std_PUT
  if z > 2.5:
      flag = "synthetic_aging"
      confidence *= 0.80  # penalty
```

**Frosting detection (frozen face):**
```
Over 2+ years:
  change < 0.01 → "frozen" (mask indicator)
```

## Output Format

```json
{
  "verdict": "PUT" | "UDMURT" | "VAS" | "UNCERTAIN",
  "confidence": 0.85,
  "tier_used": 1 | 2 | 3,
  "details": {
    "double_rules": {
      "cheekbone_R": {"value": 0.052, "threshold": 0.048, "fired": true},
      "orbit_R": {"value": 0.0008, "threshold": 0.001, "fired": true}
    },
    "aging_violation": {
      "violation_score": 0.72,
      "deviation_z": 3.4,
      "from_trajectory": true
    }
  }
}
```