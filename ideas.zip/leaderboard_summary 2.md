# Leaderboard Summary — Top-20 Texture Metrics

## Источник

Данные из `unified_test/clean_feature_leaderboard.csv` (591→20 итеративно отобраных метрик).
Это финальный leaderboard после 6 итераций отбора на clean data.

**N_calibration = 91** (52 real + 39 silicone, 2026-07-07 UTC 01:14–01:17 run)

---

## Топ-20 метрик (по composite score)

| # | Metric | AUC | Cohen's d | Separation | Direction | Real μ±σ | Silicone μ±σ |
|---|--------|-----|-----------|------------|-----------|----------|--------------|
| 1 | `glcm_dissimilarity_d5_a0` | 0.961 | 2.605 | 2.605 | higher_real | 1.827±0.198 | 1.323±0.189 |
| 2 | `glcm_homogeneity_d5_a0` | 0.960 | 2.526 | 2.527 | higher_silicone | 0.517±0.034 | 0.604±0.035 |
| 3 | `glcm_dissimilarity_d3_a0` | 0.957 | 2.532 | 2.532 | higher_real | 1.394±0.166 | 0.980±0.161 |
| 4 | `homo_local_var_w15_cv` | 0.956 | 2.476 | 2.518 | higher_silicone | 1.887±0.270 | 2.721±0.392 |
| 5 | `contrast_weber_mean` | 0.937 | 2.537 | 2.658 | higher_real | 0.0888±0.0179 | 0.0526±0.0094 |
| 6 | `homo_local_var_w31_cv` | 0.951 | 2.414 | 2.471 | higher_silicone | 1.367±0.176 | 1.923±0.274 |
| 7 | `color_b_mean` | 0.952 | 2.287 | 2.373 | higher_silicone | 94.7±10.1 | 127.9±17.9 |
| 8 | `glcm_homogeneity_d3_a0` | 0.940 | 2.227 | 2.228 | higher_silicone | 0.585±0.038 | 0.667±0.036 |
| 9 | `glcm_dissimilarity_d3_a135` | 0.939 | 2.206 | 2.208 | higher_real | 1.324±0.163 | 0.980±0.149 |
| 10 | `glcm_dissimilarity_d2_a0` | 0.940 | 2.174 | 2.174 | higher_real | 1.118±0.157 | 0.778±0.156 |
| 11 | `lbp_uniform_r5_std` | 0.938 | 2.170 | 2.210 | higher_real | 13.11±0.148 | 12.71±0.219 |
| 12 | `glcm_dissimilarity_d5_avg` | 0.936 | 2.164 | 2.168 | higher_real | 1.834±0.210 | 1.402±0.189 |
| 13 | `glcm_dissimilarity_d3_avg` | 0.936 | 2.157 | 2.158 | higher_real | 1.331±0.167 | 0.982±0.157 |
| 14 | `morph_tophat_r4_std` | 0.941 | 2.110 | 2.119 | higher_real | 9.882±1.985 | 6.029±1.650 |
| 15 | `glcm_dissimilarity_d5_a135` | 0.934 | 2.151 | 2.152 | higher_real | 1.902±0.203 | 1.474±0.195 |
| 16 | `glcm_dissimilarity_d2_range` | 0.951 | 2.018 | 2.020 | higher_real | 0.264±0.042 | 0.177±0.045 |
| 17 | `grad_sobel_mag_skewness` | 0.937 | 2.103 | 2.152 | higher_silicone | 3.908±0.875 | 6.314±1.361 |
| 18 | `residual_bio_iqr` | 0.933 | 2.099 | 2.147 | higher_real | 5.457±0.978 | 3.730±0.631 |
| 19 | `morph_tophat_r8_std` | 0.932 | 2.062 | 2.070 | higher_real | 14.89±2.681 | 9.788±2.249 |
| 20 | `glcm_dissimilarity_d5_a45` | 0.929 | 2.052 | 2.054 | higher_real | 1.925±0.231 | 1.473±0.209 |

---

## Метрики по семействам

### GLCM (доминирует — 13 из 20)

```
Dissimilarity variants (d=2,3,5; a=0,45,90,135,avg):
  d5_a0:      AUC=0.961, d=2.60  ← ЛУЧШАЯ
  d3_a0:      AUC=0.957, d=2.53
  d5_a45:     AUC=0.929, d=2.05
  d3_a135:    AUC=0.939, d=2.21
  d2_a0:      AUC=0.940, d=2.17
  d5_avg:     AUC=0.936, d=2.16
  d3_avg:     AUC=0.936, d=2.16
  d5_a135:    AUC=0.934, d=2.15
  d2_range:   AUC=0.951, d=2.02

Homogeneity variants:
  d5_a0:      AUC=0.960, d=2.53
  d3_a0:      AUC=0.940, d=2.23
```

**Интерпретация:** Dissimilarity (непохожесть текстуры) — ключевой discriminator.
Real skin → более нерегулярная текстура → выше dissimilarity.
Silicone mask → однородная → ниже dissimilarity.

### LBP (1 метрика)

```
lbp_uniform_r5_std:  AUC=0.938, d=2.17
→ Local Binary Pattern (radius=5) по std — умеренно информативен
→ Не попал в топ-5 потому что LBP захватывает локальные паттерны,
   не глобальную текстурную регулярность
```

### Gradient (1 метрика)

```
grad_sobel_mag_skewness:  AUC=0.937, d=2.10
→ Skewness распределения градиентов — silicone даёт более симметричное (менее анизотропное) поле градиентов
```

### Morphological (2 метрики)

```
morph_tophat_r4_std:  AUC=0.941, d=2.11
morph_tophat_r8_std:  AUC=0.932, d=2.06
→ Top-hat transform (r=4,8) — разница между морфологическим открытием и оригиналом.
→ Real: higher variance (мелкие структуры), Silicone: lower (flat surface)
```

### Color (1 метрика)

```
color_b_mean:  AUC=0.952, d=2.29
→ B-канал (LAB) — silicone masks имеют systematically higher blue channel.
→ Наиболее устойчив к шуму (robust metric)
```

### Local variance (2 метрики)

```
homo_local_var_w15_cv:  AUC=0.956, d=2.48
homo_local_var_w31_cv:  AUC=0.951, d=2.41
→ Coefficient of variation локальной дисперсии (w=15,31)
→ Real: lower CV (variation within local window), Silicone: higher CV (uniform patches)
```

### Residual (1 метрика)

```
residual_bio_iqr:  AUC=0.933, d=2.10
→ IQR биологического residual-а (высокочастотная составляющая после крупномасштабной аппроксимации)
→ Real: higher IQR (остаточная текстура), Silicone: lower (гладкая поверхность)
```

### Contrast (1 метрина)

```
contrast_weber_mean:  AUC=0.937, d=2.54
→ Weber contrast — отношение разности яркостей к фоновой яркости.
→ Real: higher (локальные вариации), Silicone: lower (uniform)
```

---

## Что отсеялось на итерациях (не в топ-20)

Эти метрики были отсеяны как redundant или noisy:

| Метрика | Причина отсеивания |
|---------|-------------------|
| glcm_contrast_* | Redundant с dissimilarity (корреляция > 0.9) |
| lbp_*_mean | Lower AUC чем std variant |
| entropy_w15_mean | Сильно коррелирует с color_b_mean |
| patch_*_entropy_mean | Overlaps с lbp_uniform_r5_std |
| hessian_s4.0_eigen1 | Нестабильна на размытых фото |

---

## Robustness: как ведут себя топ-5 при стрессе

Из `unified_test/stress_robustness_matrix.csv`:

| Metric | clean | noise_s5 | blur_s5 | combo_s5 | mean_stress |
|--------|-------|----------|---------|----------|-------------|
| glcm_dissimilarity_d5_a0 | 0.961 | 0.940 | 0.920 | 0.890 | 0.927 |
| glcm_homogeneity_d5_a0 | 0.960 | 0.935 | 0.910 | 0.875 | 0.920 |
| color_b_mean | 0.952 | 0.945 | 0.940 | 0.930 | 0.942 |
| glcm_dissimilarity_d3_a0 | 0.957 | 0.930 | 0.915 | 0.880 | 0.921 |
| homo_local_var_w15_cv | 0.956 | 0.925 | 0.905 | 0.870 | 0.914 |

**Наблюдения:**
- `color_b_mean` — most robust (устойчив к blur + noise)
- GLCM dissimilarity — robust к noise, умеренно чувствителен к blur
- combo_s5 (worst case): AUC падает с 0.96 → 0.87-0.89 без компенсации

---

## Рекомендации для Stage 3

**Обязательные топ-5 (для быстрого вердикта):**
1. `glcm_dissimilarity_d5_a0` (лучший AUC + good robustness)
2. `glcm_homogeneity_d5_a0` (nearly same AUC, complements dissimilarity)
3. `color_b_mean` (robust, не зависит от качества)
4. `homo_local_var_w15_cv` (хорошая сепарация, independent от GLCM)
5. `contrast_weber_mean` (независимый оттенок)

**Расширенный набор (Stage 3 → FORENSIC mode):**
Добавить: `grad_sobel_mag_skewness`, `morph_tophat_r4_std`, `residual_bio_iqr`

**Исключить (too slow or redundant):**
- Gabor filters (21s/image — слишком медленно)
- glcm_dissimilarity_d7_* (d=5 уже optimal, d=7 redundant)
- contour_fourier_descriptors (слабая сепарация в экспериментах V2)