# Noise Model (Geometry) Spec

## Назначение

Модель шума для геометрических метрик по эпохам и ракурсам.
Геометрия более устойчива чем текстура, но имеет свои нюансы:
- Reconstruction quality (LoD) сильно влияет на mesh metrics
- Occlusion (profile ракурсы исключают некоторые зоны)
- Normal estimation variance (для normal-based metrics)

## Epoch/Bucket Quality

| Epoch | q_reconstruction | q_lod | q_occlusion | q_overall |
|---|---|---|---|---|
| legacy (pre-2006) | 0.60 | 0.50 | 0.80 | 0.63 |
| mid (2006-2013) | 0.75 | 0.65 | 0.85 | 0.75 |
| recent (2014-2026) | 0.90 | 0.85 | 0.90 | 0.88 |

## Bucket-Specific Notes

| Bucket | Ограничения | Fallback metrics |
|---|---|---|
| frontal | None | All 10 metrics available |
| right_3/4 | Slightly left-side blind | Mirror equivalents |
| left_3/4 | Slightly right-side blind | Mirror equivalents |
| profile | One-side only, temporal blind | 5 metrics max |
| upturned/downturned | Jaw/forehead distortion | 3 metrics min |

## Quality Gate

Minimal for geometric analysis:
- q_reconstruction > 0.70 (decent mesh)
- q_lod > 0.50 (enough vertex density)
- q_occlusion > 0.80 (key zones visible)
- q_overall > 0.65

If below → mark as uncertain, skip problematic metrics.