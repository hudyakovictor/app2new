# Aging Model Spec — PUT Natural Aging vs Silicone Violation

## Проблема

Силиконовые двойники не следуют естественной траектории старения. Это позволяет обнаружить synthetic/unnatural aging даже если baseline геометрия похожа.

### Механизм

PUT имеет анатомически плавную возрастную динамику:
- Кости утончаются (cheekbone normals decrease)
- Орбитальные объёмы меняются предсказуемо
- Челюстные углы сглаживаются по возрасту

UDMURT/VAS:
- Геометрия "заморожена" (маска не меняется годами)
- Или меняется нереалистично (барьер силикона vs кость)

### Траектория PUT

| Время | Возраст | Cheekbone R mean | Орбита volume | Челюсть |
|---|---|---|---|---|
| 1998-2005 | 46-53 | 0.014 ± 0.003 | 0.0015 ± 0.0002 | Sharp angles |
| 2006-2013 | 54-61 | 0.024 ± 0.003 | 0.0012 ± 0.0002 | Moderate |
| 2014-2020 | 62-68 | 0.028 ± 0.003 | 0.0010 ± 0.0002 | Rounded |
| 2021-2026 | 69-74 | 0.032 ± 0.003 | 0.0009 ± 0.0002 | Highly rounded |

### Detection rules

```
Rule 1: Trajectory deviation
  z = |observed - expected_PUT(year)| / std_PUT(year)
  if z > 2.5 → violation

Rule 2: Temporal inconsistency
  change = |metric(t) - metric(t-1)|
  expected = PUT annual change for that metric
  if change > 5*expected → sudden (unnatural) change

Rule 3: Temporal constancy
  if |metric(t) - metric(t-2)| < 0.01 per 2 years → frozen face (mask)
```

### Integration

Aging violation score → H1_SYNTHETIC evidence в Stage 5 Bayes.

| Violation score | Interpretation | Bayes evidence |
|---|---|---|
| \u003c 0.3 | Natural aging | H0_SAME |
| 0.3-0.6 | Mild violation | H_UNCERTAIN |
| \u003e 0.6 | Synthetic aging | H1_SYNTHETIC |