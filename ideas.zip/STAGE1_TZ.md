# ТЗ — Этап 1 «PREP»: поза → 3D-реконструкция → канон-выравнивание → visibility → `info.json`

Версия: 1.0. Основано на анализе текущего `backend/` (NEWWAP), `aboutplatform.txt`,
`AGENTS.md`, `REFACTOR_PLAN.md`. Формат — самодостаточное инженерное ТЗ: цель,
границы, входы/выходы, пошаговый алгоритм, конкретные формулы/пороги (взяты из
рабочего кода, где они физически верны), контракты данных, обработка ошибок,
критерии приёмки, тест-план, порядок переноса кода.

---

## 1. Цель этапа

Превратить одно сырое JPEG-фото (из `photo/main` или `photo/calibration`) в
**полностью подготовленный к извлечению метрик набор артефактов**, где:

- поза головы определена и классифицирована по одному из 9 ракурсов;
- 3D-модель лица построена и выровнена в **канон-положение внутри своего
  ракурса** (устранён шум от разного наклона головы на разных фото одного
  ракурса);
- рассчитана видимость каждой вершины меша (occlusion/z-buffer);
- вырезан `face_mask.png` — кроп лица с альфа-маской кожи, готовый для
  текстурного анализа;
- зафиксированы технические флаги качества фото и выражения лица (улыбка,
  открытый рот), которые должны быть исключены на Этапе 2;
- записан лёгкий структурированный `info.json` — единственный контракт,
  который Этап 2 обязан читать (никаких сырых фото, никакого 3DDFA внутри
  Этапа 2).

Этот этап **не считает** ни одной геометрической или текстурной метрики
идентичности/подлинности. Всё, что касается сравнения лиц, детекции силикона,
байесовского вывода — вне границ Этапа 1.

---

## 2. Входы и выходы

### 2.1 Вход

Один файл изображения (JPEG/PNG) из датасета `main` или `calibration`:

```
photo_path: Path      # напр. /storage/photo/main/2001_03_23.jpg
dataset: "main" | "calibration"
previous_bucket: str | None   # bucket этого же photo_id с прошлого прогона (для гистерезиса), None при первом прогоне
```

Имя файла содержит дату всегда, углы наклона головы — только у калибровочных
фото (`calibration_y-10p4r0.jpg` и т.п.). **Важно**: имя файла — это НЕ
источник pose для main-датасета и не должно использоваться для вычисления
итоговой позы даже как fallback (за исключением опциональной pose-подсказки
для калибровочного датасета — см. §4.7). Единственные источники позы —
HPE-модель (head-pose-estimation) и 3DDFA_v3 (см. §4.1).

### 2.2 Выход — файловая структура

```
storage/{dataset}/{photo_id}/
├── info.json                  # обязателен — контракт для Этапа 2 (см. §6)
├── reconstruction_v1.pkl      # обязателен — кэш 3D (полная геометрия, для Этапов 3-5)
├── mesh.obj + mesh.mtl        # обязателен — meш для попарного сравнения (Этап 4)
├── face_mask.png              # обязателен (кроме hard-reject) — RGBA-кроп кожи для Этапа 2 (текстура)
├── face_crop.jpg              # обязателен (кроме hard-reject) — BGR preview без маски (UI/thumbnail)
├── thumb.jpg                  # обязателен — миниатюра для UI
└── {original_filename}        # копия исходника (аудит/воспроизводимость)
```

`info.json` — единственный файл, который обязаны читать все последующие
этапы для метаданных фото. Файлы `reconstruction_v1.pkl` и `mesh.obj`
открывают Этапы 2 (геометрия) и 4 (попарное сравнение) напрямую по путям,
указанным в `info.json`.

### 2.3 `photo_id`

Пере используем существующую функцию `stable_photo_id(dataset, path, root)`
(см. §8, перенос 🟢) — детерминированный идентификатор по относительному
пути файла, без привязки к mtime/порядку обхода директории.

---

## 3. Девять ракурсов и границы бакетов (источник истины)

Ракурс определяется исключительно по каноническому yaw (после исправления
знака оси, см. §4.2) и таблице диапазонов. Это должно быть вынесено в
конфиг-файл (аналог текущего `pipeline/pose_settings.json`), не хардкодиться:

| bucket | yaw min, ° | yaw max, ° |
|---|---|---|
| `left_profile` | -180 | -65 |
| `left_threequarter_deep` | -65 | -45 |
| `left_threequarter_mid` | -45 | -25 |
| `left_threequarter_light` | -25 | -10 |
| `frontal` | -10 | 10 |
| `right_threequarter_light` | 10 | 25 |
| `right_threequarter_mid` | 25 | 45 |
| `right_threequarter_deep` | 45 | 65 |
| `right_profile` | 65 | 180 |

Порядок проверки диапазонов — от узких (3/4) к широким (профиль), чтобы на
границе (напр. yaw=55 при `deep≤65` и `profile≥65`) не срабатывал первый
попавшийся ключ. Если ни один диапазон не подошёл (не должно случаться при
корректной таблице, но защитный случай) — `bucket = "unclassified"`.

**Left/right** соответствуют анатомически видимой щеке (какая половина лица
обращена к камере), а не знаку по учебным датасетам исходных моделей —
поэтому в реализации предусмотрен настраиваемый знак оси yaw (см. §4.2) с
явными, задокументированными константами (не через непрозрачные
env-переменные, как в текущем коде, а через типизированный enum/конфиг).

### 3.1 Гистерезис на границе бакетов

Если новый расчётный bucket отличается от `previous_bucket` только тем, что
пересёк границу `*_threequarter_deep` ↔ `*_profile`, а yaw находится в пределах
**6°** от этой границы (по модулю) — сохраняется `previous_bucket`. Это
устраняет дребезг классификации при повторных прогонах/пересчётах одного и
того же фото с чуть другой погрешностью детектора. Для первого прогона
(`previous_bucket=None`) гистерезис не применяется.

### 3.2 Коррекция ложного "профиля"

Если поза классифицирована как `*_profile`, но при этом:
- `pose_source` требует ручной проверки (`needs_manual_review=True` от HPE), и
- `|pitch| < 16°`, и
- `|roll| < 15°`,

— то это, как правило, ложное срабатывание HPE-модели на почти фронтальном
лице. Bucket переклассифицируется в `*_threequarter_deep` (той же стороны).

---

## 4. Пошаговый алгоритм (внутри одного фото)

### Шаг 0. Валидация входа

- Прочитать изображение (`cv2.imread`). Если не читается → **hard-reject**:
  `info.json` со `status="rejected"`, `reject_reason="unreadable_image"`, ни
  один из тяжёлых шагов (реконструкция, quality gate) не запускается.
- Проверить, что фото не входит в ручной exclusion-лист (`EXCLUDED_PHOTO_IDS`
  — список конкретных `photo_id`, заведомо непригодных для форензики,
  например с экстремальным освещением). Если входит → hard-reject с
  `reject_reason="manually_excluded"`, но артефакты (crop/thumb) всё равно
  сохраняются для UI-просмотра.

### Шаг 1. Определение позы головы (Pose Estimation)

Источник истины — **связка HPE → 3DDFA fallback**, единая функция
`resolve_pose(image_path, previous_bucket)`:

1. Запустить head-pose-estimation (SCRFD-детектор лица + mobilenetv3 pose
   regressor) на полном изображении.
   - Если детектор нашёл лицо и классифицировал ракурс (`bucket != unclassified`)
     → `pose_source = "head_pose"`, `needs_manual_review = False`,
     `pose_degraded = False`.
2. Если HPE не смог классифицировать ракурс (`hpe_bucket == "unclassified"`) —
   fallback на pose из 3DDFA_v3 (тот же forward pass, что и в Шаге 2, поэтому
   реализация должна кэшировать/переиспользовать эти вычисления, а не
   запускать 3DDFA дважды):
   - `pose_source = "3ddfa_v3"`, `needs_manual_review = True`,
     `pose_degraded = True`, `hpe_fallback_reason = "head_pose_unclassified"`.
3. Если и HPE, и 3DDFA не дали результата (лицо не найдено вообще) —
   `pose_source = "none"`, `bucket = "unclassified"`, `needs_manual_review =
   True`, `pose_degraded = True`. Фото не хард-реджектится автоматически —
   решение о полезности принимается позже по итоговому `readiness`
   (см. §4.6), но `usable_for_comparison = False`.
4. **Reconciliation (сверка) HPE vs 3DDFA**: если `pose_source == "head_pose"`
   и одновременно доступны углы из 3DDFA-реконструкции (Шаг 2 уже выполнен),
   сравнить `|yaw_hpe - yaw_3ddfa|`:
   - если разница **> 12°** ИЛИ bucket по 3DDFA отличается от bucket по HPE —
     итоговые pose и bucket берутся из 3DDFA (`pose_source =
     "3ddfa_v3_reconciled"`, `needs_manual_review = True`, `pose_degraded =
     True`, зафиксировать `pose_yaw_discrepancy_deg`).
   - иначе — остаётся результат HPE.
5. Знак оси yaw переводится в канонический через явную конфигурацию (не через
   env-переменные как сейчас): один знак для HPE-модели, отдельный — для
   3DDFA (эти модели обучены в разных конвенциях осей, инвертировать их
   молча одной и той же переменной запрещено — это источник скрытых багов
   типа "left/right перепутаны на части фото").

Итоговый объект `pose`:
```json
{
  "yaw": -46.2, "pitch": 3.1, "roll": -1.8,
  "bucket": "left_threequarter_deep",
  "pose_source": "head_pose | 3ddfa_v3 | 3ddfa_v3_reconciled | none",
  "needs_manual_review": false,
  "pose_degraded": false,
  "pose_yaw_discrepancy_deg": null,
  "raw_yaw_hpe_deg": -46.2,
  "raw_yaw_3ddfa_deg": -45.7
}
```

Если `bucket == "unclassified"` после всех fallback — это финальное
состояние, не ошибка выполнения: фото просто не будет участвовать в
попарном/групповом сравнении внутри ракурса (Этапы 2+), но артефакты для UI
сохраняются.

### Шаг 2. 3D-реконструкция лица (3DDFA_v3)

1. Проверить дисковый кэш реконструкции: `storage/{dataset}/{photo_id}/reconstruction_v1.pkl`.
   Инвалидация — по MD5-хэшу **пиксельного содержимого** файла (не mtime, не
   размера файла — устойчиво к копированию/переносу между дисками).
   - Cache hit → пропустить дорогостоящий forward pass, использовать
     сохранённую геометрию.
   - Cache miss → выполнить полную 3D-реконструкцию.
2. Реконструкция выполняется в режиме **с сохранением реальной мимики**
   (`neutral_expression=False`, `identity_only=False`) — усреднение до
   нейтрального выражения НЕ делается на этом этапе, экспрешн-параметры
   (`exp_params`) сохраняются как есть и используются в Шаге 5 только для
   классификации/исключения зон, а не для деформации самого меша.
3. Из выхода модели извлекаются:
   - `vertices_world`, `vertices_camera`, `vertices_image` (мировые/камерные/
     экранные координаты вершин);
   - `triangles`, `point_buffer` (топология меша);
   - `annotation_groups` (индексы вершин по анатомическим зонам из BFM);
   - `normals_world`, `normals_camera`;
   - `rotation_matrix`, `translation`, `angles_deg = [pitch, yaw, roll]`
     (порядок именно такой — частый источник багов при перепутывании);
   - `trans_params` (параметры обратного преобразования 224×224 crop →
     оригинальные координаты изображения);
   - `landmarks_106` (если модель их вернула — 106 антропометрических точек,
     используются для оценки качества реконструкции, см. §4.4);
   - `seg_visible` (8-канальная маска сегментации: right_eye, left_eye,
     right_eyebrow, left_eyebrow, nose, upper_lip, lower_lip, skin) —
     используется для построения `face_mask.png`;
   - `expression`: `{mouth_open_intensity, jaw_open_intensity, smile_intensity}`
     — вычисляются из первых трёх компонент exp-базиса модели (индексы 0, 1, 2).
4. Управление памятью: LRU-кэш реконструкций в оперативной памяти/VRAM с
   лимитом (по умолчанию 10 записей), явное освобождение тензоров и вызов
   `torch.cuda.empty_cache()`/`torch.mps.empty_cache()` при вытеснении записи
   из кэша — обязательное требование для overnight-прогонов на 1700+ фото без
   OOM. Раздельные кэш-ключи для `neutral_expression=True/False` и
   `identity_only=True/False` (это разные результаты реконструкции).
5. Сохранение на диск: `reconstruction_v1.pkl` (санитизированный payload без
   несериализуемых объектов типа raw torch-тензоров модели) + запись MD5-хэша
   исходного файла внутри пикла для последующей верификации при чтении.

### Шаг 3. Оценка доверия к реконструкции (Reconstruction Trust)

До того как реконструкция используется где-либо дальше, вычисляется
`trust_score ∈ [0,1]` и список `issues`:

| Компонент | Вес | Правило |
|---|---|---|
| `vertex_quality` | 0.35 | `vertex_count < 1000` → 0.3 (issue); `< 3000` → 0.6 (issue); иначе 1.0 |
| `transform_quality` | 0.30 | `trans_params` отсутствует → 0.0 (issue); scale вне `[0.3, 3.0]` → 0.5 (issue); иначе 1.0 |
| `pose_quality` | 0.15 | `1.0 - 0.55*yaw_penalty - 0.25*pitch_penalty`, где `yaw_penalty = min(|yaw|/yaw_limit, 1)`; `yaw_limit = 85°` если bucket ожидаемо не-фронтальный (light/mid/deep/profile), иначе `60°`; `pitch_penalty = min(|pitch|/45°, 1)`; минимум 0.15 |
| `reprojection_quality` | 0.20 | по `reprojection_rmse_px` (см. ниже): `>12px`→0.35 (issue), `>8px`→0.65 (issue), `>5px`→0.85, иначе 1.0 |

`trust_score = Σ(компонент × вес)`; затем штраф: если `len(issues) >= 2` →
`×0.7`, если `len(issues) >= 3` → `×0.5`.

`is_usable = trust_score > 0.4 AND vertex_quality > 0.3`.

**`reprojection_rmse_px`** — расстояние (px, RMSE) между 106
2D-ландмарками модели и ближайшими проекциями видимых вершин меша
(`vertices_image`, отфильтрованные по `visible_idx_renderer`), через KD-tree
nearest-neighbour (`scipy.spatial.cKDTree`). Если `landmarks_106`
недоступны или видимых вершин `< 100` — `None` (метрика не участвует в
trust_score, `reprojection_quality` считается нейтрально = 1.0).

Результат записывается в `info.json` как блок `reconstruction_trust` —
Этап 2 обязан проверять `is_usable` перед вычислением метрик и помечать
геометрию как `unavailable`, если `is_usable == False`.

### Шаг 4. Оценка технического качества изображения (Quality Gate)

Оценка проводится **на face-crop** (после Шага 6, см. переупорядочивание
ниже) либо на полном кадре, если bbox лица недоступен — но crop предпочтителен
(избегает искажения оценки фоном).

Вычисляемые величины:

- `blur_variance` = дисперсия Лапласиана (`cv2.Laplacian(gray, CV_64F).var()`).
- `motion_ratio` = `max(var(Sobel_x)/var(Sobel_y), var(Sobel_y)/var(Sobel_x))`;
  `is_motion_blurred = motion_ratio > 3.0 AND min(var_x, var_y) < 100.0`.
- `jpeg_blockiness` = отношение перепада яркости на границах JPEG-блоков 8×8 к
  перепаду внутри блока (grid-aligned относительно смещения crop). `> 1.35` →
  `is_jpeg_blocky = True`.
- `sharpness_score = clip(blur_variance / denom, 0, 1)`, где
  `denom = 400 * clip(min_face_dim/224, 0.35, 2.5)` — нормировка резкости под
  реальный размер лица в кадре (архивные фото ~200px vs современные 4K crop).
  Штрафы: `×0.5` при `is_motion_blurred`, `×0.7` при `is_jpeg_blocky`.
- `noise_level` = `mean(|gray - medianBlur(gray, 3)|)`;
  `noise_quality = clip(1 - noise_level/25, 0, 1)`.
- `is_over_smoothed` = `sharpness_score > 0.88 AND noise_quality > 0.82 AND
  jpeg_blockiness < 1.08 AND NOT is_motion_blurred` — признак "подозрительно
  гладкой" кожи (потенциальный силикон/дипфейк).
  **Важное архитектурное решение ТЗ**: `is_over_smoothed = True` **не
  является причиной reject**. Пайплайн не должен отбрасывать
  "слишком гладкие" лица как брак — иначе система систематически теряет
  именно те кадры, которые нужно проверить на силикон гипотезой ТЗ. Штраф
  `×0.72` на sharpness применяется только для расчёта `overall_score`, но не
  блокирует прохождение дальше.
- `overall_score = (sharpness_score*0.7 + noise_quality*0.3) * penalty`, где
  `penalty = 0.75` если `is_over_smoothed`, иначе `1.0`.

**Единственные условия hard-reject на этом шаге**:
- изображение не читается (см. Шаг 0);
- размер лица (bbox) `< 120px` по любой стороне → `reject_reason =
  "face_too_small"`.

`is_motion_blurred` **не используется как reject** в проде (сознательное
решение — реальное фотодвижение старых архивных снимков не должно
автоматически выкидывать кадр из выборки), но записывается как флаг для
Этапа 2/downstream-фильтров, которые могут учитывать его точечно.

### Шаг 5. Экспрешн-флаги (мимика)

Из `exp_params` реконструкции (Шаг 2) вычисляются:

```
jaw_open_intensity = |exp_params[0]|
smile_intensity   = max(|exp_params[1]|, |exp_params[2]|)
```

Пороги исключения (калиброваны по датасету, фиксировать как конфиг-константы,
не хардкод в разных местах кода):

```
THRESHOLD_JAW_OPEN = 0.70
THRESHOLD_SMILE    = 2.2
```

Флаги:
```
jaw_excluded   = jaw_open_intensity > THRESHOLD_JAW_OPEN
smile_excluded = smile_intensity   > THRESHOLD_SMILE
```

Эти флаги **не исключают фото целиком** — они лишь фиксируются в `info.json`
как метаданные, чтобы Этап 2 мог динамически исключать конкретные зоны
(рот/челюсть при `jaw_excluded`; мягкие ткани щёк/носогубные при
`smile_excluded`) из геометрического сравнения, оставляя фото пригодным для
всех остальных метрик — ровно так, как описано в ТЗ платформы ("исключать
шум мимики, не теряя фото для остальных анализов").

Соответствие зона↔флаг (для справки Этапу 2, сама логика исключения зон —
уже вне Этапа 1):
- `jaw_excluded` → зоны `chin, jaw_L, jaw_R, jaw_angle_L, jaw_angle_R,
  upper_lip, lower_lip` временно не участвуют в геометрическом сравнении.
- `smile_excluded` → зоны `cheek_soft_L, cheek_soft_R, ligament_zygomatic_L,
  ligament_zygomatic_R, nose_wing_L, nose_wing_R` временно исключаются.

### Шаг 6. Расчёт видимости (Visibility / Z-buffer)

Для каждой вершины меша вычисляется бинарная маска видимости
(`compute_visibility`):

1. Косинус угла между нормалью вершины в камерных координатах и направлением
   на камеру: `cos_theta = normals_camera[:, 2]` (конвенция 3DDFA: положительная
   Z-компонента нормали = вершина обращена к камере).
2. Угол `> 82°` → вершина невидима (`VISIBILITY_ANGLE_DEG = 82.0`).
3. Дополнительно пересекается с маской видимости от рендерера модели
   (`visible_idx`), если она доступна и по форме совместима — иначе
   фиксируется `trust_issue` (`visible_mask_missing_from_renderer` или
   `visible_mask_shape_mismatch`) для аудита, но не блокирует пайплайн.
4. Финальная маска дополнительно отфильтровывает вершины с
   не-конечными (`NaN`/`Inf`) нормалями.

Результат — `VisibilityResult{binary_mask, cosine_weights, facing_cosines,
visible_count}`, сохраняется как часть `reconstruction_v1.pkl` (не
дублируется в `info.json` — слишком объёмно для лёгкого JSON).

### Шаг 7. Канон-выравнивание внутри ракурса (ключевой шаг твоей идеи)

Цель: любые два фото одного и того же bucket (например, оба
`left_threequarter_mid`) после этого шага должны быть в одной и той же
системе координат головы, отличаясь только реальной геометрией лица, а не
случайным наклоном головы во время съёмки.

Алгоритм `canonicalize_vertices_for_bucket(vertices, angles_deg, view_group,
rotation_matrix_applied)`:

1. Взять целевой yaw для данного bucket из таблицы канонических углов
   (центр диапазона bucket, см. таблицу ниже) — pitch и roll в
   канон-положении полагаются равными **0°** для одиночного фото (не
   среднее по паре — это разница с pairwise-выравниванием, которое находится
   уже в Этапе 4).

   ```
   frontal:                    0.0°
   left_threequarter_light:  -22.5°   right_threequarter_light:  22.5°
   left_threequarter_mid:    -45.0°   right_threequarter_mid:    45.0°
   left_threequarter_deep:   -67.5°   right_threequarter_deep:   67.5°
   left_profile:             -90.0°   right_profile:             90.0°
   ```

2. Построить матрицу вращения фактической позы `R_cur` — либо напрямую из
   `rotation_matrix` реконструкции (`rotation_matrix_applied`, точнее, т.к.
   это реальная матрица, применённая моделью), либо (fallback) из
   Эйлеровых углов `angles_deg` через `R = Rz(roll) @ Ry(yaw) @ Rx(pitch)`
   (конвенция 3DDFA: `[pitch, yaw, roll]`, транспонированная под
   `vertices @ R`, т.к. модель применяет `pts @ R`, а не `R @ pts`).
3. Построить целевую матрицу `R_target` для `[pitch=0, yaw=target_yaw,
   roll=0]`.
4. Вычислить `R_align = R_cur.T @ R_target`.
5. Центрировать меш по центроиду и применить: `vertices_canon = (vertices -
   centroid) @ R_align + centroid`.

Результат — `vertices_canon` (тот самый "канонический" меш внутри ракурса,
на котором в Этапе 2 будут считаться геометрические метрики) — сохраняется
как отдельный массив в `reconstruction_v1.pkl` (или пересчитывается на лету
в Этапе 2 из сырых углов + `rotation_matrix`, если экономия места важнее —
решение по месту, но алгоритм зафиксирован здесь).

**Важно**: масштабирование (scale-fitting) на этом шаге запрещено — канон-
выравнивание не должно менять размер лица, иначе искажается вся
антропометрия, которая должна оставаться в оригинальных пропорциях каждого
конкретного человека на конкретном фото. Только чистое вращение вокруг
центроида.

### Шаг 8. Построение `face_mask.png` (кроп кожи с альфа-каналом)

1. Взять `seg_visible` (8-канальная маска 224×224 из реконструкции).
   `skin_channel = max(seg_visible[...,7] (skin), seg_visible[...,4] (nose))`
   — нос сохраняется отдельно, чтобы не образовывать дыру в центре лица.
2. Построить маску исключения:
   `excluded = max(right_eye, left_eye, right_eyebrow, left_eyebrow,
   upper_lip, lower_lip)` (каналы 0,1,2,3,5,6).
3. Мягкое вычитание через сигмоиду:
   `skin *= (1 - sigmoid(10 * (excluded - 0.5)))` — плавные, не рубленые
   края маски (важно, чтобы швы силиконовой маски на границах не
   обрезались артефактно, ровно то, о чём просит форензик-задача).
4. Спроецировать маску 224×224 обратно в координаты оригинального
   изображения через `trans_params` (тот же обратный трансформ, что
   использует сама 3DDFA-модель — не своя отдельная формула, чтобы не
   рассинхронизироваться с `vertices_2d`).
5. Морфологическое закрытие (`MORPH_CLOSE`, ellipse 5×5) для устранения
   мелких дыр без разрушения формы маски.
6. **Важно (уже зафиксированное архитектурное решение форензик-режима)**: не
   применять жёсткий YCrCb skin-color фильтр поверх маски сегментации —
   он ложно вырезает настоящую кожу при необычном освещении (архивные фото
   со специфической цветопередачей). Доверять непосредственно выходу
   сегментации модели.
7. Найти bounding box маски (порог бинаризации 10/255 для отсечения слабых
   хвостов). Если маска пуста (`coords is None`) → `face_mask` не строится,
   `face_mask_path = null` в `info.json`, `readiness.texture = "unavailable"`.
8. Расширить bbox на 25% с каждой стороны (`*1.25`), привести к целевому
   аспекту `FACE_CROP_WIDTH/FACE_CROP_HEIGHT = 424/500`, вырезать регион (с
   защитой от выхода за границы кадра — сдвиг окна внутрь, не изменение
   аспекта).
9. Letterbox-resize кропа и маски до `424×500` **без искажения пропорций**
   (чёрные поля по краям при необходимости, не squeeze/stretch) —
   обязательное требование, зафиксированное существующим unit-тестом
   (`test_face_crop_letterbox.py`).
10. Сохранить:
    - `face_mask.png` — RGBA, альфа-канал = построенная маска кожи;
    - `face_crop.jpg` — тот же BGR-кроп без альфа-канала, JPEG quality 95,
      для UI-превью/thumbnail (не для текстурного анализа).

### Шаг 9. Извлечение `mesh.obj`

Экспорт `vertices_world` + `triangles` (+ материал-заглушка `mesh.mtl`) в
формате OBJ — независимый от остальной геометрии артефакт, используется
напрямую в Этапе 4 (попарное ICP-сравнение) без необходимости распаковывать
`reconstruction_v1.pkl`.

### Шаг 10. Thumbnail

Уменьшенная копия исходника (напр. по ширине 320px, формат JPEG) для
быстрого листинга в UI — генерация тривиальна, существующий код переносится
без изменений.

### Шаг 11. Дата и возраст на момент съёмки

1. Распарсить дату из имени файла (`parse_date_from_name`) — паттерны
   `YYYY_MM_DD`, `YYYY-MM-DD`, `YYYYMMDD`, либо только `YYYY` (тогда
   `01-01` этого года). Если не распарсилось — `fallback_date_for_file`
   (mtime файла) и явный флаг `date_is_fallback = true` в `info.json` (это
   обязано быть видно на всех последующих этапах, особенно в Этапе 5
   Chronology — приблизительная дата не должна тихо считаться точной).
2. Вычислить возраст субъекта на дату съёмки:
   `age = photo_date.year - birth_date.year`, минус 1, если
   `(month, day)_photo < (month, day)_birth`. Дата рождения субъекта — явная
   конфигурационная константа (не хардкод внутри функции), переопределяемая
   через переменную окружения/конфиг на случай смены объекта расследования.

---

## 5. Обработка калибровочного датасета (`dataset == "calibration"`)

Отличия от `main`:

- Имя файла калибровочного фото содержит явную метку углов
  (`calibration_y-10p4r0.jpg` = yaw −10, pitch 4, roll 0), проставленную
  тобой вручную при съёмке.
- Эта метка **используется только как diagnostic/QA-подсказка** (например,
  для выбора "по одному JPEG на каждый из 9 ракурсов" в smoke-тестах или для
  обнаружения грубого рассинхрона pose-детектора), но не как источник
  итоговой позы в `info.json` — итоговая поза калибровочного фото вычисляется
  ровно тем же путём HPE→3DDFA, что и для main, иначе калибровочная модель
  шума будет предвзятой (натренированной на "заявленных", а не на реально
  измеренных теми же алгоритмами углах).
- Во всём остальном (реконструкция, канон-выравнивание, visibility, маска,
  quality gate, экспрешн-флаги) алгоритм идентичен main.

---

## 6. Контракт `info.json` (обязательная схема)

```jsonc
{
  "schema_version": "1.0",
  "photo_id": "main-2001_03_23-<hash8>",
  "dataset": "main",
  "source_filename": "2001_03_23.jpg",
  "processed_at": "2026-07-07T09:12:33Z",

  "status": "ready | needs_review | rejected",
  "reject_reason": null,

  "date": {
    "iso_date": "2001-03-23",
    "is_fallback": false,
    "subject_age_years": 48
  },

  "pose": {
    "yaw": -46.2, "pitch": 3.1, "roll": -1.8,
    "bucket": "left_threequarter_deep",
    "pose_source": "3ddfa_v3_reconciled",
    "needs_manual_review": true,
    "pose_degraded": true,
    "pose_yaw_discrepancy_deg": 14.7,
    "raw_yaw_hpe_deg": -31.5,
    "raw_yaw_3ddfa_deg": -46.2
  },

  "reconstruction": {
    "cache_path": "reconstruction_v1.pkl",
    "mesh_path": "mesh.obj",
    "vertex_count": 35709,
    "trust_score": 0.81,
    "is_usable": true,
    "issues": [],
    "reprojection_rmse_px": 3.2
  },

  "quality": {
    "overall_score": 0.72,
    "blur_variance": 148.0,
    "noise_level": 4.1,
    "jpeg_blockiness": 1.02,
    "is_motion_blurred": false,
    "is_jpeg_blocky": false,
    "is_over_smoothed": false,
    "quality_scope": "face_crop"
  },

  "expression": {
    "jaw_open_intensity": 0.12,
    "smile_intensity": 0.85,
    "jaw_excluded": false,
    "smile_excluded": false
  },

  "visibility": {
    "visible_vertex_count": 21344,
    "visible_ratio": 0.598,
    "trust_issue": null
  },

  "artifacts": {
    "face_mask": "face_mask.png",
    "face_crop": "face_crop.jpg",
    "thumb": "thumb.jpg",
    "original": "2001_03_23.jpg"
  },

  "readiness": {
    "geometry": "ready | low | unavailable",
    "texture": "ready | low | unavailable | rejected",
    "usable_for_comparison": true
  }
}
```

Правила заполнения `status`:
- `"rejected"` — только для случаев из Шага 0/Шага 4 (нечитаемое фото,
  слишком маленькое лицо, ручной exclusion-лист). `reconstruction`,
  `pose`, `visibility` в этом случае — `null`/пустые объекты, но
  `artifacts.thumb` всё равно генерируется, если изображение технически
  читается (для UI).
- `"needs_review"` — фото прошло весь пайплайн, но
  `reconstruction.is_usable == false` ИЛИ `pose.bucket == "unclassified"` ИЛИ
  `quality.overall_score < 0.4`.
- `"ready"` — во всех остальных случаях.

`readiness.usable_for_comparison = True` только если ОДНОВРЕМЕННО:
`status != "rejected"`, `reconstruction.is_usable == true`,
`pose.bucket != "unclassified"`.

---

## 7. Ошибки и границы отказоустойчивости

| Ситуация | Поведение |
|---|---|
| Файл не читается | hard-reject, `info.json` с минимальными полями, шаг завершается за миллисекунды |
| Лицо не найдено ни HPE, ни детектором 3DDFA | `pose.bucket = "unclassified"`, `pose.pose_source = "none"`, реконструкция НЕ выполняется (нет смысла — детектор 3DDFA тоже не найдёт лицо), `status = "needs_review"` |
| 3DDFA нашла лицо, но HPE — нет | штатный fallback-путь, `pose_source = "3ddfa_v3"` |
| `trans_params` отсутствует после реконструкции | `face_mask` не строится (`Шаг 8` пропускается), `readiness.texture = "unavailable"`, geometry всё ещё может быть usable |
| Реконструкция падает с исключением (OOM/детектор) | явный `try/except` вокруг всего Шага 2 с гарантированной очисткой VRAM (`torch.cuda.empty_cache()`), `status = "needs_review"`, `reconstruction.is_usable = false`, `issues = ["reconstruction_failed: <сообщение>"]`, пайплайн продолжает Шаг 4 (quality gate по полному кадру) — фото не теряется полностью, только помечается неготовым для геометрии |
| Кэш реконструкции повреждён / MD5 не совпадает | инвалидировать кэш, выполнить полный forward pass заново, залогировать событие |
| `face_mask` пуст (сегментация не нашла кожу) | `status="needs_review"`, `readiness.texture="unavailable"`, `face_mask` в артефактах = `null` |

Ни одна ошибка одного фото не должна прерывать батч-обработку остальных фото
(overnight-режим на 1700+ фото) — все исключения ловятся на уровне
per-photo обработчика, логируются с `photo_id`, и обработка продолжается со
следующего файла.

---

## 8. Карта переноса кода (что брать из текущего backend)

| Модуль/функция | Действие | Примечание |
|---|---|---|
| `pipeline/reconstruction.py` (`ReconstructionAdapter`, MD5-кэш, `resolve_reconstruction`) | Перенести как есть | Ядро Шага 2 и управления VRAM |
| `pipeline/alignment.py` (`canonicalize_vertices_for_bucket`, `euler_to_rotation_matrix*`, `CANONICAL_YAW_BY_VIEW_GROUP`) | Перенести как есть | Ядро Шага 7 |
| `pipeline/alignment.py` (`rigid_umeyama_robust`, `align_and_score_gpa`) | Не переносить | Дублирует `rigid_umeyama`, помечено как legacy/неиспользуемое в Этапе 1 |
| `pipeline/visibility.py` (`compute_software_zbuffer_mask`, `compute_visibility`) | Перенести как есть | Ядро Шага 6 |
| `pipeline/pose_gate.py` | Перенести как есть | Не используется напрямую в Этапе 1 (нужен для Этапа 3/4 pose-distance), но зависимость общая — держать в общем пакете `pose/` |
| `pipeline/detect_pose.py`, `core/head_pose.py`, `core/capture_pose.py` | Объединить в один модуль `pose/estimator.py` | Убрать дублирование, заменить env-переменные знаков осей на явный конфиг/enum |
| `pipeline/quality_gate.py` (`QualityGate.evaluate`, `_jpeg_blockiness_score`, `_laplacian_sharpness_denominator`) | Перенести как есть, вынести `is_rejected`-поведение под явный конфиг-флаг | Реализует Шаг 4; убрать разрозненные `[FORENSIC PATCH]`-комментарии, свести в один документированный флаг `reject_smooth_faces: bool = False` |
| `pipeline/zones.py` (`apply_expression_exclusion_mask`, `THRESHOLD_JAW_OPEN`, `THRESHOLD_SMILE`) | Перенести константы и функцию вычисления флагов (без применения к зонам — это Этап 2) | Источник для Шага 5 |
| `core/analysis.py: _assess_reconstruction_trust` | Перенести как отдельную функцию `pose_prep/trust.py` | Реализует Шаг 3, сейчас погребена внутри монолитного `extract_photo_bundle` |
| `core/uncertainty.py: compute_reprojection_rmse_px` | Перенести как есть | Используется в Шаге 3 |
| `core/analysis.py: _save_face_crop` | Перенести, разбив на подфункции (build_skin_mask / project_to_original / crop_and_letterbox / save) | Реализует Шаг 8; сейчас 100-строчная функция делает всё сразу |
| `core/analysis.py: _resize_letterbox`, `_resize_letterbox_gray` | Перенести как есть | Уже покрыты тестом `test_face_crop_letterbox.py` |
| `core/analysis.py: _resolve_extract_pose` | Переписать как чистую функцию `resolve_pose()` без побочных зависимостей от `runtime`/`LegacyRuntime` | Реализует весь Шаг 1 целиком, но нужно вырезать из монолита и явно типизировать вход/выход |
| `core/utils.py: classify_pose_bucket`, `classify_pose_bucket_from_yaw_ranges`, `_apply_pose_bucket_hysteresis`, `load_pose_yaw_ranges` | Перенести как есть | Реализует §3 |
| `pipeline/pose_settings.json` | Перенести как есть (конфиг) | Таблица диапазонов ракурсов |
| `core/policy.py: POSE_YAW_RECONCILE_DEG = 12.0` | Перенести как конфиг-константу | Используется в Шаге 1.4 |
| `core/utils.py: parse_date_from_name`, `fallback_date_for_file`, `subject_age_years_at`, `stable_photo_id` | Перенести как есть | Реализует Шаг 11 и §2.3 |
| `core/constants.py: SUBJECT_BIRTH_DATE, VISIBILITY_ANGLE_DEG, EXCLUDED_PHOTO_IDS` | Перенести как конфиг | Не хардкодить в коде |
| `pipeline/mesh_units.py` | Перенести как есть | Константы перевода единиц, нужны, чтобы не потерять масштаб при экспорте mesh.obj |
| `pipeline/types.py` (`ReconstructionResult`, `VisibilityResult`, `AlignmentResult`) | Перенести как есть, использовать как базовые датаклассы контракта | Хорошо спроектированы, включая `__eq__`/`__hash__` для тестируемости |
| `tests/test_pose_gate.py`, `tests/test_face_crop_letterbox.py`, `tests/test_reprojection_rmse.py`, `tests/test_pose_no_filename_smoke.py`, `tests/test_quality_gate_reject.py` | Перенести как есть, расширить | Готовый тестовый фундамент для Этапа 1, включая набор фикстур calibration JPEG по каждому из 9 ракурсов |

**Не переносить в Этап 1**: всё, что сейчас понатыкано в `core/analysis.py`
после Шага 8 (текстурный анализ, geometry metrics, verdict, mask_anomaly,
UV-генерация для blemish-tracking) — это Этап 2+ по границе, зафиксированной
в `REFACTOR_PLAN.md`.

---

## 9. Критерии приёмки (Definition of Done)

1. На тестовом наборе из 9 калибровочных JPEG (по одному на каждый bucket,
   см. `BUCKET_CALIB_SAMPLES` в `tests/test_pose_no_filename_smoke.py`)
   каждый файл получает корректный `pose.bucket`, совпадающий с ожидаемым
   (с учётом ручной калибровочной метки как ground truth только для теста,
   не для прод-пути).
2. Ни для одного `pose_source` в выходе `info.json` не встречается значение
   `"filename"` или `"fallback"` — поза main-датасета никогда не берётся из
   имени файла (регрессионный тест уже существует, переносится как есть).
3. `face_mask.png` для контрольного набора из 20 разноракурсных фото не
   искажён по аспекту (letterbox тест проходит) и не имеет "прямых" резких
   границ на стыке кожа/фон (визуальная проверка + тест на плавность
   градиента альфа-канала).
4. Полный прогон 1775 main + 224 calibration фото завершается без падения
   процесса; количество `reconstruction_v1.pkl` файлов после прогона равно
   количеству входных файлов минус hard-reject; ни один photo_id не приводит
   к необработанному исключению, прерывающему батч.
5. Повторный запуск того же батча (resume/idempotency) — при наличии
   валидного `reconstruction_v1.pkl` (MD5 совпадает) реконструкция не
   пересчитывается повторно (проверяется по времени выполнения второго
   прогона — должно быть на порядок быстрее первого).
6. `info.json` каждого обработанного фото проходит валидацию по JSON Schema,
   соответствующей структуре §6 (обязательные поля присутствуют, типы
   совпадают).
7. Для случайной выборки 30 фото из разных десятилетий (1999–2025) —
   `subject_age_years` в `info.json` совпадает с ручным расчётом по дате
   рождения субъекта и дате фото (unit-тест на функцию, не требует полного
   пайплайна).
8. Reprojection RMSE тест (`test_reprojection_rmse.py`) проходит без
   регрессии — защита от повторного появления бага со случайной
   subsampling-инфляцией ошибки.

---

## 10. Тест-план

### 10.1 Юнит-тесты (переносятся + расширяются)
- `classify_pose_bucket_from_yaw_ranges` — граничные значения на каждой
  границе таблицы §3 (±0.01° по обе стороны).
- `_apply_pose_bucket_hysteresis` — сценарий дребезга на границе
  deep/profile.
- `_resize_letterbox`/`_resize_letterbox_gray` — уже покрыто, оставить.
- `compute_reprojection_rmse_px` — уже покрыто (bool vs int visibility
  mask), оставить.
- `subject_age_years_at` — граничные даты (день рождения ровно в дату
  фото, день до/после).
- `parse_date_from_name` — все 4 паттерна + невалидные имена.
- Новое: `resolve_pose()` — параметризованный тест на все ветки fallback
  (HPE ok / HPE unclassified→3DDFA / оба none / reconciliation triggered).

### 10.2 Интеграционные тесты
- Полный Шаг 0→11 на 9 калибровочных JPEG — уже частично оформлено в
  `test_pose_no_filename_smoke.py`, расширить до полного `info.json`.
- Прогон на "плохом" фото (искусственно зашумлённое/размытое старое фото
  1999 года) — убедиться, что `is_over_smoothed=False`,
  `overall_score` низкий, но фото не хард-реджектится, `status=needs_review`
  максимум.
- Прогон на "подозрительно гладком" синтетическом фото (blur variance
  искусственно повышена + noise занижен) — убедиться, что
  `is_over_smoothed=True`, но фото **проходит** дальше по пайплайну (не
  reject).

### 10.3 Регрессионные/нагрузочные
- Полный батч 1775+224 фото, замер времени, отсутствие падений, отсутствие
  утечек VRAM (мониторинг `nvidia-smi`/`torch.cuda.memory_allocated()` в
  течение прогона — не должно расти монотонно).
- Повторный batch (resume) — время выполнения на порядок меньше первого
  прогона за счёт кэш-хитов.

---

## 11. Что явно НЕ входит в Этап 1 (граница ответственности)

- Любые геометрические метрики идентичности (расстояния, углы, зоны) —
  Этап 2.
- Любой текстурный анализ поверх `face_mask.png` (GLCM/LBP/FFT/silicone
  prob) — Этап 2.
- Построение калибровочной модели шума по калибровочному датасету — Этап 3
  (Этап 1 лишь готовит одинаково подготовленные артефакты и для main, и для
  calibration, дальнейшее сравнение между ними — не его забота).
- Попарное сравнение фото друг с другом (ICP, mesh evidence) — Этап 4.
- Любой вердикт "силикон/живая кожа" — Этап 4.
- Байесовский вывод, хронологический анализ, отчётность — Этапы 5-6.

---

## 12. Правки из аудита аналитиков (консолидированный беклог, applicable к Этапу 1)

### 12.1 🔴 П1-03: Рассинхрон координатных пространств
**Что**: Метрики считаются в разных пространствах (raw/canon_bucket/shape_neutral) без явной приведения.
**Как**: Ввести типизацию мешей (атрибут `.space`). Все меш после канон-выравнивания получают `space='canonical'`. Этап 2 принимает **только** меш с `space='canonical'`. Валидация на входе: если `.space != 'canonical'` — reject.

### 12.2 🔴 П1-04 (часть позы): Дублирование логики позы
**Что**: Поза считается в 3 местах (detect_pose.py, head_pose.py, capture_pose.py).
**Как**: Свести в один модуль `pose/estimator.py` с единым API `estimate_pose(image) → PoseResult(yaw, pitch, roll, bucket)`. Остальные файлы удалить.

### 12.3 🟡 П2-08: Quality Gate / DCS (Data Confidence Score)
**Что**: Система обрабатывает плохие фото (низкое разрешение, шум), создавая ложные срабатывания.
**Как**: На Этапе 1 рассчитывать `dcs` (Data Confidence Score) на основе:
- `resolution_score`: расстояние между зрачками > 35 px
- `sharpness_score`: дисперсия Лапласиана
- `lighting_score`: гистограмма без clip (> 245 в канале V)
- `is_over_smoothed`: флаг пересвета/шума
Если `dcs.overall < threshold` — фото помечается `status=needs_review`, но **не отсеивается** (для ручной проверки). Метрики с низким DCS получают пониженный вес на Этапе 4.

### 12.4 🟡 П2-09: Жёсткие Якоря (Rigid Anchors) вместо мягких тканей
**Что**: Щёки/губы используются при выравнивании, внося ошибку при пластике/мимике.
**Как**: Выделить «Жёсткие Якоря» — зоны черепа, которые **никогда** не меняются после 25 лет:
- Орбиты глаз (orbit_left, orbit_right)
- Переносица (nasal_bridge)
- Основание скул (zygomatic_arch)
Эти зоны используются **только** для фиксации системы координат (ICP/Procrustes). Мягкие ткани (губы, щёки, подбородок) **исключаются** из выравнивания при `smile_detected=True` или `jaw_open_detected=True`.

### 12.5 🟡 П2-13 (часть): Evidence Log — Stage 1 output
**Что**: Отсутствует аудиторский след на Этапе 1.
**Как**: На выходе Этапа 1, помимо `info.json` и `face_mask.png`, сохранять `evidence_stage1.json`:
```json
{
  "photo_id": "...",
  "dcs": {"overall": 0.85, "resolution": 0.9, "sharpness": 0.85, "lighting": 0.8},
  "pose": {"yaw": 1.2, "pitch": -0.5, "roll": 0.1, "bucket": "frontal"},
  "reconstruction": {"alignment_error": 0.08, "vram_cache_hit": true},
  "anchors": {"intercanthal_dist": 32.1, "nasal_bridge_height": 15.4},
  "rigid_anchor_validation": "PASS"
}
```
