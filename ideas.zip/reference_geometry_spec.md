# reference_geometry.json — Спецификация

## Назначение

`reference_geometry.json` — эталонный файл Stage 3 (CALIBRATION) для геометрической части персональной идентификации PUT/UDMURT/VAS.
На выходе — когорты, пороги, aging траектории и cross-center модель.

---

## Структура (Pydantic-like)

```json
{
  "version": "string",
  "built_at": "ISO8601",
  "n_calibration_samples": int,

  "cohorts": {
    "PUT": {
      "description": "Real person (Vladimir Putin), natural aging",
      "n": 1912,
      "year_range": [1998, 2026],
      "buckets": ["frontal", "right_3/4", ... Həm ...]
    },
    "UDMURT": {
      "description": "Double #1 (similar person, silicone, 2012-2021)",
      "n": 41,
      "year_range": [2012, 2021]
    },
    "VAS": {
      "description": "Double #2 (silicone mask, 2023-2026)",
      "n": 39,
      "year_range": [2023, 2026]
    }
  },

  "thresholds": {
    "<metric_name>": {
      "threshold": float,
      "operator": ">" | "<",
      "direction": "DOUBLE_if_above" | "NOT_PUT_if_below" | ...,
      "confidence": float,
      "source_rakurs": string  // из какого ракурса работает лучше всего
    }
  },

  "aging_trajectory": {
    "PUT": {
      "<year_lo>-<year_hi>": {
        "<metric_name>": {"mean": float, "std": float, "n": int}
      }
    }
  },

  "cross_center": {
    "center_entity": "PUT",
    "center_mass": 1912,
    "distances": {
      "UDMURT_from_PUT": {"mahalanobis": 2.3, "euclidean": 0.45},
      "VAS_from_PUT": {"mahalanobis": 3.8, "euclidean": 0.72}
    },
    "outlier_threshold_sigma": 2.0
  }
}
```

---

## Поля

### `cohorts`

Для каждой персоны — статистики и метаданные.

| Поле | Назначение |
|---|---|
| `n` | Количество фото в когорте |
| `year_range` | Диапазон лет (для aging model validation) |
| `buckets` | Bucket/rakurs coverage |

### `thresholds`

Критические пороги (zero-error rules) для каждой метрики.

| Поле | Назначение |
|---|---|
| `threshold` | Численный порог |
| `operator` | "\u003e" или "\u003c" (направление rule) |
| `direction` | Что означает crossing threshold |
| `confidence` | Accuracy этого порога |
| `rakurs` | Оптимальный ракурс |

### `aging_trajectory`

Возрастная динамика PUT (естественное старение).

| Поле | Назначение |
|---|---|
| `mean` | Ожидаемое значение для данного year_range |
| `std` | Стандартное отклонение |
| `n` | Число образцов в данном диапазоне |

---

## Требования

1. **version** — строка "MAJOR.MINOR"
2. **n_calibration_samples** > 0 для всех cohorts
3. **thresholds** — все ключевые 10 метрик должны иметь пороги
4. **aging_trajectory** — перекрытие по годам с PUT cohort

---

## Пример (minimized)

```json
{
  "version": "1.0",
  "built_at": "2026-07-07T04:00:00Z",
  "n_calibration_samples": {"PUT": 1912, "UDMURT": 41, "VAS": 39},
  "cohorts": {...},
  "thresholds": {
    "cheekbone_R_normal_mean_y": {
      "threshold": 0.048, "operator": "\u003e", "direction": "DOUBLE_if_above",
      "confidence": 0.999, "rakurs": "frontal"
    },
    "orbit_R_bbox_volume_ratio": {
      "threshold": 0.001, "operator": "\u003c", "direction": "NOT_PUT_if_below",
      "confidence": 0.960, "rakurs": "frontal"
    }
  },
  "aging_trajectory": {
    "PUT": {
      "1998-2005": {"cheekbone_R_normal_mean_y": {"mean": 0.014, "std": 0.003}},
      "2006-2013": {"cheekbone_R_normal_mean_y": {"mean": 0.024, "std": 0.003}},
      "2014-2026": {"cheekbone_R_normal_mean_y": {"mean": 0.032, "std": 0.003}}
    }
  }
}
```