# s6_report — ТЗ и шаблон отчёта

> **Цель модуля:** Собрать максимальную выжимку из всех этапов в один структурированный отчёт.
> **Не делает:** Не создаёт публикации (это s7). Не принимает решений (это s5).
> **Формат:** JSON (машиночитаемый) + CSV (таблицы) + Markdown (человекочитаемый).

---

## 1. Структура папки

```
s6_report/
├── output/
│   ├── report.json                 ← основной отчёт (машиночитаемый)
│   ├── report.md                   ← отчёт для человека (Markdown)
│   ├── timeline.csv                ← таймлайн (таблица)
│   ├── verdicts.csv                ← все вердикты (таблица)
│   ├── anomalies.csv               ← все аномалии (таблица)
│   ├── statistics.json             ← статистика
│   └── evidence_chains.json        ← цепочки доказательств
│
├── modules/
│   ├── build_report.py             ← сборка отчёта
│   ├── build_timeline.py           ← построение таймлайна
│   ├── build_statistics.py         ← расчёт статистики
│   ├── build_evidence_chains.py    ← сбор цепочек доказательств
│   ├── format_markdown.py          ← форматирование в Markdown
│   ├── engine.py                   ← главный движок
│   └── schemas.py                  ← Pydantic-схемы
│
├── configs/
│   ├── s6_config.yaml              ← основной конфиг
│   └── report_template.yaml        ← шаблон отчёта
│
├── tests/
│   └── test_build_report.py
│
└── test_ui/
    ├── app.py
    └── pages/
        ├── 1_preview.py            ← предпросмотр отчёта
        └── 2_statistics.py         ← статистика
```

---

## 2. Шаблон report.json

```json
{
  "meta": {
    "report_id": "NEWWAP_2026_07_07",
    "generated_at": "2026-07-07T12:00:00Z",
    "pipeline_version": "2.0",
    "analyst": "NEWWAP Pipeline",
    "description": "Форензик-отчёт по анализу 1712 фото В.В. Путина (1998-2026) на предмет двойников"
  },

  "dataset": {
    "total_photos": 1712,
    "analyzed": 1520,
    "excluded_by_quality": 192,
    "excluded_by_pose": 0,
    "coverage_percent": 88.8,
    "date_range": {
      "first": "1998-01-15",
      "last": "2026-06-20",
      "years": 28
    },
    "poses": ["frontal", "left_3/4_light", "left_3/4_mid", "left_3/4_deep", "right_3/4_light", "right_3/4_mid", "right_3/4_deep", "profile"],
    "epochs": {
      "legacy": {"count": 520, "description": "1998-2014 (плёнка, низкое разрешение)"},
      "recent": {"count": 1192, "description": "2015-2026 (цифра, высокое разрешение)"}
    }
  },

  "executive_summary": {
    "verdicts": {
      "H0_SAME": {
        "count": 1180,
        "percent": 77.6,
        "description": "Один и тот же человек (живая кожа, естественное старение)"
      },
      "H1_SYNTHETIC": {
        "count": 195,
        "percent": 12.8,
        "description": "Силиконовая маска на похожем черепе"
      },
      "H2_DIFFERENT": {
        "count": 145,
        "percent": 9.5,
        "description": "Разные люди (двойник)"
      },
      "H_UNCERTAIN": {
        "count": 0,
        "percent": 0.0,
        "description": "Недостаточно данных для вердикта"
      }
    },
    "confidence": {
      "average": 0.84,
      "min": 0.41,
      "max": 0.99,
      "high_confidence": 1100,
      "medium_confidence": 320,
      "low_confidence": 100
    },
    "anomalies_detected": 340,
    "key_findings": [
      "Резкое изменение геометрии в период 2012-2015",
      "Стабильные показатели UDMURT (2012-2021)",
      "Новые аномалии VAS (2023-2026)"
    ]
  },

  "timeline": [
    {
      "position": 1,
      "date": "1998-01-15",
      "photo_id": "main_1998_01_15",
      "pose": "frontal",
      "epoch": "legacy",
      "quality": 0.72,
      "verdict": {
        "hypothesis": "H0_SAME",
        "confidence": 0.91,
        "scores": {"H0": 0.85, "H1": 0.08, "H2": 0.07}
      },
      "identity": {
        "geometry_verdict": "PUT",
        "skin_verdict": "real",
        "geometry_confidence": 0.94,
        "skin_confidence": 0.88
      },
      "metrics_snapshot": {
        "cheekbone_R": 0.22,
        "orbit_R": 0.0012,
        "jaw_L": 0.006,
        "wrinkles": 0.35,
        "pores": 0.42
      },
      "anomaly_score": 0.1,
      "flags": [],
      "cluster": "frontal_PUT",
      "context": "Первое фото в серии, эталон для сравнения",
      "comment": "Начало тренда естественного старения"
    },
    {
      "position": 2,
      "date": "2001-03-23",
      "photo_id": "main_2001_03_23",
      "pose": "frontal",
      "epoch": "legacy",
      "quality": 0.85,
      "verdict": {
        "hypothesis": "H0_SAME",
        "confidence": 0.95,
        "scores": {"H0": 0.92, "H1": 0.04, "H2": 0.04}
      },
      "identity": {
        "geometry_verdict": "PUT",
        "skin_verdict": "real",
        "geometry_confidence": 0.97,
        "skin_confidence": 0.93
      },
      "metrics_snapshot": {
        "cheekbone_R": 0.21,
        "orbit_R": 0.0011,
        "jaw_L": 0.0058,
        "wrinkles": 0.33,
        "pores": 0.40
      },
      "anomaly_score": 0.05,
      "flags": [],
      "cluster": "frontal_PUT",
      "context": "Соответствует тренду естественного старения",
      "comment": "Незначительные изменения cheekbone_R (0.22→0.21 за 3 года) — норма"
    }
  ],

  "statistics": {
    "by_hypothesis": {
      "H0_SAME": {"count": 1180, "percent": 77.6, "avg_confidence": 0.87},
      "H1_SYNTHETIC": {"count": 195, "percent": 12.8, "avg_confidence": 0.79},
      "H2_DIFFERENT": {"count": 145, "percent": 9.5, "avg_confidence": 0.82},
      "H_UNCERTAIN": {"count": 0, "percent": 0.0, "avg_confidence": 0.0}
    },
    "by_pose": {
      "frontal": {"total": 450, "H0": 350, "H1": 60, "H2": 40},
      "left_3/4_light": {"total": 280, "H0": 220, "H1": 35, "H2": 25},
      "left_3/4_mid": {"total": 220, "H0": 180, "H1": 25, "H2": 15},
      "left_3/4_deep": {"total": 150, "H0": 120, "H1": 20, "H2": 10},
      "right_3/4_light": {"total": 180, "H0": 140, "H1": 25, "H2": 15},
      "right_3/4_mid": {"total": 120, "H0": 95, "H1": 15, "H2": 10},
      "right_3/4_deep": {"total": 70, "H0": 55, "H1": 10, "H2": 5},
      "profile": {"total": 50, "H0": 40, "H1": 5, "H2": 5}
    },
    "by_epoch": {
      "legacy": {"total": 520, "H0": 500, "H1": 10, "H2": 10},
      "recent": {"total": 1192, "H0": 680, "H1": 185, "H2": 135}
    },
    "by_quality": {
      "high": {"count": 1100, "avg_confidence": 0.89},
      "medium": {"count": 320, "avg_confidence": 0.78},
      "low": {"count": 100, "avg_confidence": 0.62}
    },
    "anomalies": {
      "total": 340,
      "by_type": {
        "sudden_smoothing": 120,
        "aging_break": 85,
        "form_return": 65,
        "impossible_change": 45,
        "face_switching": 25
      },
      "by_severity": {
        "critical": 45,
        "high": 120,
        "medium": 130,
        "low": 45
      }
    }
  },

  "evidence_chains": {
    "main_2015_06_10": {
      "photo_id": "main_2015_06_10",
      "date": "2015-06-10",
      "pose": "frontal",
      "quality": 0.88,
      "verdict": "H2_DIFFERENT",
      "confidence": 0.78,
      "channels": {
        "identity": {
          "weight": 0.35,
          "contribution": 0.32,
          "data": {
            "geometry_verdict": "UDMURT",
            "skin_verdict": "silicone",
            "geometry_confidence": 0.92,
            "skin_confidence": 0.85
          }
        },
        "pairwise": {
          "weight": 0.30,
          "contribution": 0.28,
          "data": {
            "prev_photo": "main_2010_01_15",
            "delta_days": 1882,
            "icp_rmse": 2.31,
            "global_z": 3.2,
            "anomaly_flags": ["sudden_smoothing:high"]
          }
        },
        "chronology": {
          "weight": 0.20,
          "contribution": 0.12,
          "data": {
            "aging_break": true,
            "delta_days": 1882,
            "expected_cheekbone_R": 0.19,
            "actual_cheekbone_R": 0.05,
            "deviation": 0.14
          }
        },
        "cluster": {
          "weight": 0.15,
          "contribution": 0.06,
          "data": {
            "cluster": "frontal_UDMURT",
            "trend": "stable",
            "position_in_cluster": "within_1_std"
          }
        }
      },
      "accumulation": {
        "flags_count": 1,
        "multiplier": 1.0,
        "applied": false
      },
      "quality_gate": {
        "quality": 0.88,
        "multiplier": 1.0,
        "applied": false
      },
      "comment": "Резкое изменение cheekbone_R с 0.19 на 0.05 за 5 лет. Геометрия и текстура указывают на UDMURT."
    }
  },

  "anomalies": [
    {
      "anomaly_id": "ANOM_001",
      "photo_id": "main_2015_06_10",
      "date": "2015-06-10",
      "type": "identity_switch",
      "severity": "high",
      "metric": "cheekbone_R",
      "previous_value": 0.19,
      "current_value": 0.05,
      "delta": 0.14,
      "delta_days": 1882,
      "expected_delta": 0.02,
      "deviation_factor": 7.0,
      "description": "Резкое изменение cheekbone_R с 0.19 на 0.05 за 1882 дней. Ожидаемое изменение: 0.02. Фактическое: 0.14. Отклонение: 7x.",
      "evidence": "Геометрия: UDMURT (92%). Текстура: silicone (85%). Хронология: aging_break.",
      "related_photos": ["main_2010_01_15", "main_2018_03_20"]
    }
  ],

  "calibration_report": {
    "calibration_date": "2026-07-07",
    "calibration_dataset": "91 photos (50 real + 41 silicone)",
    "metrics": {
      "identity_accuracy": 0.999,
      "skin_auc": 0.9912,
      "skin_accuracy": 0.967,
      "overall_confidence": 0.84
    },
    "quality_distribution": {
      "high": 72.4,
      "medium": 21.1,
      "low": 6.5
    },
    "notes": [
      "Калибровка выполнена на датасете 91 фото",
      "Точность идентификации: 99.9% (3 метрики)",
      "Точность текстуры: 96.7% (топ-20 метрик)",
      "192 фото отброшены по качеству (11%)"
    ]
  },

  "verification": {
    "pipeline_checks": [
      {"stage": "s1", "status": "passed", "photos": 1712},
      {"stage": "s2", "status": "passed", "photos": 1520},
      {"stage": "s3", "status": "passed", "photos": 1520},
      {"stage": "s4", "status": "passed", "photos": 1520},
      {"stage": "s5", "status": "passed", "photos": 1520}
    ],
    "anomalies_in_pipeline": 0,
    "warnings": [],
    "errors": []
  },

  "export_formats": {
    "json": "report.json",
    "csv": ["timeline.csv", "verdicts.csv", "anomalies.csv"],
    "markdown": "report.md",
    "xlsx": "report.xlsx"
  }
}
```

---

## 3. Шаблон report.md (для человека)

```markdown
# Форензик-отчёт: NEWWAP Pipeline

**Дата:** 2026-07-07
**Датасет:** 1712 фото (1998-2026)
**Аналитик:** NEWWAP Pipeline v2.0

---

## Краткое резюме

Проанализировано **1520 фото** из 1712 (88.8% покрытие).

| Гипотеза | Кол-во | Доля | Описание |
|----------|--------|------|----------|
| H0_SAME | 1180 | 77.6% | Один и тот же человек |
| H1_SYNTHETIC | 195 | 12.8% | Силиконовая маска |
| H2_DIFFERENT | 145 | 9.5% | Разные люди |
| H_UNCERTAIN | 0 | 0.0% | Недостаточно данных |

**Средняя достоверность:** 84%

---

## Хронология

### 1998-2010 (legacy)
- **Всего фото:** 520
- **H0_SAME:** 500 (96.2%)
- **H1/H2:** 20 (3.8%)
- **Комментарий:** Период естественного старения, стабильные показатели

### 2012-2021 (UDMURT)
- **Всего фото:** 680
- **H0_SAME:** 180 (26.5%)
- **H2_DIFFERENT:** 500 (73.5%)
- **Комментарий:** Появление двойника UDMURT, резкие изменения геометрии

### 2023-2026 (VAS)
- **Всего фото:** 320
- **H0_SAME:** 0 (0%)
- **H2_DIFFERENT:** 320 (100%)
- **Комментарий:** Двойник VAS в силиконовой маске

---

## Ключевые аномалии

1. **2012-2015:** Резкое изменение cheekbone_R (0.22 → 0.05)
2. **2015-2021:** Стабильные показатели UDMURT (маска)
3. **2023-2026:** Новые аномалии VAS

---

## Статистика по ракурсам

| Ракурс | Всего | H0 | H1 | H2 |
|--------|-------|----|----|-----|
| frontal | 450 | 350 | 60 | 40 |
| left_3/4_light | 280 | 220 | 35 | 25 |
| left_3/4_mid | 220 | 180 | 25 | 15 |
| ... | ... | ... | ... | ... |

---

## Достоверность

| Уровень | Кол-во | Доля |
|---------|--------|------|
| Высокая (>0.8) | 1100 | 72.4% |
| Средняя (0.6-0.8) | 320 | 21.1% |
| Низкая (<0.6) | 100 | 6.5% |

---

## Методология

- **Идентификация:** 3 метрики → 99.9% точность
- **Текстура:** Топ-20 метрик, AUC 0.9912
- **Вердикт:** Компенсаторная система (4 канала)
- **Калибровка:** 91 фото (50 real + 41 silicone)

---

*Отчёт сгенерирован автоматически NEWWAP Pipeline v2.0*
*Для публикационных материалов см. s7_public*
```

---

## 4. Шаблон timeline.csv

```csv
position,date,photo_id,pose,epoch,quality,verdict,confidence,identity,skin,cheekbone_R,orbit_R,anomaly_score,flags,cluster,comment
1,1998-01-15,main_1998_01_15,frontal,legacy,0.72,H0_SAME,0.91,PUT,real,0.22,0.0012,0.1,,frontal_PUT,Первое фото в серии
2,2001-03-23,main_2001_03_23,frontal,legacy,0.85,H0_SAME,0.95,PUT,real,0.21,0.0011,0.05,,frontal_PUT,Нормальное старение
3,2015-06-10,main_2015_06_10,frontal,recent,0.88,H2_DIFFERENT,0.78,UDMURT,silicone,0.05,0.0008,1.75,"sudden_smoothing:high",frontal_UDMURT,Резкое изменение
```

---

## 5. Шаблон verdicts.csv

```csv
photo_id,date,pose,epoch,quality,verdict,confidence,h0_score,h1_score,h2_score,geometry_verdict,skin_verdict,anomaly_score,flags_count
main_1998_01_15,1998-01-15,frontal,legacy,0.72,H0_SAME,0.91,0.85,0.08,0.07,PUT,real,0.1,0
main_2001_03_23,2001-03-23,frontal,legacy,0.85,H0_SAME,0.95,0.92,0.04,0.04,PUT,real,0.05,0
main_2015_06_10,2015-06-10,frontal,recent,0.88,H2_DIFFERENT,0.78,0.12,0.10,0.78,UDMURT,silicone,1.75,1
```

---

## 6. Шаблон anomalies.csv

```csv
anomaly_id,photo_id,date,type,severity,metric,previous_value,current_value,delta,delta_days,expected_delta,deviation_factor,description
ANOM_001,main_2015_06_10,2015-06-10,identity_switch,high,cheekbone_R,0.19,0.05,0.14,1882,0.02,7.0,Резкое изменение cheekbone_R
ANOM_002,main_2018_03_20,2018-03-20,aging_break,medium,wrinkles,0.35,0.10,0.25,1095,0.05,5.0,Резкое сглаживание морщин
```

---

## 7. Конфиг s6_config.yaml

```yaml
# s6_report/configs/s6_config.yaml

# === Форматы экспорта ===
export:
  json: true
  csv: true
  markdown: true
  xlsx: false  # опционально

# === Детализация ===
detail_level:
  timeline: true           # включать таймлайн
  evidence_chains: true    # включать цепочки доказательств
  anomaly_descriptions: true  # включать описания аномалий
  comments: true           # включать комментарии

# === Фильтрация ===
filters:
  min_confidence: 0.3      # минимум confidence для включения
  include_uncertain: true  # включать H_UNCERTAIN
  include_excluded: true   # включать отброшенные фото

# === Статистика ===
statistics:
  by_pose: true
  by_epoch: true
  by_quality: true
  by_hypothesis: true
  anomalies_by_type: true
  anomalies_by_severity: true

# === Комментарии ===
comments:
  auto_generate: true      # авто-комментарии к каждому фото
  key_findings: true       # ключевые выводы
  methodology_notes: true  # заметки о методологии
```

---

## 8. Процесс сборки отчёта

```python
def build_report(all_verdicts, all_evidence, config):
    """Собрать полный отчёт из данных всех этапов"""

    report = {}

    # 1. Мета-информация
    report["meta"] = build_meta()

    # 2. Датасет
    report["dataset"] = build_dataset_info(all_verdicts)

    # 3. Краткое резюме
    report["executive_summary"] = build_executive_summary(all_verdicts)

    # 4. Таймлайн
    report["timeline"] = build_timeline(all_verdicts, all_evidence)

    # 5. Статистика
    report["statistics"] = build_statistics(all_verdicts)

    # 6. Цепочки доказательств
    report["evidence_chains"] = build_evidence_chains(all_verdicts, all_evidence)

    # 7. Аномалии
    report["anomalies"] = build_anomalies(all_verdicts, all_evidence)

    # 8. Калибровка
    report["calibration_report"] = build_calibration_report()

    # 9. Верификация
    report["verification"] = build_verification()

    # 10. Экспорт
    export_report(report, config)

    return report
```

---

*Последнее обновление: 2026-07-07*
