# ТЗ — Этап 5 «BAYES & CHRONO»: байесовский синтез + хронологический анализ

Версия: 1.0. Продолжение `STAGE4_TZ.md`. Основано на анализе текущего `backend/` (NEWWAP),
`aboutplatform.txt`, `AGENTS.md`, `REFACTOR_PLAN.md`. Формат — самодостаточное инженерное ТЗ: цель,
границы, входы/выходы, пошаговый алгоритм, контракты данных, обработка ошибок,
критерии приёмки, тест-план, порядок переноса кода.

---

## 1. Цель этапа

Превратить разрозненные **evidence** (попарные сравнения геометрии и per-photo
вердикты кожи из Этапа 4) в **единый, математически строгий форензик-вердикт**
для каждого фото и для каждой пары фото — с учётом приоров (байесовское обновление),
хронологических ограничений (естественная кривая старения, невозможные скачки)
и перекрёстной валидации всех каналов evidence.

Это самый сложный этап пайплайна — именно здесь отдельные «мигающие лампочки»
(geometry deviation на 2.3σ в одной зоне, skin verdict «silicone» с confidence 0.4
на старом плёночном фото) превращаются в **формальную гипотезу**:

- **H0_SAME** — на обоих фото один и тот же живой человек; наблюдаемые различия —
  естественная вариативность съёмки + старение;
- **H1_SYNTHETIC** — на одном или обоих фото присутствует силиконовая маска /
  цифровая подмена лица; текстура кожи — синтетическая при сохранении (или
  близости) геометрии черепа;
- **H2_DIFFERENT** — на фото разные люди (полная подмена, двойник);
- **H_UNCERTAIN** — evidence недостаточно для уверенного вывода (низкое качество
  фото, неполное покрытие зон, противоречивые сигналы).

**Хронологический слой** поверх байеса: проверка, что последовательность вердиктов
во времени физически непротиворечива — лицо не может «помолодеть» на 10 лет за
2 месяца, а потом «постареть» обратно; силиконовая маска не может «появиться»
в 2003, «исчезнуть» в 2005 и снова «появиться» в 2008 на фото того же ракурса
без объяснимой причины.

---

## 2. Входы и выходы

### 2.1 Вход

```
# Из Этапа 4:
storage/results/
├── pairwise_evidence.jsonl    # попарные сравнения геометрии (ICP + per-zone RMSE vs reference)
└── skin_verdicts.jsonl        # per-photo вердикты кожи (real/silicone/uncertain + prob_silicone + confidence)

# Из Этапа 3 (калибровочные модели — для priors):
storage/calibration/
├── reference_geometry.json
└── reference_texture.json

# Из Этапа 1 (метаданные каждого фото — для хронологии):
storage/main/{photo_id}/info.json   # date, age_at_photo, bucket, quality, expression flags

# Конфигурация этапа:
bayes_config.json                    # приоры, пороги, веса evidence-каналов, хронологические ограничения
```

### 2.2 Выход

```
storage/results/
├── forensic_verdicts.jsonl     # per-photo финальный вердикт (H0/H1/H2) с байесовскими вероятностями
├── pair_hypotheses.jsonl       # per-pair гипотезы с evidence-цепочкой
├── timeline_analysis.json      # хронологический анализ: кривая старения, точки разрыва, аномалии
└── anomalies.jsonl             # хронологические аномалии (невозможные скачки, противоречия)
```

#### 2.2.1 `forensic_verdicts.jsonl` — схема строки

```json
{
  "photo_id": "main_2001_03_23",
  "date": "2001-03-23",
  "age_at_photo": 48.5,
  "bucket": "frontal",
  "epoch": "legacy",
  "bayes": {
    "prior": {
      "p_h0": 0.90,
      "p_h1": 0.07,
      "p_h2": 0.03
    },
    "posterior": {
      "p_h0": 0.82,
      "p_h1": 0.15,
      "p_h2": 0.02,
      "p_uncertain": 0.01
    },
    "verdict": "H0_SAME",
    "confidence": 0.85,
    "log_bayes_factor_h1_vs_h0": -1.70,
    "log_bayes_factor_h2_vs_h0": -3.71
  },
  "evidence_used": {
    "geometry_self_consistency": {
      "status": "computed",
      "mean_pairwise_rmse_vs_neighbors": 0.38,
      "z_score_vs_reference": 0.65,
      "supports": "H0_SAME"
    },
    "skin_verdict": {
      "classification": "real",
      "prob_silicone": 0.12,
      "confidence": 0.72,
      "supports": "H0_SAME"
    },
    "chronological_consistency": {
      "status": "consistent",
      "visual_age_estimate": 49.1,
      "chronological_age": 48.5,
      "delta_years": 0.6,
      "is_anomalous": false,
      "supports": "H0_SAME"
    },
    "cross_bucket_consistency": {
      "status": "consistent",
      "neighbor_buckets": ["left_threequarter_light", "right_threequarter_light"],
      "verdicts_in_neighbors": ["H0_SAME", "H0_SAME"],
      "supports": "H0_SAME"
    }
  },
  "evidence_against": [],
  "chronological_context": {
    "previous_photo_date": "2000-08-14",
    "next_photo_date": "2001-09-30",
    "days_since_previous": 221,
    "days_until_next": 191,
    "is_isolated": false
  },
  "rule_traces": [
    {
      "rule_id": "R_CHRONO_CONSISTENT_AGE",
      "triggered": true,
      "reason_ru": "Оценка визуального возраста (49.1) соответствует хронологическому (48.5) в пределах допустимого отклонения (±3 года)"
    }
  ]
}
```

#### 2.2.2 `pair_hypotheses.jsonl` — схема строки

```json
{
  "pair_id": "main_2001_03_23__main_2003_10_05",
  "photo_a": "main_2001_03_23",
  "photo_b": "main_2003_10_05",
  "delta_days": 926,
  "hypothesis": {
    "verdict": "H0_SAME",
    "p_h0": 0.78,
    "p_h1": 0.18,
    "p_h2": 0.03,
    "p_uncertain": 0.01,
    "log_bayes_factor_h1_vs_h0": -1.47,
    "confidence": 0.80
  },
  "evidence_breakdown": {
    "geometry": {
      "global_verdict": "minor_deviation",
      "global_z_score": 1.42,
      "anomalous_zones": [],
      "supports": "H0_SAME",
      "weight_in_fusion": 0.45
    },
    "skin_pair": {
      "photo_a_skin": "real",
      "photo_b_skin": "real",
      "skin_mismatch": false,
      "supports": "H0_SAME",
      "weight_in_fusion": 0.30
    },
    "chronological_constraints": {
      "expected_aging_delta_mm": 0.18,
      "observed_geometry_delta_mm": 0.42,
      "delta_vs_expected_z": 1.15,
      "is_plausible_aging": true,
      "supports": "H0_SAME",
      "weight_in_fusion": 0.25
    }
  },
  "prosthetic_modifier": false,
  "rule_traces": [
    {
      "rule_id": "R_PAIR_GEOMETRY_MINOR_DEVIATION",
      "triggered": true,
      "reason_ru": "Отклонение геометрии 1.42σ — в пределах естественной вариативности данного ракурса (порог 2.0σ)"
    },
    {
      "rule_id": "R_PAIR_SKIN_CONSISTENT",
      "triggered": true,
      "reason_ru": "Оба фото классифицированы как живая кожа"
    }
  ]
}
```

#### 2.2.3 `timeline_analysis.json` — схема

```json
{
  "version": "1.0",
  "built_at": "2026-07-07T12:00:00Z",
  "subject": {
    "birth_date": "1952-10-07",
    "photo_date_range": ["1999-08-09", "2025-06-15"],
    "total_photos": 1775,
    "photos_with_verdict": 1680,
    "photos_uncertain": 95
  },
  "aging_curve": {
    "method": "robust_loess",
    "metrics_tracked": [
      "zone_morphology_jaw_median",
      "zone_morphology_cheek_median",
      "orbit_ellipse_bowl_ratio",
      "palpebral_aperture_height"
    ],
    "breakpoints": [
      {"date": "2011-09-24", "metric": "zone_morphology_jaw_median", "direction": "sharp_decrease", "z_score": 4.2},
      {"date": "2013-03-15", "metric": "palpebral_aperture_height", "direction": "increase", "z_score": 3.8}
    ],
    "natural_aging_rate": {
      "zone_morphology_jaw_median": {"mm_per_year": 0.04, "r_squared": 0.72},
      "orbit_ellipse_bowl_ratio": {"ratio_per_year": 0.002, "r_squared": 0.45}
    }
  },
  "eras": [
    {
      "era_id": "pre_2011",
      "date_range": ["1999-08-09", "2011-09-23"],
      "dominant_verdict": "H0_SAME",
      "h0_fraction": 0.91,
      "h1_fraction": 0.03,
      "h2_fraction": 0.01,
      "uncertain_fraction": 0.05,
      "mean_confidence": 0.78,
      "description_ru": "Период до первого значимого отклонения: высокая согласованность геометрии и текстуры, естественное старение"
    },
    {
      "era_id": "transition_2011_2014",
      "date_range": ["2011-09-24", "2014-12-31"],
      "dominant_verdict": "mixed",
      "h0_fraction": 0.55,
      "h1_fraction": 0.28,
      "h2_fraction": 0.05,
      "uncertain_fraction": 0.12,
      "mean_confidence": 0.62,
      "description_ru": "Переходный период: рост доли synthetic-вердиктов, геометрические аномалии в нижней челюсти и глазной щели"
    },
    {
      "era_id": "post_2015",
      "date_range": ["2015-01-01", "2025-06-15"],
      "dominant_verdict": "H1_SYNTHETIC",
      "h0_fraction": 0.18,
      "h1_fraction": 0.71,
      "h2_fraction": 0.03,
      "uncertain_fraction": 0.08,
      "mean_confidence": 0.74,
      "description_ru": "Период систематического доминирования synthetic-вердиктов: геометрия близка к оригиналу, текстура кожи — синтетическая"
    }
  ]
}
```

#### 2.2.4 `anomalies.jsonl` — схема строки

```json
{
  "anomaly_id": "anom_0042",
  "type": "impossible_aging_reversal",
  "photo_a": "main_2012_05_07",
  "photo_b": "main_2012_07_14",
  "delta_days": 68,
  "metric": "zone_morphology_jaw_median",
  "value_a": 12.3,
  "value_b": 10.1,
  "delta": -2.2,
  "expected_delta": 0.01,
  "z_score": -5.8,
  "description_ru": "Невозможное «омоложение» нижней челюсти на 2.2 мм за 68 дней (в 5.8 раз превышает естественную скорость старения в обратном направлении)",
  "severity": "critical"
}
```

---

## 3. Архитектура: два слоя — Bayesian Core + Chronological Layer

```
                    ┌──────────────────────────────────┐
                    │   pairwise_evidence.jsonl         │  из Этапа 4
                    │   skin_verdicts.jsonl             │
                    │   info.json (всех фото)           │  из Этапа 1
                    │   reference_geometry/texture.json │  из Этапа 3
                    └──────────────┬───────────────────┘
                                   │
                    ┌──────────────▼───────────────────┐
                    │        EVIDENCE NORMALIZER        │
                    │                                   │
                    │  • Приводит все evidence к единому │
                    │    формату EvidencePacket         │
                    │  • Проверяет admissibility gates │
                    │  • Нормализует шкалы (z-scores,   │
                    │    log-likelihood ratios)         │
                    │  • Разрешает конфликты каналов    │
                    └──────────────┬───────────────────┘
                                   │
          ┌────────────────────────┼────────────────────────┐
          │                        │                        │
┌─────────▼─────────┐  ┌───────────▼───────────┐  ┌────────▼──────────┐
│   BAYESIAN CORE    │  │   FORENSIC RULES      │  │  CHRONO ENGINE    │
│                    │  │                        │  │                   │
│ 1. Prior assignment │  │ 1. R_PAIR_GEOMETRY_*  │  │ 1. build_timeline │
│    per epoch/bucket │  │ 2. R_SKIN_*           │  │ 2. estimate_visual│
│                      │  │ 3. R_CHRONO_*         │  │    _age           │
│ 2. Evidence →        │  │ 4. R_CROSS_BUCKET_*  │  │ 3. evaluate_chrono│
│    likelihood        │  │                        │  │    _delta         │
│    (prob_logic.py)   │  │ Human-readable rules  │  │                   │
│                      │  │ with RU explanations  │  │ 4. PELT breakpoint│
│ 3. Bayesian update   │  │                        │  │    detection      │
│    (posterior.py)    │  │ Output: rule traces +  │  │                   │
│                      │  │ hypothesis votes      │  │ 5. detect impossible│
│ 4. Decision with     │  │                        │  │    reversals      │
│    guards            │  └───────────┬───────────┘  │                   │
│    (decision.py)     │              │              │ 6. era segmentation│
│                      │              │              └────────┬──────────┘
└─────────┬───────────┘              │                       │
          │                          │                       │
          └──────────────────────────┼───────────────────────┘
                                     │
                    ┌────────────────▼───────────────────┐
                    │         HYPOTHESIS FUSION           │
                    │                                     │
                    │  • Взвешенное голосование:           │
                    │    bayesian_posterior (вес 0.40)     │
                    │    + rule_votes (вес 0.30)           │
                    │    + chrono_constraints (вес 0.30)   │
                    │                                     │
                    │  • Разрешение конфликтов:            │
                    │    если каналы расходятся > порога,  │
                    │    вердикт → H_UNCERTAIN             │
                    │                                     │
                    │  • Per-photo final verdict           │
                    │  • Per-pair hypothesis               │
                    └────────────────┬───────────────────┘
                                     │
                    ┌────────────────▼───────────────────┐
                    │         OUTPUT WRITER               │
                    │                                     │
                    │  forensic_verdicts.jsonl            │
                    │  pair_hypotheses.jsonl              │
                    │  timeline_analysis.json             │
                    │  anomalies.jsonl                    │
                    └─────────────────────────────────────┘
```

**Почему байесовский движок и хронология — в одном этапе:**
- Это математически другой слой, чем извлечение evidence (Этап 4) — здесь не
  вычисляются новые метрики, а синтезируются уже готовые;
- Хронологические ограничения (возраст, допустимый темп старения) — это приоры
  байесовской модели, а не отдельный пост-процессинг;
- Ошибка здесь не должна требовать пересчёта тяжёлого 3D pipeline (Этапы 1–2);
- Разделение от Этапа 6 (Report) критично: report — чистая агрегация, не содержащая
  вычислительной логики.

---

## 4. Пошаговый алгоритм

### Часть A: Evidence Normalizer (подготовка)

#### Шаг A.1: Загрузка и валидация evidence

```
загрузить pairwise_evidence.jsonl → список PairEvidence
загрузить skin_verdicts.jsonl → dict[photo_id, SkinVerdict]
загрузить info.json для всех photo_id → dict[photo_id, PhotoInfo]

для каждого evidence:
    проверить admissibility gates (evidence_gates.py):
        - geometry: status == "computed" AND shared_vertex_count ≥ 1000
        - skin: status == "computed" AND confidence ≥ 0.2
        - если gate не пройден → evidence помечается как inadmissible,
          исключается из байесовского обновления (но не из rule-части)
```

#### Шаг A.2: Нормализация в единый EvidencePacket

```python
@dataclass
class EvidencePacket:
    """Единый пакет evidence для байесовского движка."""
    photo_id: str
    pair_id: str | None          # None для per-photo evidence
    
    # Геометрические evidence (из pairwise_evidence)
    geometry_global_z: float | None
    geometry_anomalous_zone_count: int
    geometry_max_zone_z: float | None
    
    # Кожные evidence (из skin_verdicts)
    skin_prob_silicone: float | None
    skin_confidence: float | None
    skin_classification: str | None  # real/silicone/uncertain
    
    # Метаданные
    bucket: str
    epoch: str  # legacy/recent
    date: str
    age_at_photo: float
    quality_overall: float
    
    # Флаги admissibility
    geometry_admissible: bool
    skin_admissible: bool
```

### Часть B: Bayesian Core

#### Шаг B.1: Назначение приоров

Приоры зависят от эпохи, ракурса и типа анализа (per-photo vs per-pair):

```
# Per-photo приоры (из bayes_config.json, калибруются по historical data):
если epoch == "legacy" (фото до 2015):
    prior = {p_h0: 0.90, p_h1: 0.07, p_h2: 0.03}
    # Высокий prior H0 — большинство старых фото считаются подлинными,
    # бремя доказательства на evidence

если epoch == "recent" (фото после 2015):
    prior = {p_h0: 0.50, p_h1: 0.40, p_h2: 0.10}
    # Более равномерный prior — калибровочный датасет показал,
    # что в эту эпоху synthetic-сигнал значим

# Per-pair приоры (зависят от эпохи ОБОИХ фото):
если оба legacy:
    prior = {p_h0: 0.88, p_h1: 0.09, p_h2: 0.03}
если оба recent:
    prior = {p_h0: 0.45, p_h1: 0.45, p_h2: 0.10}
если смешанная (одно legacy, одно recent):
    prior = {p_h0: 0.60, p_h1: 0.30, p_h2: 0.10}
    # Повышенный prior H1 — сама ситуация «сравниваем старое с новым»
    # уже informативна для гипотезы подмены
```

#### Шаг B.2: Evidence → Likelihood (prob_logic.py функции)

Берём за основу текущий `core/fuzzy_bayes/prob_logic.py` (🟡 — переносить
функцию за функцией с юнит-тестом):

```python
def geometry_evidence_to_likelihood(
    geometry_global_z: float,
    anomalous_zone_count: int,
    max_zone_z: float,
    bucket: str
) -> dict[str, float]:
    """
    Преобразует геометрический evidence в likelihoods P(evidence | Hi).
    
    H0_SAME:       глобальный z около 0, мало аномальных зон
    H1_SYNTHETIC:  умеренный z (1-2), аномалии в костных зонах,
                    но не во всех (силикон на похожем черепе)
    H2_DIFFERENT:  высокий z (>3), много аномальных зон по всему лицу
    """
    # Likelihood моделируются как смесь нормальных распределений
    # с параметрами, откалиброванными по calibration-датасету (Этап 3)
    ...

def skin_evidence_to_likelihood(
    prob_silicone: float,
    skin_confidence: float,
    epoch: str
) -> dict[str, float]:
    """
    Преобразует кожный evidence в likelihoods.
    
    H0_SAME:       prob_silicone низкая, confidence высокая
    H1_SYNTHETIC:  prob_silicone высокая, confidence ≥ 0.3
    H2_DIFFERENT:  не informative (кожа может быть любой)
    
    Важно: confidence учитывается — низкая confidence размывает
    likelihoods в сторону равномерного распределения.
    """
    ...

def prosthetic_modifier_to_likelihood(
    prosthetic_modifier: bool,
    geometry_z: float
) -> dict[str, float]:
    """
    prosthetic_modifier = True (геометрия близка, текстура разная) —
    это сильный сигнал в пользу H1_SYNTHETIC.
    """
    if prosthetic_modifier and geometry_z < 2.0:
        return {"H0_SAME": 0.05, "H1_SYNTHETIC": 0.90, "H2_DIFFERENT": 0.05}
    else:
        return {"H0_SAME": 0.33, "H1_SYNTHETIC": 0.34, "H2_DIFFERENT": 0.33}
```

#### Шаг B.3: Байесовское обновление (posterior.py)

```python
def bayesian_update(
    prior: dict[str, float],
    evidence_packets: list[EvidencePacket]
) -> dict[str, float]:
    """
    Последовательное байесовское обновление:
    
    P(Hi | E1, E2, ..., En) ∝ P(Hi) × Π_j P(Ej | Hi)
    
    Evidence считаются условно независимыми (naive Bayes) —
    это осознанное упрощение; зависимость между каналами
    учитывается через отдельный conflict-resolution шаг.
    """
    log_posterior = {h: log(prior[h]) for h in prior}
    
    for evidence in evidence_packets:
        # Geometry likelihood
        if evidence.geometry_admissible:
            geom_lik = geometry_evidence_to_likelihood(...)
            for h in log_posterior:
                log_posterior[h] += log(geom_lik[h])
        
        # Skin likelihood
        if evidence.skin_admissible:
            skin_lik = skin_evidence_to_likelihood(...)
            for h in log_posterior:
                log_posterior[h] += log(skin_lik[h])
    
    # Нормализация (log-sum-exp)
    max_log = max(log_posterior.values())
    posterior = {
        h: exp(log_posterior[h] - max_log) for h in log_posterior
    }
    total = sum(posterior.values())
    posterior = {h: v / total for h, v in posterior.items()}
    
    return posterior
```

#### Шаг B.4: Log Bayes Factor

```python
def compute_log_bayes_factors(posterior: dict, prior: dict) -> dict:
    """
    log BF(H1 vs H0) = log(P(E|H1) / P(E|H0))
                     = log(P(H1|E)/P(H0|E)) - log(P(H1)/P(H0))
    
    Интерпретация (шкала Джеффриса):
    |log BF| < 1.0  — evidence слабое (barely worth mentioning)
    1.0 ≤ |log BF| < 2.5 — evidence умеренное (substantial)
    2.5 ≤ |log BF| < 5.0 — evidence сильное (strong)
    |log BF| ≥ 5.0 — evidence очень сильное (decisive)
    """
    ...
```

#### Шаг B.5: Decision с guards (decision.py)

```python
def make_decision(
    posterior: dict[str, float],
    log_bf: dict[str, float],
    evidence_count: int,
    confidence: float
) -> VerdictResult:
    """
    Принимает финальное решение с защитными guards:
    
    1. Доминирование: если p(Hi) > 0.6 И p(Hi) > 2 × p(Hj) для всех j≠i:
       verdict = Hi
    2. Неопределённость: если max(p) < 0.5:
       verdict = H_UNCERTAIN
    3. Конфликт: если два канала evidence дают противоположные выводы
       и оба с высокой confidence:
       verdict = H_UNCERTAIN с флагом channel_conflict
    4. Минимальное evidence: если evidence_count < 2:
       verdict = H_UNCERTAIN с флагом insufficient_evidence
    5. Низкая confidence: confidence < 0.3:
       verdict = H_UNCERTAIN с флагом low_confidence
    """
    ...
```

### Часть C: Forensic Rules Engine (rules.py)

#### Шаг C.1: Детерминированные правила

Параллельно с байесовским движком работает **rules engine** — набор явных,
человекочитаемых правил (из текущего `core/fuzzy_bayes/rules.py`, 🟡 перенос
с построчным аудитом):

| Rule ID | Условие | → Гипотеза | Причина (RU) |
|---------|---------|------------|--------------|
| `R_PAIR_GEOMETRY_ANOMALOUS` | global_z ≥ 3.0 + ≥ 3 anomalous zones | H2_DIFFERENT | Геометрия лица отличается по множеству зон — разные люди |
| `R_PAIR_GEOMETRY_SIGNIFICANT` | 2.0 ≤ global_z < 3.0 + prosthetic_modifier | H1_SYNTHETIC | Геометрия близка, но с отклонениями + текстура разная — силиконовая маска |
| `R_PAIR_GEOMETRY_CONSISTENT` | global_z < 1.0 + оба skin=real | H0_SAME | Геометрия и текстура согласованы — один человек |
| `R_SKIN_SILICONE_HIGH_CONF` | prob_silicone > 0.8 + confidence > 0.6 | H1_SYNTHETIC | Высокая уверенность в синтетической коже |
| `R_SKIN_REAL_HIGH_CONF` | prob_silicone < 0.15 + confidence > 0.6 | H0_SAME | Высокая уверенность в живой коже |
| `R_CHRONO_IMPOSSIBLE_REVERSAL` | aging_reversal_z < -4.0 | H1_SYNTHETIC | Физически невозможное «омоложение» — подмена лица |
| `R_CHRONO_SHARP_JUMP` | aging_jump_z > 4.0 + последующая стабилизация | H1_SYNTHETIC | Резкий скачок с возвратом — смена маски/подмены |
| `R_CROSS_BUCKET_DIVERGENCE` | разные вердикты в разных ракурсах одного дня | H_UNCERTAIN | Противоречие между ракурсами — возможно, ошибка реконструкции |
| `R_ISOLATED_PHOTO` | одно фото в ракурсе за большой период | Confidence -= 0.2 | Мало данных для сравнения |
| `R_QUALITY_COMPROMISED` | q_overall < 0.3 + hf_metrics_discounted | H_UNCERTAIN | Качество фото слишком низкое для надёжного вывода |

#### Шаг C.2: Взвешенное голосование правил

```python
def rules_vote(
    evidence: EvidencePacket,
    rules: list[Rule],
    chronological_context: ChronoContext
) -> dict[str, float]:
    """
    Каждое сработавшее правило отдаёт взвешенный голос:
    
    rule_weight зависит от:
    - specificity: насколько правило специфично (R_CHRONO_IMPOSSIBLE_REVERSAL
      вес 0.95 — почти достоверно; R_QUALITY_COMPROMISED вес 0.3 — слабый сигнал)
    - rule_confidence: внутренняя confidence правила
    
    Итоговый vote = нормализованная сумма голосов по гипотезам.
    """
    ...
```

### Часть D: Chronological Engine

#### Шаг D.1: Построение временной шкалы (timeline)

```python
def build_timeline(
    photos: list[PhotoInfo],
    forensic_verdicts: dict[str, VerdictResult]
) -> Timeline:
    """
    Для каждого photo_id строим временную шкалу:
    - Сортируем все фото по дате
    - Для каждого фото находим предыдущее и следующее в том же ракурсе
    - Вычисляем временные интервалы
    - Помечаем изолированные фото (нет соседей в ракурсе за ±180 дней)
    """
    ...
```

#### Шаг D.2: Кривая старения (aging curve)

```python
def estimate_aging_curve(
    timeline: Timeline,
    metrics: list[str]  # ключевые метрики, коррелирующие с возрастом
) -> AgingCurve:
    """
    Строит кривую старения по выбранным метрикам:
    
    1. Для каждой метрики: robust LOESS-регрессия metric ~ age
       (робастная к выбросам — единичные synthetic фото не должны
       искажать кривую)
    2. Вычисляет ожидаемый темп старения (mm/year, ratio/year)
    3. Определяет доверительные интервалы (±2σ)
    4. Находит точки выхода за пределы CI → candidate breakpoints
    
    Метрики для кривой старения (костные структуры):
    - zone_morphology_jaw_median (нижняя челюсть — наиболее стабильная)
    - zone_morphology_cheek_median (скулы)
    - orbit_ellipse_bowl_ratio (форма орбит)
    - palpebral_aperture_height (глазная щель — меняется с возрастом)
    - nose_bridge_width (переносица)
    """
    ...
```

#### Шаг D.3: Детекция хронологических аномалий

```python
def detect_chronological_anomalies(
    timeline: Timeline,
    aging_curve: AgingCurve
) -> list[Anomaly]:
    """
    Три типа аномалий:
    
    1. IMPOSSIBLE_REVERSAL — «омоложение»:
       Значение метрики возвращается к уровню многолетней давности
       за короткий срок. Пример: jaw_median = 12.3 (2012-05),
       затем 10.1 (2012-07) — откат на уровень 2005 года.
       Z-score: (observed_delta - expected_aging_delta) / sigma_delta
    
    2. SHARP_JUMP_WITH_RETURN — резкий скачок с возвратом:
       Метрика резко меняется (>4σ) и через некоторое время
       возвращается к предыдущему уровню. Паттерн «смена маски».
    
    3. GRADUAL_DIVERGENCE — постепенное расхождение:
       Метрика монотонно уходит от исторического тренда
       на протяжении > 3 последовательных фото.
    
    Для каждого типа: severity (critical / warning / info),
    z_score, затронутые метрики, описание на русском.
    """
    ...
```

#### Шаг D.4: PELT-сегментация (breakpoint detection)

```python
def segment_into_eras(
    timeline: Timeline,
    aging_curve: AgingCurve
) -> list[Era]:
    """
    Использует PELT (Pruned Exact Linear Time) для нахождения
    оптимальных точек разрыва во временном ряду метрик.
    
    Алгоритм (из forensic/chrono_cluster.py, 🟢):
    1. Для каждой метрики: PELT с penalty = 2 × log(n)
    2. Агрегировать breakpoints по всем метрикам
    3. Ward-кластеризация для группировки близких breakpoints
    4. Определить эры: непрерывные интервалы между агрегированными breakpoints
    
    Для каждой эры вычислить:
    - Доминирующий вердикт
    - Доли H0/H1/H2/Uncertain
    - Среднюю confidence
    - Описание на русском
    """
    ...
```

#### Шаг D.5: Хронологические ограничения для байеса

```python
def chronological_constraints_to_likelihood(
    photo: PhotoInfo,
    timeline: Timeline,
    aging_curve: AgingCurve
) -> dict[str, float]:
    """
    Хронология НЕ даёт независимый вердикт — она модифицирует likelihoods:
    
    - Если visual_age_estimate близок к хронологическому возрасту (±2 года):
      небольшое усиление H0 (×1.2)
    - Если обнаружен impossible_reversal с соседним фото:
      сильное усиление H1 (×5.0) для ОБОИХ фото
    - Если фото — часть sharp_jump_with_return паттерна:
      усиление H1 (×3.0)
    - Если фото находится в эре с доминирующим H1:
      умеренное усиление H1 (×1.5)
    
    Это байесовски корректно: хронология — это дополнительный evidence,
    который обновляет prior.
    """
    ...
```

### Часть E: Hypothesis Fusion

#### Шаг E.1: Сведение трёх каналов

```python
def fuse_hypotheses(
    bayesian_posterior: dict[str, float],
    rules_vote: dict[str, float],
    chrono_likelihood_modifier: dict[str, float],
    weights: tuple[float, float, float] = (0.40, 0.30, 0.30)
) -> FusedHypothesis:
    """
    Взвешенное сведение трёх источников:
    
    fused[h] = w_bayes × bayesian_posterior[h]
             + w_rules × rules_vote[h]
             + w_chrono × chrono_modified_bayesian[h]
    
    где chrono_modified_bayesian[h] = 
        bayesian_posterior[h] × chrono_likelihood_modifier[h] / normalizer
    
    Conflict detection:
    если |fused[h0] - rules_vote[h0]| > 0.3:
        флаг bayes_rules_conflict
    если chrono_likelihood_modifier[h1] > 3.0 AND bayesian_posterior[h1] < 0.2:
        флаг chrono_bayes_conflict (хронология видит аномалию, байес — нет)
    
    При конфликте: confidence понижается пропорционально magnitude конфликта.
    """
    ...
```

#### Шаг E.2: Per-photo final verdict

```
для каждого photo_id:
    собрать все evidence (geometry self-consistency, skin, chrono)
    запустить Bayesian Core → posterior
    запустить Forensic Rules → rules_vote
    запустить Chrono Constraints → chrono_modifier
    запустить Hypothesis Fusion → fused
    применить decision guards
    записать в forensic_verdicts.jsonl
```

#### Шаг E.3: Per-pair hypothesis

```
для каждой пары из pairwise_evidence.jsonl:
    собрать evidence пары + per-photo вердикты обоих фото
    запустить Bayesian Core (pair priors)
    запустить Forensic Rules (pair rules)
    запустить Chrono Constraints (ожидаемый aging delta vs наблюдаемый)
    запустить Hypothesis Fusion
    записать в pair_hypotheses.jsonl
```

---

## 5. Контракты данных

### 5.1 `bayes_config.json`

```json
{
  "version": "1.0",
  "priors": {
    "per_photo": {
      "legacy": {"p_h0": 0.90, "p_h1": 0.07, "p_h2": 0.03},
      "recent": {"p_h0": 0.50, "p_h1": 0.40, "p_h2": 0.10}
    },
    "per_pair": {
      "both_legacy": {"p_h0": 0.88, "p_h1": 0.09, "p_h2": 0.03},
      "both_recent": {"p_h0": 0.45, "p_h1": 0.45, "p_h2": 0.10},
      "mixed":       {"p_h0": 0.60, "p_h1": 0.30, "p_h2": 0.10}
    }
  },
  "decision_thresholds": {
    "dominance_ratio": 2.0,
    "min_posterior_for_verdict": 0.5,
    "min_confidence": 0.3,
    "min_evidence_count": 2
  },
  "log_bayes_factor_scale": {
    "barely_worth_mentioning": 1.0,
    "substantial": 2.5,
    "strong": 5.0
  },
  "fusion_weights": {
    "bayesian": 0.40,
    "rules": 0.30,
    "chrono": 0.30
  },
  "chronological_constraints": {
    "max_plausible_aging_rate": {
      "zone_morphology_jaw_median": {"mm_per_year": 0.08, "max_total_mm": 2.0},
      "orbit_ellipse_bowl_ratio": {"ratio_per_year": 0.005, "max_total_ratio": 0.12},
      "palpebral_aperture_height": {"mm_per_year": 0.06, "max_total_mm": 1.5}
    },
    "visual_age_tolerance_years": 3.0,
    "impossible_reversal_z_threshold": -4.0,
    "sharp_jump_z_threshold": 4.0,
    "min_days_for_aging_evaluation": 90
  },
  "rule_weights": {
    "R_PAIR_GEOMETRY_ANOMALOUS": 0.95,
    "R_PAIR_GEOMETRY_SIGNIFICANT": 0.80,
    "R_PAIR_GEOMETRY_CONSISTENT": 0.70,
    "R_SKIN_SILICONE_HIGH_CONF": 0.90,
    "R_SKIN_REAL_HIGH_CONF": 0.85,
    "R_CHRONO_IMPOSSIBLE_REVERSAL": 0.95,
    "R_CHRONO_SHARP_JUMP": 0.85,
    "R_CROSS_BUCKET_DIVERGENCE": 0.60,
    "R_ISOLATED_PHOTO": 0.20,
    "R_QUALITY_COMPROMISED": 0.30
  },
  "pellet_segmentation": {
    "penalty": "2*log(n)",
    "min_era_length_days": 180,
    "min_photos_per_era": 5
  }
}
```

### 5.2 Типы гипотез

```python
class Hypothesis(str, Enum):
    H0_SAME = "H0_SAME"            # один и тот же живой человек
    H1_SYNTHETIC = "H1_SYNTHETIC"  # силиконовая маска / цифровая подмена
    H2_DIFFERENT = "H2_DIFFERENT"  # разные люди
    H_UNCERTAIN = "H_UNCERTAIN"    # недостаточно evidence

class AnomalyType(str, Enum):
    IMPOSSIBLE_REVERSAL = "impossible_reversal"
    SHARP_JUMP_WITH_RETURN = "sharp_jump_with_return"
    GRADUAL_DIVERGENCE = "gradual_divergence"

class AnomalySeverity(str, Enum):
    CRITICAL = "critical"   # z > 5.0 — практически достоверная аномалия
    WARNING = "warning"     # z > 3.0 — значимая аномалия
    INFO = "info"           # z > 2.0 — заслуживает внимания
```

---

## 6. Обработка ошибок и граничные случаи

| Ситуация | Действие |
|----------|----------|
| Нет admissible evidence для фото (все каналы rejected) | Verdict = H_UNCERTAIN, confidence = 0.0, reason = "no_admissible_evidence" |
| Байесовский posterior и rules vote расходятся > 0.3 | Флаг `bayes_rules_conflict`, confidence × 0.7, verdict = H_UNCERTAIN |
| Хронология показывает impossible_reversal, но байес даёт H0 | Флаг `chrono_bayes_conflict`, confidence × 0.5, verdict — в пользу хронологии (консервативно: лучше H_UNCERTAIN, чем false negative) |
| Менее 3 фото в ракурсе за всю историю | Хронологическая кривая для этого ракурса не строится, chrono_constraints возвращают uniform likelihoods |
| PELT не находит ни одного breakpoint | Одна эра на весь период; если при этом есть аномалии в anomalies.jsonl — флаг `pellet_vs_anomaly_mismatch` |
| Фото с датой вне диапазона калибровки (ранее 1999 или позднее 2025) | Использовать priors ближайшей эпохи с флагом `extrapolated_prior` |
| `rule_traces` содержат противоречащие правила (напр. R_PAIR_CONSISTENT и R_SKIN_SILICONE для одной пары) | Взвешенное голосование само разрешает; при равных весах — H_UNCERTAIN |
| Фото с `expression_flags.smile = True` или `mouth_open = True` | Исключить мимические зоны из chrono-сравнения; geometry evidence использует `EXCLUDED_ZONES` из Этапа 2 |
| Несколько фото в один день в одном ракурсе | Выбрать фото с наивысшим `quality.overall_score` как representative; остальные помечены `same_day_duplicate` |

---

## 7. Порядок переноса кода (из REFACTOR_PLAN.md)

### 🟢 Перенести как есть

| Модуль | Комментарий |
|--------|-------------|
| `core/fuzzy_bayes/hypothesis_keys.py` | Канонические H0_SAME / H1_SYNTHETIC / H2_DIFFERENT / H_UNCERTAIN + миграция legacy-ключей. Чистый, маленький, образцовый модуль |
| `core/fuzzy_bayes/evidence_gates.py` | Гейты допустимости evidence — самостоятельный, маленький |
| `forensic/chrono_cluster.py` (`robust_mad`, `pelt_breakpoint_count`, `agglomerative_ward_labels`) | Статистические примитивы для PELT-сегментации и кластеризации |
| `forensic/negative_control.py` | Контрольные группы для валидации methodology |
| `forensic/prior_sensitivity.py` | Анализ чувствительности к приорам |
| `forensic/bootstrap_ci.py` | Доверительные интервалы Wilson |
| `forensic/ablation.py`, `forensic/ablation_compare.py` | Ablation-исследования: какой evidence-канал насколько важен |
| `core/contracts.py` (`MeasurementResult`, `ResultStatus`) | Типизированные контракты — расширить на VerdictResult, Anomaly |

### 🟡 Перенести с рефакторингом

| Модуль | Комментарий |
|--------|-------------|
| `core/fuzzy_bayes/membership.py` (`silicone_membership`) | Порог `noise_threshold` (0.3→0.7) уже поправлен. Перенести с regression-тестом на этот конкретный порог |
| `core/fuzzy_bayes/prob_logic.py` (676 строк) | **Ядро вероятностной модели.** 6 evidence-функций не эмитили H1 (частично починено). Переносить функцию за функцией с юнит-тестом «на синтетическом evidence вход X ожидаем долю H1 не ниже Y». Максимальная концентрация тонких багов |
| `core/fuzzy_bayes/rules.py` (281 строка) | 19 правил → H_CARRIER_SWITCH и 0 → H1_SYNTHETIC (частично починено). Переносить с построчным аудитом каждого правила: в какую гипотезу оно реально льёт |
| `core/fuzzy_bayes/posterior.py`, `decision.py` | Матаппарат корректен (байесовское обновление, guards), но зависит от prob_logic/rules выше по цепочке. Переносить **после** них |
| `core/chronology.py` (`build_timeline`, `estimate_visual_age_from_features`, `evaluate_chronological_delta`) | 579 строк. Идея правильная (кривая старения, allowed_delta, флаг «невозможного» скачка). Проверить на реальных датах Путина через `subject_age_years_at` |
| `core/fuzzy_bayes/chronology.py`, `timeline_pairs.py` | **Два модуля с идентичными именами в разных пакетах** (`core/chronology.py` и `core/fuzzy_bayes/chronology.py`). При пересборке — объединить в один `chrono/` пакет |
| `core/fuzzy_bayes/config.py` | Конфигурация байеса — перенести, консолидировать с `bayes_config.json` |

### 🔴 Переписать заново / не переносить

| Модуль | Комментарий |
|--------|-------------|
| Дублирующаяся логика chronology | `core/chronology.py` и `core/fuzzy_bayes/chronology.py` — спроектировать заново как единый `chrono/` пакет |
| `core/analysis.py` — байес-связанные секции | Вырезать из монолита, логика уходит в Этап 5 |

### Новое (не существует в текущем коде)

- `bayes/evidence_normalizer.py` — приведение evidence к единому EvidencePacket
- `bayes/likelihoods.py` — реорганизованные prob_logic-функции с тестами
- `bayes/posterior.py` — байесовское обновление (на основе текущего posterior.py + decision.py)
- `bayes/fusion.py` — взвешенное сведение bayes + rules + chrono (новое)
- `rules/engine.py` — rules engine с аудированными правилами
- `rules/definitions.py` — декларативные определения правил (rule_id, условие, гипотеза, причина, вес)
- `chrono/timeline.py` — единый модуль хронологии (слияние двух chronology.py)
- `chrono/aging_curve.py` — robust LOESS + PELT breakpoints
- `chrono/anomaly_detector.py` — три типа хронологических аномалий
- `chrono/era_segmenter.py` — PELT + Ward кластеризация → эры
- `config/bayes_config.json` — все приоры, пороги, веса

---

## 8. Критерии приёмки (Definition of Done)

### Байесовский движок

1. **Калибровка likelihoods**: на calibration-датасете (где ground truth известен —
   автор = real, силикон = synthetic) байесовский движок даёт:
   - H0_SAME для ≥ 90% real-фото автора (эпоха recent, высокое качество);
   - H1_SYNTHETIC для ≥ 80% silicone-фото;
   - Log Bayes Factor H1 vs H0 ≥ 2.5 (substantial) для ≥ 70% silicone-фото.
2. **Prior sensitivity**: изменение prior на ±0.1 не меняет вердикт для ≥ 85% фото
   (вердикт устойчив к выбору приоров).
3. **Evidence admissibility**: фото с `geometry_admissible = False` и `skin_admissible = False`
   получает H_UNCERTAIN, а не произвольный вердикт.
4. **Log Bayes Factor scale**: для пар с заведомо разными людьми (negative control)
   log BF(H2 vs H0) ≥ 5.0 (decisive).

### Хронологический анализ

5. **Aging curve**: robust LOESS на реальных данных 1999–2025 даёт монотонную кривую
   старения с r² ≥ 0.4 для ≥ 3 метрик.
6. **Breakpoint detection**: PELT находит известные аномалии (2011–2013) с точностью
   ±90 дней от ожидаемых дат.
7. **Impossible reversal**: calibration-тест — искусственно созданная пара «реальное фото →
   фото 5-летней давности, выданное за новое» — детектируется как impossible_reversal
   с severity = critical.
8. **False positive chrono**: на 100 случайных парах real-фото автора (где точно нет подмены)
   — 0 false positive impossible_reversal аномалий.

### Интеграция

9. **End-to-end**: полный прогон 1700+ фото от Этапа 1 до Этапа 5 даёт:
   - `forensic_verdicts.jsonl` с ≥ 1600 записями (≥ 90% покрытие);
   - `timeline_analysis.json` с 3–5 эрами;
   - `anomalies.jsonl` с ≥ 5 записями severity ≥ warning.
10. **Reproducibility**: повторный запуск на тех же данных даёт идентичные вердикты
    (детерминированные алгоритмы, без random seed).
11. **Rule traceability**: каждый вердикт в `forensic_verdicts.jsonl` содержит `rule_traces`
    с минимум 1 сработавшим правилом и объяснением на русском.

---

## 9. Тест-план

### 9.1 Юнит-тесты

- `geometry_evidence_to_likelihood` — параметризованный: z = [0.0, 1.0, 2.0, 3.0, 5.0],
  проверка что likelihoods монотонны: H0 убывает с ростом z, H2 возрастает.
- `skin_evidence_to_likelihood` — prob_silicone = [0.05, 0.20, 0.50, 0.80, 0.95],
  confidence = [0.2, 0.5, 0.8] — кросс-проверка.
- `prosthetic_modifier_to_likelihood` — (True, z=1.5) → H1 ≥ 0.80; (False, z=1.5) → H1 ≤ 0.40.
- `bayesian_update` — синтетический тест: 3 evidence подряд подтверждают H1,
  posterior H1 монотонно растёт; 2 evidence противоречат друг другу — posterior
  размывается.
- `make_decision` — граничные значения posterior: {h0: 0.55, h1: 0.25, h2: 0.20} → H0_SAME;
  {h0: 0.35, h1: 0.45, h2: 0.20} → H_UNCERTAIN (нет доминирования).
- `rules_vote` — синтетический evidence, где срабатывает R_PAIR_GEOMETRY_ANOMALOUS
  (вес 0.95) — H2 должен доминировать.
- `impossible_reversal_detection` — синтетический временной ряд с искусственным
  «омоложением» на 5σ — детектируется как critical.
- `pelt_breakpoint_count` — синтетический временной ряд с известными 3 breakpoints —
  PELT находит все 3 ±1 позиция.
- `era_segmentation` — синтетический timeline с 2 явными эрами — сегментация
  находит обе.
- `visual_age_tolerance` — age_estimate = 48.5, chrono_age = 48.5 → delta=0,
  is_anomalous=False; age_estimate = 40, chrono_age = 55 → delta=-15,
  is_anomalous=True.

### 9.2 Интеграционные тесты

- На calibration-датасете (224 фото, ground truth известен): полный прогон
  байесовского движка + хронологии; сравнение вердиктов с ground truth.
- Negative control: 10 фото другого человека (не автора, не Путина) —
  все пары с автором должны получить H2_DIFFERENT.
- Prior sensitivity sweep: p_h0 меняется от 0.5 до 0.95 с шагом 0.05;
  для ≥ 80% фото вердикт стабилен.
- Проверка rule traceability: для 20 случайных фото из разных эпох —
  все имеют ≥ 1 rule_trace с непустым reason_ru.

### 9.3 Регрессионные тесты

- Сравнение вердиктов текущей версии (v4) и новой (v5) на 100 случайных фото:
  документировать все расхождения, каждое объяснить (новый evidence / исправленный баг).
- Ablation test: отключение каждого evidence-канала по очереди —
  измерить влияние на итоговый вердикт (через forensic/ablation.py).

---

## 10. Что явно НЕ входит в Этап 5

- Вычисление evidence (ICP, skin verdict) — **Этап 4**.
- Построение reference-моделей (калибровка шума) — **Этап 3**.
- Вычисление сырых метрик — **Этап 2**.
- Поза / реконструкция / выравнивание — **Этап 1**.
- Агрегация в отчёт, персоны, публикационный слой — **Этап 6**.
- Исправление багов в evidence (например, placeholder mesh_zones) — должно быть
  сделано на Этапах 2–4; Этап 5 потребляет уже исправленные evidence.

---

## 11. Зависимости от других этапов

```
Этап 1 (PREP)
    ↓ info.json (date, age, bucket, quality)
Этап 2 (METRICS)
    ↓ metrics.csv
Этап 3 (CALIBRATION)
    ↓ reference_geometry.json + reference_texture.json (priors baseline)
Этап 4 (PAIR & VERDICT)
    ↓ pairwise_evidence.jsonl + skin_verdicts.jsonl
Этап 5 (BAYES & CHRONO)      ← мы здесь
    ↓ forensic_verdicts.jsonl + pair_hypotheses.jsonl + timeline_analysis.json + anomalies.jsonl
Этап 6 (REPORT)
```

---

## 12. Приложение: выдержка из REFACTOR_PLAN.md — предупреждения, критичные для Этапа 5

### 12.1 Максимальная концентрация тонких багов

> `core/fuzzy_bayes/prob_logic.py` (676 строк) — ядро вероятностной модели. По находкам
> аналитиков — минимум 6 evidence-функций не эмитили H1 (частично починено).
> ... тут максимальная концентрация тонких багов во всём репо.

**Рекомендация:** переносить prob_logic.py **функцию за функцией** с юнит-тестом
«на синтетическом evidence вход X ожидаем долю H1 не ниже Y». Каждая функция
получает свой тест до того, как будет интегрирована в общий байесовский движок.

### 12.2 Два chronology-модуля с одинаковыми именами

> `core/chronology.py` (579 строк) и `core/fuzzy_bayes/chronology.py` —
> пересекаются по смыслу, имена модулей идентичны, но живут в разных пакетах.
> Это источник путаницы.

**Решение в новой версии:** единый `chrono/` пакет с явным разделением на
`chrono/timeline.py` (построение шкалы), `chrono/aging_curve.py` (кривая старения),
`chrono/anomaly_detector.py` (детекция аномалий), `chrono/era_segmenter.py` (PELT + Ward).

### 12.3 Rules → 0 гипотез H1_SYNTHETIC

> `core/fuzzy_bayes/rules.py`: 19 правил → H_CARRIER_SWITCH и 0 → H1_SYNTHETIC
> (частично починено).

**Решение:** построчный аудит каждого правила. Для каждого правила:
1. Какой evidence оно проверяет?
2. В какую гипотезу должен лить?
3. В какую гипотезу реально льёт?
4. Юнит-тест с синтетическим evidence, подтверждающий ожидаемое поведение.

---

*Версия: 1.0. Основано на REFACTOR_PLAN.md, текущем backend/core/fuzzy_bayes/, backend/forensic/.*

---

## Дополнение: Правки из аудита аналитиков (applicable к Этапу 5)

### 🔴 П1-02: Исправление маршрута доказательств силикона (H_CARRIER_SWITCH)
**Что**: В `hypothesis_keys.py` и `prob_logic.py` улики силикона ошибочно уводят в H2 вместо H1.
**Как**:
1. В `hypothesis_keys.py`: `H_CARRIER_SWITCH → H2` **удалить**. Carrier-evidence с высоким `silicone/texture_break` маршрутизировать в `H1_SYNTHETIC`
2. В `prob_logic.py`: порог `silicone >= 0.82` → понизить до `0.6` (конфиг-параметр `h1_silicone_threshold`)
3. В `rules.py`: 5 ключевых правил перенастроить:
   - `R_PAIR_TEXTURE_SYNTHETIC`: target → `H1_SYNTHETIC` (было `H_CARRIER_SWITCH`)
   - `R_PAIR_CROSS_MODAL_SUSPICIOUS`: target → `H1_SYNTHETIC`
   - `R_PAIR_IDENTITY_MATCH`: target → `H1_SYNTHETIC` при texture_break > 0.35
   - `R_PAIR_TEXTURE_SYNTHETIC` (ветка 2): target → `H1_SYNTHETIC` при mask_anomaly > 0.4
   - `R_PAIR_SYNTHETIC_CONTINUITY`: target → `H1_SYNTHETIC`
4. Юнит-тест: `assert posterior['H1_SYNTHETIC'] > 0.3` при silicone evidence = 0.7

### 🟡 П2-10: Проверка на биологически невозможные трансформации
**Что**: Резкие изменения геометрии могут быть «усреднены» другими метриками.
**Как**: Добавить проверку в Stage 5:
```
Для каждой пары фото с датами t1, t2:
  Если |intercanthal_dist(t2) - intercanthal_dist(t1)| > 0.8 мм → flag IMPOSSIBLE_TRANSFORMATION
  Если |zygomatic_width(t2) - zygomatic_width(t1)| > 1.2 мм → flag IMPOSSIBLE_TRANSFORMATION
  Если inverted_asymmetry(orbit) → flag IMPOSSIBLE_TRANSFORMATION
При наличии IMPOSSIBLE_TRANSFORMATION → принудительно H2 или H1 (в зависимости от зоны)
```

### 🟡 П2-11: Переход на Likelihood Ratio (LR)
**Что**: Простая вероятность P(H|E) уязвима для критики (зависит от априорных).
**Как**:
1. Заменить расчёт вероятности на LR: `LR = P(E|H1) / P(E|H0)`
2. Формула для каждой улики: `LR_i = P(evidence_i | H1) / P(evidence_i | H0)`
3. Итоговый LR по всем уликам: `LR_total = product(LR_i)` (независимые улики)
4. Интерпретация: `LR > 100` = «сильное доказательство H1», `LR < 0.01` = «сильное доказательство H0»
5. Пороги LR вынести в конфиг (см. П3-32)

### 🟢 П3-15: Деканонизация меша перед сравнением (вычитание ракурсного шума)
**Что**: 3DDFA_v3 вносит систематическую ошибку при разных ракурсах.
**Как**:
1. На калибровочном датасете (твои фото) найти пары с одинаковыми углами позы
2. Вычислить `epsilon(theta_A, theta_B) = V(C_A) - V(C_B)` — погрешность алгоритма
3. Вычесть из основных сравнений: `Delta_true = || (V(P_A) - V(P_B)) - epsilon ||`

### 🟢 П3-16: Мониторинг межорбитального расстояния
**Как**: `D_interorb(t)` — фильтр Калмана. Порог: `|D(t2) - D(t1)| > 0.8 мм` → маркер другого человека.

### 🟢 П3-17: Детектор инверсии скуловой ширины
**Как**: Если изменение > `±1.2 мм` с обратным скачком → фиксировать нарушение.

### 🟢 П3-18: Градиент скорости опускания латеральных углов глаз
**Как**: Если за `< 6 месяцев` угол увеличивается `> 1.5°` → флаг подмены/маски.

### 🟢 П3-19: Детектор изменения высоты нижней трети лица
**Как**: Если за `2 недели` высота увеличивается `> 2.5%` → флаг невозможной трансформации.

### 🟢 П3-20: Анализ динамики асимметрии глазных впадин
**Как**: Зеркальная инверсия знака асимметрии → биологически невозможно.

### 🟢 П3-21: Мониторинг истончения красной каймы губ
**Как**: Резкое увеличение высоты верхней губы без отёка → накладка.

### 🟢 П3-22: Постоянство угла наклона ушных раковин
**Как**: Изменение расстояния `Tragus–Exocanthion > 2.0 мм` → исключает тождество.

### 🟢 П3-23: Хронологический контроль периметра глазниц
**Как**: Сужение периметра с возрастом → другой человек.

### 🟢 П3-24: Фильтр скорости птоза подбородка
**Как**: Резкое становление очерченным → смена дублера.

### 🟢 П3-25: Детектор инверсии кривизны надбровных дуг
**Как**: Переход от массивных дуг к плоскому лбу → подмена черепа.

### 🟢 П3-26: Контроль проекции скуловых дуг в профиле
**Как**: Внезапное изменение проекции на дни/месяцы → опровергает тождество.

### 🟢 П3-27: Мониторинг вертикальных пропорций третей лица
**Как**: Колебания `T1/T2` и `T2/T3` `> 3.5%` → смена дублеров.

### 🟢 П3-28: Стабильность подбородочной выемки
**Как**: Резкий переход от глубокой к плоской выемке → смена носителя.

### 🟢 П3-29: Фильтр отражающей способности спинки носа
**Как**: Смена узкого костного блика на широкое диффузное пятно → силиконовая маска.

### 🟢 П3-30: Комплексный хроно-индекс невозможной жизни
**Как**: Агрегация всех хронологических аномалий в единый индекс `I_impossible(t)`. При `I > 0.85` → заключение о юридически доказанном нарушении биологии.

### 🟡 П2-13 (часть): Evidence Log — Stage 5 output
На выходе Этапа 5 сохранять `evidence_stage5.json`:
```json
{
  "photo_id": "...",
  "bayes_posterior": {"H0": 0.12, "H1": 0.78, "H2": 0.10},
  "lr_total": 342.5,
  "lr_by_channel": {"geometry": 12.3, "texture": 28.1, "chrono": 1.02},
  "impossible_flags": ["intercanthal_shift_1.2mm", "zygomatic_inversion"],
  "chrono_anomalies": ["aging_velocity_spike_2018", "asymmetry_inversion_2021"],
  "verdict_summary_ru": "Обнаружены признаки силиконовой маски на скулах (LR=342) и невозможная трансформация межорбитального расстояния"
}
```
