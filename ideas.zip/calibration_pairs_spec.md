# calibration_pairs_spec.md — Пары для калибровки Stage 3

## Назначение

`calibration_pairs.json` — набор оптимальных пар фотографий для:
1. Попарного сравнения в Stage 4 (pairwise verdict)
2. Оценкиintra-class variability (насколько сильно метрики различаютсяwithin class)
3. Валидации shift_model на hold-out (pair-level accuracy)

---

## Структура

```json
{
  "version": "string",
  "n_pairs": int,
  "pairs": [
    {
      "pair_id": "CAL_P_0001",
      "class": "real",  // real | silicone

      "photo_a": {
        "photo_id": "string",
        "path": "string",
        "bucket": "frontal|right_threequarter|...",
        "epoch": "legacy|recent",
        "quality": {"q_noise_level": 0.x, "q_blur_level": 0.x, "q_overall": 0.x}
      },

      "photo_b": {
        "photo_id": "string",
        "path": "string",
        "bucket": "...",
        "epoch": "...",
        "quality": {...}
      },

      "pair_metadata": {
        "mean_quality": 0.x,
        "quality_spread": 0.x,
        "bucket_match": bool,
        "epoch_match": bool,
        "n_valid_metrics": int,
        "top5_auc_metrics": ["glcm_dissimilarity_d5_a0", ...],
        "pair_score": 0.x
      },

      "reference_shifts": {
        // Z-score отклонения метрик от когортного reference
        // Используются длявалидации shift_model
      }
    }
  ],

  "coverage": {
    "total_real_pairs": int,
    "total_silicone_pairs": int,
    "buckets_covered": ["frontal", ...],
    "epochs_covered": ["legacy", "recent"],
    "calibration_pairs_by_bucket": {
      "frontal": {"real": int, "silicone": int}
    }
  }
}
```

---

## Критерии отбора пар

### Обязательные (hard constraints)

| Критерий | Порог | Обоснование |
|---|---|---|
| Оба фото ∈ calibration set | — | Есть истиные метрики и качество |
| n_valid_metrics в паре | ≥ 5 с AUC ≥ 0.85 | Достаточно для статистики |
| Оба фото same epoch | — | Исключить epoch-confounded пары |
| Quality anomaly | < 2σ от epoch+bucket model | Только "типичные" фото |

### Опциональные (soft constraints, maximize)

| Критерий | Bonus | Обоснование |
|---|---|---|
| bucket_match == True | +0.2 | Исключить bucket-confounded сравнения |
| quality_spread > 0.1 | +0.1 | Варьируемое качество = robustness test |
| top5_auc_metrics overlap > 3 | +0.1 | Обе фото informative по одним метрикам |
| rare bucket (coverage) | +0.15 | Нужно покрытие всех bucket |

### Формула pair_score

```
pair_score = w1 * mean_auc + w2 * quality + w3 * bucket_match + w4 * epoch_match + w5 * coverage_bonus

где:
  w1 = 0.40 (AUC главный критерий)
  w2 = 0.20 (качество важно)
  w3 = 0.15
  w4 = 0.10
  w5 = 0.15
```

---

## Алгоритм selection

```
Input: calibration_photos (N фото), leaderboard (top-50 metrics with AUC)

1. Групппируем фото по (class, epoch, bucket)
2. Для каждой группы:
   a. Считаем pair_score для всех возможных пар (N*(N-1)/2)
   b. Сортируем по pair_score descending
   c. Отбираем top-K пар, где K = min(3, len(pairs))  # max 3 per sample
   d. Удаляем отобранные фото из пула (избегаем переиспользования)
3. Добираем из редких bucket/epochs пока coverage.buckets и coverage.epochs не заполнены
4. Финальный отсев: удаляем пары с quality_anomaly > 2σ

Output: calibration_pairs.json
```

---

## Валидация

После построения `calibration_pairs.json`:
1. Проверить: все ключевые метрики присутствуют в ≥5% пар
2. Проверить: coverage покрывает ≥80% bucket-epoch комбинаций
3. Проверить: real/silicone баланс (ratio в пределах 0.5–2.0)
4. Проверить: на hold-out 20% пар accuracy не падает >5% vs train accuracy

---

## Пример

```json
{
  "pair_id": "CAL_P_0042",
  "class": "silicone",
  "photo_a": {
    "photo_id": "silicone_2019_07_22_right3q",
    "bucket": "right_threequarter",
    "epoch": "recent",
    "quality": {"q_noise_level": 0.28, "q_blur_level": 0.45, "q_overall": 0.79}
  },
  "photo_b": {
    "photo_id": "silicone_2021_03_15_right3q",
    "bucket": "right_threequarter",
    "epoch": "recent",
    "quality": {"q_noise_level": 0.31, "q_blur_level": 0.52, "q_overall": 0.74}
  },
  "pair_metadata": {
    "mean_quality": 0.765,
    "quality_spread": 0.07,
    "bucket_match": true,
    "epoch_match": true,
    "n_valid_metrics": 12,
    "top5_auc_metrics": ["glcm_dissimilarity_d5_a0", "glcm_homogeneity_d5_a0", "lbp_uniform_r5_std"],
    "pair_score": 0.89
  }
}
```