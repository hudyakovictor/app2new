# RECALIBRATION MANUAL — DASVE
## Как откалибровать Degradation-Aware Shift Verdict Engine под новый датасет

**Для кого:** Инженеры, аналитики, которым нужно перекалибровать DASVE
после обнаружения systematic bias или недостаточной точности.

**Когда читать:**
- Точность на новом датасете < 0.90
- Систематический bias: например, real фото классифицируются как silicone
- Появились новые эпохи/bucket, не покрытые текущей калибровкой
- Распределение качества в продакшене отличается от калибровочного

---

## ЧАСТЬ 1: БЫСТРЫЙ DIAGNOSTIC

### 1.1 Проверка симптомов

Запустить diagnostic:

```bash
python scripts/diagnostic.py \
    --reference reference_texture.json \
    --test-metrics /path/to/test_metrics.csv \
    --test-labels /path/to/test_labels.csv \
    --output diagnostic_report.json
```

Или вручную — проверить эти симптомы:

| Симптом | Возможная причина | Что делать |
|---------|------------------|-----------|
| Accuracy < 0.85 на clean фото | Неверные cohort statistics | Пересобрать reference_texture.json (Часть 2) |
| Accuracy падает < 0.80 при шуме | HF thresholds слишком высокие | Понизить hf_discount_threshold до 0.55 (Часть 3) |
| Real фото系统性но → silicone | Shift coefficients занижены для real | Проверить direction в leaderboard (Часть 4) |
| Silicone → real (reverse bias) | Cohorts перепутаны при построении | Проверить label polarity (Часть 2.3) |
| Большой разброс confidence | Нестабильность метрик | Добавить robust_metrics в configs |
| Accuracy падает на legacy фото | Epoch смешивание | Проверить epoch разбиение (Часть 5) |

### 1.2 Ключевые метрики для проверки

```python
# Проверить распределение shift_scores
import numpy as np
from scipy import stats

real_shifts  = [s for s, label in zip(shifts, labels) if label == "real"]
sil_shifts   = [s for s, label in zip(shifts, labels) if label == "silicone"]

print(f"Real shift:    mean={np.mean(real_shifts):.3f}, std={np.std(real_shifts):.3f}")
print(f"Silicone shift: mean={np.mean(sil_shifts):.3f}, std={np.std(sil_shifts):.3f}")
print(f"Separation: {np.mean(sil_shifts) - np.mean(real_shifts):.3f}")

# Проверить нормальность
_, p_real = stats.shapiro(real_shifts)
_, p_sil  = stats.shapiro(sil_shifts)
print(f"Shapiro-Wilk p: real={p_real:.4f}, sil={p_sil:.4f}")
# Если p < 0.05 → нормальность отвергается → использовать Mann-Whitney вместо z-score
```

### 1.3 Логирование проблемных фото

```bash
python scripts/find_problematic_photos.py \
    --reference reference_texture.json \
    --metrics /path/to/all_metrics.csv \
    --labels /path/to/all_labels.csv \
    --output problem_photos.json

# Затем посмотреть:
# - Какие фото систематически ошибаются
# - Их epoch, bucket, quality
# - Какие метрики дают аномальные значения
```

---

## ЧАСТЬ 2: ПЕРЕСБОРКА REFERENCE_TEXTURE.JSON

### 2.1 Когда делать

- Увеличился калибровочный датасет
- Появились фото из новых эпох/bucket
- обнаружен systematic bias в вердиктах
- Accuracy на hold-out < 0.90

### 2.2 Пошаговая инструкция

**Шаг 1: Подготовить калибровочные данные**

```
calibration/
├── real/
│   ├── photo_001.jpg
│   ├── photo_002.jpg
│   └── ...
└── silicone/
    ├── mask_001.jpg
    └── ...
```

Требования:
- Только фото с известной истиной меткой (real/silicone)
- Качество: q_overall ≥ 0.70 (для чистой базы)
- Покрытие: все epoch и bucket, которые будут в продакшене
- Минимум: 10 фото на класс, 3 фото на bucket

**Шаг 2: Извлечь метрики**

```bash
python scripts/extract_stress_metrics.py \
    --input-dir /path/to/calibration \
    --leaderboard assets/clean_feature_leaderboard.csv \
    --output metrics_calibration.csv \
    --max-per-class 100
```

**Шаг 3: Построить reference**

```bash
python scripts/build_texture_reference.py \
    --calibration-real-dir /path/to/calibration/real \
    --calibration-sil-dir  /path/to/calibration/silicone \
    --leaderboard assets/clean_feature_leaderboard.csv \
    --output reference_texture.json \
    --n-per-class 100
```

**Шаг 4: Валидировать**

```bash
python scripts/validate_reference.py \
    --reference reference_texture.json
```

Ожидаемый вывод: `"errors": []`

### 2.3 Частые проблемы при пересборке

**Проблема:** Cohorts пустые (n=0)
**Причина:** Фото не найдены или неправильный формат
**Решение:**
```python
# Проверить, какие файлы видит скрипт
from pathlib import Path
folder = Path("/path/to/calibration/real")
files = [p for p in folder.iterdir() if p.suffix.lower() in {".png", ".jpg", ".jpeg"}]
print(f"Found {len(files)} files: {files[:5]}")
```

**Проблема:** Silicone cohort shift в неправильную сторону (real → silicone)
**Причина:** Перепутаны label при построении
**Решение:** Проверить в build_texture_reference.py:
```python
for label, folder in [(0, args.calibration_real_dir), (1, args.calibration_sil_dir)]:
    # label=0 должен быть real, label=1 должен быть silicone
```

**Проблема:** Reference не покрывает новые bucket
**Причина:** В калибровочном датасете нет фото для этих bucket
**Решение:** Добавить фото для редких bucket, затем пересобрать.
Если это невозможно — использовать global cohorts как fallback
(код в quality_compensated_verdict.py уже это делает).

---

## ЧАСТЬ 3: КОРРЕКТИРОВКА QUALITY THRESHOLDS

### 3.1 Когда делать

- Accuracy падает при шуме/blur ниже ожидаемого
- HF метрики дают ложные значения при среднем качестве
- хочется более консервативный или более агрессивный вердикт

### 3.2 Параметры для настройки

В `configs/quality_compensation_engine.yaml`:

```yaml
hf_discount:
  discount_threshold:  0.60   # Менять первым
  zero_threshold:      0.40

robust_boost:
  factor: 0.5
```

### 3.3 Как подбирать thresholds

**Метод 1: Визуальный по robustness matrix**

Открыть `assets/stress_robustness_matrix.csv`:

```
metric,clean,noise_s1,noise_s5,blur_s1,blur_s5,combo_s1,combo_s5,mean_auc
glcm_dissimilarity_d5_a0,0.961,0.958,0.940,0.935,0.920,0.910,0.890,0.945
```

Найти уровень стресса, при котором метрика начинает деградировать.
Это и есть ваш `discount_threshold`.

**Пример:** GLCM dissimilarity начинает деградировать при blur_s3 (AUC=0.93).
Если средний q_blur_level для blur_s3 ≈ 0.60 — ставьте `discount_threshold = 0.60`.

**Метод 2: Автоматический search**

```bash
python scripts/tune_thresholds.py \
    --reference reference_texture.json \
    --metrics metrics_calibration.csv \
    --labels labels_calibration.csv \
    --output tuned_thresholds.json
```

Это перебирает discount_threshold ∈ [0.40, 0.70] с шагом 0.05
и zero_threshold ∈ [0.20, 0.45] с шагом 0.05,
выбирает комбинацию с максимальным accuracy на hold-out.

### 3.4 Рекомендации по thresholds

| Ситуация | discount_threshold | zero_threshold |
|----------|-------------------|----------------|
| Качественные фото (q > 0.8) | 0.55 | 0.35 |
| Смешанный датасет | 0.60 | 0.40 (default) |
| Преимущественно шумные фото | 0.65 | 0.45 |
| Очень консервативный вердикт | 0.70 | 0.50 |

---

## ЧАСТЬ 4: КОРРЕКТИРОВКА SHIFT COEFFICIENTS

### 4.1 Когда делать

- Определённые метрики дают систематический bias в одну сторону
- хочется усилить/ослабить вклад конкретных метрик
- Появились новые informative метрики не в leaderboard

### 4.2 Ручная корректировка coefficients

В `configs/shift_model_config.yaml`:

```yaml
manual_coefficients_override:
  glcm_dissimilarity_d5_a0: 2.0   # Понизить если переобучение
  glcm_dissimilarity_d5_a0: 3.5   # Повысить если недообучение
  color_b_mean: 1.5               # Понизить если systematic color bias
```

### 4.3 Проверка direction

Каждая метрика должна иметь правильный direction:
- `higher_real` → метрика выше у real skin
- `higher_silicone` → метрика выше у silicone mask

Проверить в `clean_feature_leaderboard.csv`:

```
name,direction,real_mean,silicone_mean
glcm_dissimilarity_d5_a0,higher_real,1.827,1.323
color_b_mean,higher_silicone,94.65,127.94
```

Если direction неправильный → вручную инвертировать sign в coefficients.

### 4.4 Автоматическая переоценка coefficients

Если калибровочный датасет изменился существенно:

```bash
python scripts/recompute_coefficients.py \
    --metrics metrics_calibration.csv \
    --labels labels_calibration.csv \
    --output new_coefficients.csv

# Затем обновить coefficients в reference_texture.json:
python scripts/update_reference_coefficients.py \
    --reference reference_texture.json \
    --coefficients new_coefficients.csv \
    --output reference_texture_updated.json
```

### 4.5 Если метрики дают разные результаты на разных bucket

Создать bucket-specific coefficients:

```yaml
bucket_specific_coefficients:
  frontal:
    glcm_dissimilarity_d5_a0: 2.6  # Использовать эти вместо глобальных
  right_profile:
    glcm_dissimilarity_d5_a0: 2.0   # Профильные фото менее информативны
```

Для этого нужно сначала проверить AUC per bucket:

```python
from sklearn.metrics import roc_auc_score
import pandas as pd

df = pd.read_csv("metrics_calibration.csv")
for bucket in df["bucket"].unique():
    bucket_df = df[df["bucket"] == bucket]
    auc = roc_auc_score(bucket_df["label"], bucket_df["glcm_dissimilarity_d5_a0"])
    print(f"{bucket}: AUC={auc:.3f}")
```

---

## ЧАСТЬ 5: КОРРЕКТИРОВКА EPOCH/BUCKET NOISE MODEL

### 5.1 Когда делать

- Epoch-specific accuracy сильно отличается
-某些 bucket дают систематический bias
- Появились фото из новой эпохи (например, 2026+)

### 5.2 Пересборка noise_model

```bash
python scripts/build_noise_model.py \
    --calibration-real-dir /path/to/real \
    --calibration-sil-dir /path/to/silicone \
    --leaderboard assets/clean_feature_leaderboard.csv \
    --output noise_model_calibration.json

# Добавить в reference_texture.json:
python scripts/merge_noise_model.py \
    --reference reference_texture.json \
    --noise-model noise_model_calibration.json \
    --output reference_texture_with_noise.json
```

### 5.3 Настройка anomaly detection

В `configs/noise_model_config.yaml`:

```yaml
anomaly_detection:
  sigma_threshold: 2.0     # Понизить до 1.5 если много false positive
                          # Повысить до 2.5 если много false negative
  action_on_anomaly:
    reduce_confidence: true
    confidence_penalty: 0.20  # Настроить силу penalty
```

### 5.4 Как проверить, нужен ли epoch split

```python
# Если accuracy на legacy < 0.85, нужен отдельный epoch split
legacy_acc = accuracy_for_epoch("legacy")
recent_acc = accuracy_for_epoch("recent")

if abs(legacy_acc - recent_acc) > 0.10:
    print("WARNING: Significant epoch bias detected")
    print(f"  Legacy accuracy: {legacy_acc:.3f}")
    print(f"  Recent accuracy: {recent_acc:.3f}")
    print("  → Split noise_model_by_epoch or use epoch-specific thresholds")
```

---

## ЧАСТЬ 6: ПРОВЕРКА КАЛИБРОВКИ end-to-end

### 6.1 Чеклист перед продакшеном

После всех настроек — запустить полную проверку:

```bash
python scripts/full_calibration_check.py \
    --reference reference_texture.json \
    --calibration-dir /path/to/calibration \
    --leaderboard assets/clean_feature_leaderboard.csv \
    --output calibration_report.json
```

**Ожидаемые результаты:**

| Тест | Порог |
|------|-------|
| Clean accuracy | ≥ 0.95 |
| LOO-CV AUC | ≥ 0.98 |
| Hold-out accuracy | ≥ 0.90 |
| combo_s5 accuracy | ≥ 0.85 |
| Legacy epoch accuracy | ≥ 0.85 |
| Real/Silicone bias | < 0.05 (symmetric) |
| Mean confidence | > 0.60 |
| Anomaly detection | Нет ложных срабатываний на clean фото |

### 6.2 Интерпретация результатов

Если что-то не сходится:

```
Accuracy < 0.90 на clean:
  → Пересобрать reference_texture.json (Часть 2)
  → Проверить cohort polarity (Часть 2.3)

combo_s5 accuracy < 0.85:
  → Понизить hf_discount_threshold (Часть 3)
  → Проверить что frequency_ratios работают

Legacy accuracy < 0.85:
  → Noise model не покрывает legacy эпоху (Часть 5)
  → Или использовать только robust_metrics для legacy фото

Systematic bias (real→silicone или наоборот):
  → Проверить direction в leaderboard (Часть 4.3)
  → Пересчитать coefficients (Часть 4.4)

High variance confidence:
  → Добавить больше robust_metrics
  → Проверить quality_gate thresholds (Часть 5)
```

### 6.3 Финальное сохранение

После успешной калибровки:

```bash
# Сохранить все конфиги в versions/
cp configs/ versions/calibration_$(date +%Y%m%d)/

# Записать metadata
python scripts/save_calibration_metadata.py \
    --reference reference_texture.json \
    --config-dir configs/ \
    --output calibration_metadata.json

# Добавить в reference:
# reference_texture.json["calibration_metadata"] = calibration_metadata.json
```

---

## ЧАСТЬ 7: TROUBLESHOOTING MATRIX

| Проблема | Первый шаг | Второй шаг |
|----------|-----------|-----------|
| "Reference validation fails" | Проверить schema specs/ | Проверить что n > 0 для всех cohorts |
| "Metrics missing from reference" | Проверить что метрика есть в leaderboard | Добавить вручную в cohorts |
| "Verdict always 'uncertain'" | Проверить quality_gate thresholds | Проверить confidence_lower_bound |
| "Prob_silicone always > 0.5" | Проверить cohort polarity | Инвертировать direction |
| "Slow inference (>5s)" | Уменьшить n_metrics до top-20 | Отключить heavy families |
| "Gabor segmentation fault" | Убедиться что gabor исключён | Проверить memory limit |
| "Bucket-specific bias" | Вычислить AUC per bucket | Добавить bucket coefficients (Часть 4.5) |
| "Epoch confusion" | Увеличить n_calibration_samples | Понизить epoch_cutoff_year |

---

## ПРИЛОЖЕНИЕ A: Формулы

### Effective quality
```
eq = 0.40 * q_overall + 0.35 * (1 - q_noise_level) + 0.25 * (1 - q_blur_level)
```

### HF discount
```
discount = 1.0                                     if eq >= 0.60
discount = (eq - 0.40) / 0.20                     if 0.40 < eq < 0.60
discount = 0.0                                     if eq <= 0.40
```

### Shift score
```
raw_shift[m]  = (value[m] - cohort_mean[m]) / cohort_std[m]
comp_shift[m] = raw_shift[m] * discount * cohens_d[m]
ratio_score   = sum(ratio[r] * ratio_coef[r])
total_score   = sum(comp_shift) / sum(coef) + ratio_weight * ratio_score
prob_silicone = sigmoid(total_score)
```

### Sigmoid
```
sigmoid(x) = 1 / (1 + exp(-x / temperature))
```

---

## ПРИЛОЖЕНИЕ B: Ключевые файлы для калибровки

| Файл | Зачем менять | Как менять |
|------|-------------|-----------|
| `reference_texture.json` | Cohort statistics, coefficients | Пересобрать (Часть 2) |
| `configs/quality_compensation_engine.yaml` | HF/RF lists, thresholds, weights | Вручную (Часть 3, 4) |
| `configs/shift_model_config.yaml` | Inclusion thresholds, aggregation | Вручную (Часть 4) |
| `configs/noise_model_config.yaml` | Epoch/bucket model, anomaly detection | Вручную (Часть 5) |
| `calibration_pairs.json` | Pair selection criteria | Пересобрать select_calibration_pairs.py |

---

## ПРИЛОЖЕНИЕ C: Контакты для поддержки

Если калибровка не получается после всех шагов:

1. Собрать diagnostic report (Часть 1.1)
2. Приложить calibration_metadata.json
3. Приложить 5-10 проблемных фото с their metrics
4. Проверить issue tracker на похожие проблемы