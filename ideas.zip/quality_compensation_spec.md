# quality_compensation_spec.md — Как работает Quality-Aware Shift

## Проблема

Стандартные текстурные метрики (GLCM, LBP, градиенты) чувствительны к шуму и blur.
При плохом качестве фото они дают ложные значения → ложный вердикт.

**Пример:** На чистом фото GLCM dissimilarity_d5 = 1.8 (real). На шумном фото —
1.3 (становится ближе к silicone). Классификатор ошибается.

## Решение: два механизма компенсации

### Механизм A: Quality-Conditioned Interaction Space

Идея: не бороться с шумом вычислительно, а **изменить веса** метрик в зависимости
от качества.

```
X_raw       = вектор метрик
Q           = [q_noise_level, q_blur_level, q_overall]
X_corrected = X_raw * f(Q)

где f(Q) — discount function:
  f(Q) = 1.0                   при Q >= hf_discount_threshold (0.6)
  f(Q) = (Q - hf_zero) / (hf_discount - hf_zero)   при hf_zero < Q < hf_discount
  f(Q) = 0.0                   при Q <= hf_zero (0.4)
```

Для robust метрик — наоборот, boost при плохом качестве:
```
X_robust_corrected = X_robust * (1.0 + (1.0 - Q) * 0.5)
```

### Механизм B: Multi-Scale Frequency Ratios

Идея: отношения метрик разных масштабов **инвариантны к качеству**.

```
ratio_macro_micro = residual_bio_iqr / glcm_dissimilarity_d1_a0
ratio_color_entropy = color_b_mean / entropy_w15_mean
```

Эти отношения характеризуют тип поверхности (кожа vs силикон) независимо от
уровня шума, потому что шум одинаково влияет на numerator и denominator.

## Финальный скоринг

```python
def shift_score(metrics, reference, quality):
    eq = effective_quality(quality)  # [0..1]

    # 1. Baseline shifts
    shifts = compute_zscore_shifts(metrics, reference)

    # 2. Quality compensation for HF metrics
    if eq < 0.6:
        discount = (eq - 0.4) / 0.2  # 0..1
        for m in hf_metrics:
            shifts[m] *= discount
    if eq < 0.4:
        for m in hf_metrics:
            shifts[m] = 0.0

    # 3. Frequency ratios (not affected by quality)
    ratios = compute_frequency_ratios(metrics)

    # 4. Combine
    weighted = sum(shifts[m] * coef[m] for m in shifts)
    weighted += sum(ratios[r] * ratio_coef[r] for r in ratios)

    # 5. Sigmoid
    prob_silicone = sigmoid(weighted)

    return prob_silicone, eq, shifts, ratios
```

## Параметры (из экспериментов)

| Параметр | Значение | Обоснование |
|---|---|---|
| hf_discount_threshold | 0.6 | GLCM/LBP начинают деградировать при q < 0.6 |
| hf_zero_threshold | 0.4 | При q < 0.4 GLCM полностью бесполезен |
| robust_boost_factor | 0.5 | Умеренный boost, не перевешивает HF |
| ratio_coef | 0.5 | Отношения вносят ~30% в финальный score |

## Верификация

После построения shift_model на калибровочных данных — проверить на hold-out:
```
На stress_test_unified_metrics (320 фото):
  - Accuracy на combo_s5 должна быть ≥ 0.85
  - Mean prob_silicone для real на combo_s5 не должна превышать 0.35
  - Mean prob_silicone для silicone на combo_s5 не должна быть ниже 0.65
```

Если точность падает ниже порога — пересмотреть hf_metrics/robust_metrics разбиение
или thresholds.