# ТЗ — Этап 6 «REPORT»: агрегация, персоны/эры, публикационный слой, экспорт

Версия: 1.0. Продолжение `STAGE5_TZ.md`. Основано на анализе текущего `backend/` (NEWWAP),
`aboutplatform.txt`, `AGENTS.md`, `REFACTOR_PLAN.md`. Формат — самодостаточное инженерное ТЗ: цель,
границы, входы/выходы, пошаговый алгоритм, контракты данных, обработка ошибок,
критерии приёмки, тест-план, порядок переноса кода.

---

## 1. Цель этапа

Превратить **сырые форензик-результаты** (байесовские вердикты, хронологические
аномалии, попарные evidence из Этапов 4–5) в **готовые к публикации и внешнему
аудиту материалы**:

1. **Финальный отчёт** — структурированный документ (JSON + human-readable Markdown)
   с полной цепочкой доказательств: от исходных фото до байесовского вердикта,
   с тезисами, пригодными для цитирования журналистом/экспертом.
2. **Персоны и эры** — высокоуровневая агрегация: какие «версии» лица субъекта
   выделяются, в какие периоды какая «версия» доминирует, какие ключевые события
   (операции, смены маски) идентифицированы.
3. **Публикационный слой** — адаптация вывода для разных аудиторий:
   forensic-эксперт (полные данные), журналист (тезисы + визуализации),
   external reviewer (методология + контрольные группы).
4. **Экспорт** — машиночитаемые форматы для внешних инструментов:
   CSV для статистического анализа, JSON для API, Markdown/PDF для публикации.

**Критическое архитектурное ограничение** (из REFACTOR_PLAN.md):
> Этап 6 — чистая агрегация/представление, **не должна содержать вычислительной
> логики вообще**. Сейчас `core/service.py` (2240 строк) смешивает API, репортинг
> и часть бизнес-логики вердикта — это корень многих багов.

Этап 6 **не вычисляет** ни одного нового числа, не принимает ни одного решения
real/silicone/H0/H1. Он только:
- читает готовые результаты Этапов 1–5;
- группирует, фильтрует, форматирует;
- генерирует текст на русском (тезисы, описания эр);
- сопоставляет с внешними публикациями;
- экспортирует в целевые форматы.

---

## 2. Входы и выходы

### 2.1 Вход

```
# Из Этапа 1 (метаданные):
storage/main/{photo_id}/info.json     # date, age, bucket, quality, expression flags

# Из Этапа 4 (evidence):
storage/results/pairwise_evidence.jsonl
storage/results/skin_verdicts.jsonl

# Из Этапа 5 (вердикты и хронология):
storage/results/forensic_verdicts.jsonl
storage/results/pair_hypotheses.jsonl
storage/results/timeline_analysis.json
storage/results/anomalies.jsonl

# Внешние данные (опционально):
_archive/misc/publications.json       # внешние публикации о субъекте (статьи, фото)
storage/calibration/reference_geometry.json   # для methodological transparency
storage/calibration/reference_texture.json
```

### 2.2 Выход

```
storage/results/report/
├── final_report.md                  # основной отчёт (Markdown, human-readable, RU)
├── final_report.json                # основной отчёт (JSON, machine-readable, все данные)
├── executive_summary.md             # краткое резюме на 1 страницу (RU + EN)
├── forensic_findings.json           # структурированные forensic-находки
│
├── personas/
│   ├── personas.json                # описание выделенных «персон» (версий лица)
│   └── persona_fingerprints.json    # «отпечатки» каждой персоны (ключевые метрики)
│
├── eras/
│   └── era_summaries.json           # сводка по каждой эре с ключевыми verdict-статистиками
│
├── exports/
│   ├── all_verdicts.csv             # плоская CSV-таблица: все фото × все метрики × вердикт
│   ├── anomalies.csv                # CSV хронологических аномалий
│   ├── methodology.json             # методология для external review
│   └── evidence_chain.json          # полная evidence-цепочка для аудита
│
├── visualizations/                  # (опционально) пути к статическим графикам
│   ├── aging_curve.png
│   ├── verdict_timeline.png
│   └── era_transitions.png
│
└── publication_bundle/
    ├── journalist_thesis_ru.md      # тезисы для журналиста (RU)
    ├── journalist_thesis_en.md      # тезисы для журналиста (EN)
    ├── faq.md                       # anticipated questions & answers
    └── citations.bib                # BibTeX цитат для академической публикации
```

---

## 3. Архитектура: чистый Presentation Layer

```
┌─────────────────────────────────────────────────────────────┐
│                    DATA LAYER (read-only)                    │
│                                                             │
│  forensic_verdicts.jsonl    timeline_analysis.json          │
│  pair_hypotheses.jsonl      anomalies.jsonl                 │
│  pairwise_evidence.jsonl    reference_*.json                │
│  skin_verdicts.jsonl        info.json (всех фото)           │
└────────────────────────┬────────────────────────────────────┘
                         │
         ┌───────────────┼───────────────┐
         │               │               │
┌────────▼──────┐ ┌──────▼───────┐ ┌─────▼──────────────┐
│  AGGREGATOR   │ │  PERSONA     │ │  PUBLICATION       │
│               │ │  BUILDER     │ │  CORRELATOR        │
│               │ │              │ │                    │
│ • Группировка │ │ • Кластери-  │ │ • Сопоставление с  │
│   по эрам     │ │   зация фото │ │   внешними         │
│ • Группировка │ │   по вердикту│ │   публикациями     │
│   по ракурсам │ │   и дате     │ │   о субъекте       │
│ • Статистики  │ │              │ │                    │
│   (доли       │ │ • Выделение   │ │ • Хронологическая │
│   H0/H1/H2)   │ │   «персон»   │ │   привязка:       │
│ • Тренды      │ │   (версий    │ │   какая персона    │
│               │ │   лица)      │ │   на каких         │
│               │ │              │ │   публичных фото    │
│               │ │ • «Отпечатки»│ │                    │
│               │ │   персон     │ │                    │
│               │ │   (ключевые  │ │                    │
│               │ │   метрики)   │ │                    │
└────────┬──────┘ └──────┬───────┘ └─────┬──────────────┘
         │               │               │
         └───────────────┼───────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│                    TEXT GENERATOR                             │
│                                                              │
│  • Генерация тезисов на русском (детерминированные шаблоны)  │
│  • Описания эр: «Период до 2011: высокая согласованность...» │
│  • Описания аномалий: «Невозможное омоложение нижней челюсти»│
│  • FAQ: предвосхищение вопросов и возражений                 │
│  • Executive summary (RU + EN)                               │
└────────────────────────┬────────────────────────────────────┘
                         │
┌────────────────────────▼────────────────────────────────────┐
│                    EXPORT LAYER                              │
│                                                              │
│  • CSV: плоские таблицы для Excel / pandas / R              │
│  • JSON: structured data для API / внешних систем           │
│  • Markdown: human-readable отчёты                          │
│  • BibTeX: цитирования для academic publishing              │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. Пошаговый алгоритм

### Часть A: Aggregator

#### Шаг A.1: Загрузка всех данных

```python
def load_all_results() -> ReportDataset:
    """Загружает все артефакты Этапов 1-5 в память."""
    return ReportDataset(
        verdicts=load_jsonl("forensic_verdicts.jsonl"),
        pair_hypotheses=load_jsonl("pair_hypotheses.jsonl"),
        pairwise_evidence=load_jsonl("pairwise_evidence.jsonl"),
        skin_verdicts=load_jsonl("skin_verdicts.jsonl"),
        timeline=load_json("timeline_analysis.json"),
        anomalies=load_jsonl("anomalies.jsonl"),
        photos={pid: load_json(f"storage/main/{pid}/info.json") 
                for pid in all_photo_ids},
        reference_geometry=load_json("reference_geometry.json"),
        reference_texture=load_json("reference_texture.json"),
    )
```

#### Шаг A.2: Группировка вердиктов по эрам

```
использовать eras из timeline_analysis.json:
для каждой era в timeline.eras:
    era_verdicts = [v for v in verdicts if v.date in era.date_range]
    
    era_summary = {
        "era_id": era.era_id,
        "date_range": era.date_range,
        "total_photos": len(era_verdicts),
        "verdict_distribution": {
            "H0_SAME": count(H0) / total,
            "H1_SYNTHETIC": count(H1) / total,
            "H2_DIFFERENT": count(H2) / total,
            "H_UNCERTAIN": count(UNCERTAIN) / total
        },
        "mean_confidence": mean(v.bayes.confidence),
        "median_log_bf_h1_vs_h0": median(v.bayes.log_bayes_factor_h1_vs_h0),
        "dominant_verdict": mode(verdicts),
        "verdict_stability": 1.0 - entropy(verdict_distribution) / max_entropy,
        "key_anomalies": [a for a in anomalies if a.date in era.date_range],
        "description_ru": era.description_ru  # из timeline
    }
```

#### Шаг A.3: Группировка по ракурсам

```
для каждого bucket из 9 ракурсов:
    bucket_verdicts = [v for v in verdicts if v.bucket == bucket]
    
    bucket_summary = {
        "bucket": bucket,
        "total_photos": len(bucket_verdicts),
        "verdict_distribution": {...},
        "coverage_gaps": find_gaps(bucket_verdicts, min_days=365),
        # Периоды > 1 года без фото в этом ракурсе
        "most_anomalous_era": argmax(eras, key=lambda e: e.h1_fraction)
    }
```

#### Шаг A.4: Статистический дайджест

```
overall_stats = {
    "total_photos": len(verdicts),
    "total_pairs": len(pair_hypotheses),
    "photos_by_verdict": count_by(verdicts, "bayes.verdict"),
    "photos_by_confidence_tier": {
        "high_confidence (≥0.8)": count(v.confidence ≥ 0.8),
        "medium_confidence (0.5-0.8)": count(0.5 ≤ v.confidence < 0.8),
        "low_confidence (0.3-0.5)": count(0.3 ≤ v.confidence < 0.5),
        "uncertain (<0.3)": count(v.confidence < 0.3)
    },
    "anomalies": {
        "total": len(anomalies),
        "by_severity": count_by(anomalies, "severity"),
        "by_type": count_by(anomalies, "type")
    },
    "aging_curve": {
        "metrics_tracked": timeline.aging_curve.metrics_tracked,
        "natural_aging_rates": timeline.aging_curve.natural_aging_rate,
        "breakpoints_found": len(timeline.aging_curve.breakpoints)
    },
    "evidence_quality": {
        "geometry_admissible_fraction": mean(v.geometry_admissible for v in evidence),
        "skin_admissible_fraction": mean(v.skin_admissible for v in evidence),
        "photos_with_both_channels": count(v.geometry_admissible AND v.skin_admissible)
    }
}
```

### Часть B: Persona Builder

#### Шаг B.1: Кластеризация фото по вердикту и дате

```python
def build_personas(
    verdicts: list[VerdictResult],
    verdicts_by_bucket: dict[str, list[VerdictResult]],
    timeline: Timeline
) -> list[Persona]:
    """
    Выделяет «персоны» — устойчивые во времени кластеры фото,
    имеющие схожий forensic-профиль.
    
    Алгоритм:
    1. Сгруппировать все фото с H0_SAME (доминирующий вердикт) →
       это baseline «реальный субъект»
    2. Сгруппировать фото с H1_SYNTHETIC (высокая confidence ≥ 0.6) →
       кандидаты в synthetic-персоны
    3. Внутри H1-фото кластеризовать по:
       - Временной близости (gap ≤ 180 дней между соседними фото)
       - Похожести geometry-профиля (per-zone RMSE кластер)
       - Согласованности skin-вердикта
    4. Каждый temporal-geometry кластер → отдельная «персона»
    5. H2_DIFFERENT фото (если есть) → отдельные персоны-«чужаки»
    
    Персоны — это гипотезы: «в период T1–T2 на фото присутствует
    версия лица V_k, характеризующаяся такими-то метриками».
    """
    ...
```

#### Шаг B.2: «Отпечатки» персон (persona fingerprints)

```python
def build_persona_fingerprint(
    persona_photos: list[str],  # photo_id, принадлежащие персоне
    metrics: dict[str, dict],   # все метрики из metrics.csv
    reference: dict             # reference_geometry.json
) -> PersonaFingerprint:
    """
    Для каждой персоны вычислить «отпечаток» — набор ключевых метрик,
    по которым эта персона стабильно отличается от других.
    
    Отпечаток включает:
    - Медианные значения топ-20 геометрических метрик
    - Медианные значения топ-20 текстурных метрик
    - Inter-quartile range (стабильность персоны во времени)
    - Отличия от baseline-персоны (Cohen's d по каждой метрике)
    - Отличия от silicone-reference когорты
    """
    ...
```

#### Шаг B.3: Persona timeline

```
persona_timeline = []
текущая персона = None

для каждого фото в хронологическом порядке:
    если фото.verdict == H0_SAME:
        если текущая персона != "baseline":
            закрыть текущую персону
            текущая персона = "baseline"
            persona_timeline.append({"persona": "baseline", "start": фото.date})
    если фото.verdict == H1_SYNTHETIC AND фото.confidence ≥ 0.6:
        определить, какой H1-кластер (из B.1)
        если кластер отличается от текущей персоны:
            закрыть текущую персону
            текущая персона = новый кластер
            persona_timeline.append({"persona": кластер.id, "start": фото.date})
    если фото.verdict == H_UNCERTAIN:
        # не меняем персону, но помечаем пробел
        persona_timeline.append({"gap": True, "at": фото.date})

# Пост-обработка: объединить смежные сегменты одной персоны,
# разделённые короткими H_UNCERTAIN-промежутками (≤ 90 дней)
```

### Часть C: Publication Correlator

#### Шаг C.1: Загрузка внешних публикаций

```python
def load_external_publications(publications_path: str) -> list[Publication]:
    """
    Загружает _archive/misc/publications.json — известные публичные
    появления субъекта с документированными датами и источниками.
    
    Схема записи:
    {
        "date": "2011-09-24",
        "event": "Съезд Единой России",
        "source_url": "http://kremlin.ru/...",
        "photos_available": 3,
        "notes": "Первое появление с видимыми изменениями лица"
    }
    """
    ...
```

#### Шаг C.2: Сопоставление вердиктов с публикациями

```
для каждой publication в publications:
    найти фото из основного датасета с датой ±30 дней от publication.date
    для каждого найденного фото:
        записать verdict + confidence
        если verdict == H1_SYNTHETIC:
            пометить publication как "forensic_flag: synthetic"
        если verdict == H0_SAME:
            пометить publication как "forensic_flag: real"

# Агрегировать по событиям:
publication_correlations = [
    {
        "event": "Съезд Единой России",
        "date": "2011-09-24",
        "matched_photos": 3,
        "dominant_verdict": "H1_SYNTHETIC",
        "mean_confidence": 0.78,
        "is_key_transition_event": true,
        "notes": "Первое публичное появление с synthetic-вердиктом"
    }
]
```

### Часть D: Text Generator

#### Шаг D.1: Генерация executive summary

Шаблонный, но содержательный текст на русском (и английском):

```markdown
# NEWWAP / DEEPUTIN — Forensic Analysis Executive Summary

**Дата анализа:** 2026-07-07
**Версия пайплайна:** 5.0 (6-stage refactored)
**Объём данных:** {n_photos} фото, {n_pairs} попарных сравнений
**Период:** {date_min} – {date_max} ({total_years} лет)

## Ключевой вывод

{key_finding_ru}

## Краткая хронология

| Период | Доминирующий вердикт | H0 | H1 | H2 | Uncert | Confidence |
|--------|---------------------|----|----|----|--------|------------|
{era_rows}

## Топ-5 хронологических аномалий

{top_5_anomalies}

## Методологическая прозрачность

- Калибровочный датасет: {n_calib} фото (real + silicone control)
- Геометрических метрик: {n_geom_metrics}
- Текстурных метрик: {n_tex_metrics}
- Mesh-зон: {n_mesh_zones} (из них валидных: {n_valid_zones})
- Log Bayes Factor ≥ 2.5 (substantial): {n_substantial} фото
- Negative control: {negative_control_result}

## Ограничения

{limitations_ru}
```

#### Шаг D.2: Генерация тезисов для журналиста

```python
def generate_journalist_thesis(era_summaries, anomalies, personas) -> str:
    """
    Генерирует тезисы на русском, пригодные для цитирования.
    
    Принципы:
    - Каждый тезис — одно утверждение, проверяемое по данным.
    - К каждому тезису — ссылка на конкретный evidence (photo_id, дата).
    - Избегать вероятностного жаргона; вместо «posterior H1=0.78» →
      «на 78% фото этого периода текстура кожи классифицируется как
      синтетическая, что в 11 раз превышает baseline-частоту ложных
      срабатываний на калибровочном датасете».
    - Указывать confidence/неопределённость открыто: «для N фото
      качество недостаточно для уверенного вывода».
    """
    ...
```

#### Шаг D.3: Генерация FAQ

```
Предвосхищаемые вопросы и возражения → ответы:

Q: «Может ли система путать старое плёночное фото низкого качества с силиконом?»
A: [Описание quality-compensation механизма + статистика: для эпохи legacy
   доля H1_SYNTHETIC составляет X%, при этом Y% из них — высоко-confidence.
   Для сравнения: на calibration-датасете автора той же эпохи — Z% false positive.]

Q: «Может ли пластическая операция объяснить наблюдаемые отклонения?»
A: [Сравнение с known-case ринопластики/блефаропластики: пластика меняет
   локальные зоны, но не даёт systemic сдвига по всем зонам + не меняет
   текстуру кожи на синтетическую. В нашем случае: ...]

Q: «Насколько stable ваши priors?»
A: [Sensitivity analysis: изменение priors на ±0.1 меняет вердикт для ≤ X% фото]

Q: «Почему вы считаете, что это силиконовая маска, а не цифровая ретушь?»
A: [Аргументы: geometry почти неизменна (ICP RMSE в пределах шума) +
   текстура систематически synthetic — цифровая ретушь не объясняет
   комбинацию «та же геометрия + другая кожа» на протяжении 10+ лет]
```

### Часть E: Export Layer

#### Шаг E.1: `all_verdicts.csv` — плоская таблица

```
photo_id, date, bucket, epoch,
bayes_verdict, p_h0, p_h1, p_h2, confidence,
log_bf_h1_vs_h0, log_bf_h2_vs_h0,
skin_classification, skin_prob_silicone, skin_confidence,
geometry_self_consistency_z,
chronological_consistency, visual_age_estimate, chrono_age, age_delta,
era_id, persona_id,
top_5_anomalous_metrics, rule_traces_summary
```

#### Шаг E.2: `anomalies.csv`

```
anomaly_id, type, severity, photo_a, photo_b, delta_days,
metric, value_a, value_b, delta, expected_delta, z_score,
description_ru
```

#### Шаг E.3: `methodology.json` — для external review

```json
{
  "pipeline_version": "5.0",
  "stages": [
    {"stage": 1, "name": "PREP", "description_ru": "...", "key_algorithms": ["3DDFA_v3", "rigid_umeyama", "z-buffer occlusion"]},
    {"stage": 2, "name": "METRICS", "description_ru": "...", "n_metrics_geometry": 276, "n_metrics_texture": 20},
    {"stage": 3, "name": "CALIBRATION", "description_ru": "...", "calibration_photos": 224, "silicone_photos": 41},
    {"stage": 4, "name": "PAIR & VERDICT", "description_ru": "...", "icp_method": "KD-tree ICP (scipy)", "skin_model": "Degradation-Aware Shift Verdict"},
    {"stage": 5, "name": "BAYES & CHRONO", "description_ru": "...", "bayesian_method": "Naive Bayes with evidence gates", "chrono_method": "Robust LOESS + PELT breakpoints"},
    {"stage": 6, "name": "REPORT", "description_ru": "Агрегация и экспорт (данный этап)"}
  ],
  "negative_controls": {
    "inter_subject_pairs": "...",
    "silicone_control_auc": "..."
  },
  "limitations": [
    "placeholder_zones: 10 из 24 mesh-зон имеют < 50 вершин и исключены",
    "silicone_cohort_size: 41 фото — малая выборка для текстурной калибровки",
    "cross_bucket_comparison: сравнения только внутри ракурса"
  ],
  "reproducibility": {
    "deterministic_algorithms": true,
    "random_seeds_used": false,
    "reference_files_sha256": ["...", "..."]
  }
}
```

#### Шаг E.4: BibTeX citations

```bibtex
@misc{newwap2026,
  title = {{NEWWAP}: Forensic Facial Analysis Pipeline for Identity Verification},
  author = {{Khudyakov, Victor}},
  year = {2026},
  note = {Version 5.0. \url{https://github.com/hudyakovictor/NEWWAP}}
}
```

---

## 5. Контракты данных

### 5.1 `final_report.json` — схема верхнего уровня

```json
{
  "meta": {
    "report_version": "1.0",
    "pipeline_version": "5.0",
    "generated_at": "2026-07-07T12:00:00Z",
    "data_period": {"from": "1999-08-09", "to": "2025-06-15"}
  },
  "executive_summary": {
    "key_finding_ru": "строка",
    "key_finding_en": "string"
  },
  "overall_statistics": {},
  "era_summaries": [],
  "personas": [],
  "anomalies_top": [],
  "publication_correlations": [],
  "methodology": {},
  "limitations": [],
  "faq": [],
  "journalist_thesis_ru": "строка",
  "journalist_thesis_en": "string"
}
```

### 5.2 `personas.json` — схема

```json
{
  "personas": [
    {
      "persona_id": "baseline",
      "label_ru": "Оригинал (1999–2011)",
      "date_range": {"from": "1999-08-09", "to": "2011-09-23"},
      "photo_count": 850,
      "dominant_verdict": "H0_SAME",
      "description_ru": "Предположительно реальный субъект. Высокая согласованность геометрии и текстуры на протяжении 12 лет. Естественное старение согласно кривой.",
      "fingerprint": {
        "geometry": {
          "zone_morphology_jaw_median": {"median": 10.2, "iqr": 0.8},
          "orbit_ellipse_bowl_ratio": {"median": 0.72, "iqr": 0.03}
        },
        "texture": {
          "glcm_dissimilarity_d5_a0": {"median": 1.83, "iqr": 0.20}
        }
      }
    },
    {
      "persona_id": "synthetic_v1",
      "label_ru": "Версия A (2011–2014)",
      "date_range": {"from": "2011-09-24", "to": "2014-12-31"},
      "photo_count": 320,
      "dominant_verdict": "mixed",
      "description_ru": "Переходный период. Геометрия близка к baseline (ICP RMSE 0.48 мм), но текстура кожи — synthetic в 65% фото.",
      "fingerprint": {},
      "diff_from_baseline": {
        "geometry": {"zone_morphology_jaw_median": {"cohens_d": 0.85, "direction": "decrease"}},
        "texture": {"glcm_dissimilarity_d5_a0": {"cohens_d": 2.10, "direction": "decrease"}}
      }
    },
    {
      "persona_id": "synthetic_v2",
      "label_ru": "Версия B (2015–2025)",
      "date_range": {"from": "2015-01-01", "to": "2025-06-15"},
      "photo_count": 605,
      "dominant_verdict": "H1_SYNTHETIC",
      "description_ru": "Систематически synthetic-текстура. Геометрия сохраняет близость к baseline.",
      "fingerprint": {},
      "diff_from_baseline": {}
    }
  ]
}
```

---

## 6. Обработка ошибок и граничные случаи

| Ситуация | Действие |
|----------|----------|
| Отсутствует `timeline_analysis.json` (Этап 5 не завершён) | Эры не строятся; отчёт генерируется без era-разбивки, с пометкой `"eras": "unavailable"` |
| 0 внешних публикаций (`publications.json` отсутствует) | Publication correlations — пустой массив; не ошибка |
| Менее 3 фото в эре | Эра помечается как `underpopulated`, исключается из persona-анализа |
| Persona имеет < 10 фото | Помечается `low_confidence_persona`; fingerprint считается, но с оговоркой |
| Фото с датой вне основного диапазона | Исключается из хронологических расчётов; в CSV помечается `date_outlier` |
| Текст тезиса превышает разумный лимит (5000 символов) | Урезается до топ-N наиболее значимых утверждений |
| Экспорт CSV: метрика содержит NaN | Записывается как пустая строка (совместимо с pandas `read_csv`) |

---

## 7. Порядок переноса кода (из REFACTOR_PLAN.md)

### 🟢 Перенести как есть

| Модуль | Комментарий |
|--------|-------------|
| `core/publication_correlation.py` | Сопоставление с внешними публикациями — самостоятельный модуль, не завязан на баги остального пайплайна |
| `core/recommendations.py` | Текстовые рекомендации — чистый модуль, перенести |
| `core/uncertainty.py` | Оценка неопределённости — маленький, чистый |
| `core/pipeline_runner.py`, `run_full_pipeline.py` | Инфраструктура resume, per-step логи, `pipeline_morning_summary.md`, gate-проверки между шагами. Отличная инженерная инфраструктура для overnight-прогонов |
| `core/constants.py`, `core/config.py`, `core/policy.py` | Конфигурационные модули |
| `metrics/csv_writer.py`, `csv_reader.py` | Простая механика сериализации CSV |
| `forensic/regression.py` | Сравнение прогонов, alerts — использовать как regression-guard в CI новой версии |

### 🟡 Перенести с рефакторингом

| Модуль | Комментарий |
|--------|-------------|
| `core/investigation_enrich.py`, `investigation_eras.py`, `persona.py`, `persona_fingerprint.py` | Слой «персон»/эпох для нарратива расследования. Концептуально ценен, но зависит от корректности Этапа 5. Переносить **после** стабилизации байеса |
| `core/jobs.py` (`JobManager`) | Асинхронные job'ы — идея правильная, синхронизировать с новыми границами этапов (job = один этап пайплайна) |
| `core/pipeline_diagnostics.py` (1269 строк) | Полезная идея (expected vs actual diagnostics), но 1269 строк избыточно. Сократить через общий шаблон «expect vs actual» |

### 🔴 Переписать заново

| Модуль | Комментарий |
|--------|-------------|
| `core/summary_schema.py` (`build_flat_metrics`, `build_verdict_block` — 1168 строк) | **Самый большой узел скрытой связанности.** Одновременно формирует geometry/skin/verdict/mask_anomaly блоки, содержит legacy-fallback и внешнюю сериализацию в CSV. Спроектировать заново как чистый сериализатор поверх уже готовых Pydantic-моделей из Этапов 1–5 |
| `core/service.py` (2240 строк — API-facade, таймлайн, калибровка, джобы) | Разделить на: `api/` (только HTTP-контракты) + перенос оставшейся логики в соответствующие этапы |
| `main.py` (1985 строк FastAPI) | Переписать по стандартной FastAPI-структуре: routers по доменам (photos/jobs/timeline/calibration), логику джобов вынести, main.py — только точка входа |

### Новое (не существует в текущем коде)

- `report/aggregator.py` — группировка по эрам, ракурсам, статистический дайджест
- `report/persona_builder.py` — кластеризация фото → персоны + отпечатки
- `report/persona_timeline.py` — хронология персон
- `report/text_generator.py` — генерация executive summary, тезисов, FAQ на русском
- `report/publication_correlator.py` — сопоставление вердиктов с внешними публикациями
- `report/export.py` — CSV/JSON/Markdown/BibTeX экспорт
- `report/methodology.py` — генерация methodology.json для external review
- `api/routers/photos.py`, `api/routers/jobs.py`, `api/routers/timeline.py`, `api/routers/calibration.py` — разделённые FastAPI-роутеры
- `api/main.py` — точка входа (чистый, < 100 строк)

---

## 8. Критерии приёмки (Definition of Done)

### Отчёт

1. **`final_report.md`** — human-readable, на русском, не более 50 страниц текста
   (без таблиц); содержит все ключевые разделы: executive summary, хронология,
   эры, персоны, топ-аномалии, методология, ограничения.
2. **`final_report.json`** — machine-readable, полный дамп всех агрегированных данных;
   проходит валидацию по JSON Schema.
3. **`executive_summary.md`** — ≤ 2 страницы, самодостаточный (читатель понимает
   суть без чтения основного отчёта).

### Персоны

4. Выделено 2–5 персон; каждая имеет ≥ 10 фото.
5. Fingerprint каждой персоны содержит ≥ 15 ключевых метрик с медианами и IQR.
6. Отличия персон от baseline посчитаны через Cohen's d; для synthetic-персон
   ≥ 5 метрик имеют |d| > 1.0.

### Публикационный слой

7. `journalist_thesis_ru.md` — список из 10–20 тезисов, каждый с ссылкой на
   конкретный evidence.
8. `faq.md` — ≥ 5 предвосхищённых вопросов с аргументированными ответами.

### Экспорт

9. `all_verdicts.csv` содержит строку для каждого фото из основного датасета;
   все колонки документированы в header-комментарии.
10. `methodology.json` содержит описание всех 6 этапов пайплайна + negative controls +
    ограничения — достаточно для external review без чтения кода.

### Интеграция

11. **Нет вычислительной логики**: Stage 6 не импортирует numpy/scipy напрямую
    (кроме как для форматирования чисел); все вычисления — в Этапах 1–5.
12. **API**: FastAPI поднимается, эндпоинты `/api/report/summary`,
    `/api/report/era/{era_id}`, `/api/report/photo/{photo_id}`,
    `/api/export/verdicts.csv` отдают корректные данные за < 500 мс.
13. **Reproducibility**: повторный запуск генерации отчёта на тех же данных
    даёт побайтово идентичные `final_report.json` и `all_verdicts.csv`.

---

## 9. Тест-план

### 9.1 Юнит-тесты

- `group_verdicts_by_era` — синтетический набор вердиктов, 3 эры, проверка
  корректности distribution и dominant_verdict.
- `build_personas` — синтетический набор: 100 H0 подряд, потом 50 H1 подряд.
  Должно выделить 2 персоны с корректными date_range.
- `generate_executive_summary` — проверить, что шаблон заполняется без
  незаполненных плейсхолдеров (регрессионный тест).
- `generate_journalist_thesis` — каждый тезис содержит ≥ 1 ссылку на photo_id
  или дату.
- `export_verdicts_csv` — сравнение с эталонным CSV (проверка всех колонок).
- `methodology_json` — проходит валидацию по JSON Schema.

### 9.2 Интеграционные тесты

- Полный прогон генерации отчёта на calibration-датасете (224 фото) —
  все файлы генерируются без ошибок.
- API-эндпоинты: `/api/report/summary` возвращает корректный JSON с overall_stats;
  `/api/export/verdicts.csv` возвращает CSV с правильным Content-Type.
- Проверка: `personas.json` содержит baseline-персону автора (из calibration).

### 9.3 Регрессионные тесты

- Сравнение отчёта v5 с отчётом v4 (текущий `core/service.py`) на 100 случайных
  фото: документировать расхождения.
- Проверка отсутствия вычислительной логики: `grep -r "import numpy\|import scipy\|from sklearn" report/` → пусто.

---

## 10. Что явно НЕ входит в Этап 6

- Любые вычисления метрик, evidence, вердиктов — **Этапы 1–5**.
- Байесовский синтез, хронологический анализ — **Этап 5**.
- Исправление багов в данных — все данные должны быть корректны **до** Этапа 6.
- Построение визуализаций (графики aging curve, timeline) — опционально,
  может быть отдельным скриптом; Этап 6 лишь указывает пути к готовым графикам.
- Интерактивный UI (React) — внешний проект.
- Хостинг, деплой, CI/CD — инфраструктура.

---

## 11. Зависимости от других этапов

```
Этап 1 (PREP)
    ↓ info.json (date, age, bucket, quality)
Этап 2 (METRICS)
    ↓ metrics.csv (для persona fingerprints)
Этап 3 (CALIBRATION)
    ↓ reference_geometry/texture.json (для methodology)
Этап 4 (PAIR & VERDICT)
    ↓ pairwise_evidence.jsonl + skin_verdicts.jsonl
Этап 5 (BAYES & CHRONO)
    ↓ forensic_verdicts.jsonl + pair_hypotheses.jsonl
      + timeline_analysis.json + anomalies.jsonl
Этап 6 (REPORT)              ← мы здесь
    ↓ final_report.md/json, personas, exports, publication_bundle
```

---

## 12. Приложение: целевая структура backend/ после рефакторинга

```
backend/
├── main.py                     # точка входа FastAPI (< 100 строк)
├── api/
│   ├── __init__.py
│   ├── router.py               # общий роутер
│   ├── photos.py               # /api/photos/*
│   ├── jobs.py                 # /api/jobs/*
│   ├── timeline.py             # /api/timeline/*
│   ├── calibration.py          # /api/calibration/*
│   └── report.py               # /api/report/*, /api/export/*
│
├── stage1_prep/                # Этап 1: поза → reconstruction → alignment → info.json
│   ├── pose/
│   ├── reconstruction/
│   ├── alignment/
│   ├── visibility/
│   ├── quality_gate/
│   └── info_builder.py
│
├── stage2_metrics/             # Этап 2: извлечение geometry + texture метрик
│   ├── registry/
│   ├── geometry/
│   ├── texture/
│   └── runner.py
│
├── stage3_calibration/         # Этап 3: модель шума
│   ├── geometry_builder.py
│   ├── texture_builder.py
│   ├── shift_model.py
│   └── validator.py
│
├── stage4_evidence/            # Этап 4: попарное сравнение + вердикт кожи
│   ├── icp.py
│   ├── pairwise_builder.py
│   ├── skin_verdict.py
│   └── validator.py
│
├── stage5_bayes_chrono/        # Этап 5: байес + хронология
│   ├── bayes/
│   │   ├── likelihoods.py
│   │   ├── posterior.py
│   │   └── decision.py
│   ├── rules/
│   │   ├── engine.py
│   │   └── definitions.py
│   ├── chrono/
│   │   ├── timeline.py
│   │   ├── aging_curve.py
│   │   ├── anomaly_detector.py
│   │   └── era_segmenter.py
│   └── fusion.py
│
├── stage6_report/              # Этап 6: агрегация + экспорт
│   ├── aggregator.py
│   ├── persona_builder.py
│   ├── text_generator.py
│   ├── publication_correlator.py
│   └── export.py
│
├── shared/                     # Общие модули (перенесены из core/pipeline/metrics)
│   ├── config.py
│   ├── constants.py
│   ├── contracts.py
│   ├── types.py
│   ├── utils.py
│   ├── storage_paths.py
│   └── mesh_units.py
│
├── forensic/                   # Инструменты валидации (🟢, без изменений)
│   ├── negative_control.py
│   ├── prior_sensitivity.py
│   ├── bootstrap_ci.py
│   ├── ablation.py
│   ├── regression.py
│   └── chrono_cluster.py
│
├── config/                     # Конфигурационные файлы
│   ├── pose_settings.json
│   ├── calibration_config.json
│   ├── bayes_config.json
│   ├── forensic_mode_config.json
│   └── pipeline_config.json
│
└── tests/
    ├── stage1/
    ├── stage2/
    ├── stage3/
    ├── stage4/
    ├── stage5/
    └── stage6/
```

---

*Версия: 1.0. Основано на REFACTOR_PLAN.md, текущем backend/core/service.py, backend/core/summary_schema.py.*

---

## Дополнение: Правки из аудита аналитиков (applicable к Этапу 6)

### ⚙️ П3-31: Конфигурируемый Весовой Контроллер
**Что**: Жёсткая привязка весов геометрии, текстуры и хронологии в коде.
**Как**:
1. Создать `config/weights_config.json`:
```json
{
  "channel_weights": {
    "geometry_bone_structure": 0.7,
    "texture_skin_analysis": 0.3,
    "chronology_anomalies": 0.5
  },
  "hypothesis_thresholds": {
    "H1_strong": 100.0,
    "H1_moderate": 10.0,
    "H2_critical": 500.0
  },
  "overrides": {
    "ignore_texture_if_dcs_low": true,
    "force_H2_if_anchor_mismatch": true
  }
}
```
2. Функция `apply_weights(verdict, config)` читает веса из файла в рантайме
3. Финальный синтез: `final_score = w_geom * LR_geom + w_tex * LR_tex + w_chrono * LR_chrono`
4. Пороги меняются без правки кода — достаточно обновить JSON

### ⚙️ П3-32: Настраиваемые пороги для всех методов
**Что**: Хардкод порогов снижает гибкость.
**Как**: Вынести все пороги в `config/pipeline_settings.yaml`:
```yaml
dcs:
  min_overall: 0.3
  min_resolution: 35  # px между зрачками
sigma_multiplier: 3.0  # для "сильного доказательства" (> 3σ)
lr_strong: 100.0
lr_moderate: 10.0
bio_limits:
  intercanthal_max_delta: 0.8  # мм
  zygomatic_max_delta: 1.2    # мм
  eye_angle_max_velocity: 1.5  # градусы за 6 мес
chrono:
  impossible_threshold: 0.85
  aging_velocity_max: 2.0  # года/год
```

### 🟡 П2-13 (часть): Evidence Log — Stage 6 output (финальный)
На выходе Этапа 6 сохранять `final_verdict.json`:
```json
{
  "photo_id": "...",
  "pair_ids": ["pair_1", "pair_2"],
  "weighted_verdict": {"H0": 0.15, "H1": 0.72, "H2": 0.13},
  "weights_applied": {"geometry": 0.7, "texture": 0.3, "chrono": 0.5},
  "evidence_chain": ["evidence_stage1.json", "evidence_stage2.json", "..."],
  "impossible_transformations": 3,
  "chronological_anomalies": 5,
  "final_verdict": "H1_SYNTHETIC",
  "confidence": "HIGH",
  "verdict_summary_ru": "Юридически доказано использование силиконовой маски (LR=342, 3 невозможных трансформации костной структуры, 5 хронологических аномалий)"
}
```
