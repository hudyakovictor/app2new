# forensic_mode_config_spec.md — Конфигурация режима ФОРЕЗИС

## Назначение

`forensic_mode_config.json` — конфигурация для режима "ФОРЕЗИС" (forensic mode),
активируемого в Stage 4/5. Это режим повышенной строгости, используемый когда:
- Есть явное подозрение на силикон (H1_SYNTHETIC evidence)
- Результат pair-анализа требует верификации
- Клиент запросил " deep scan" (медленнее, но точнее)

---

## Режимы работы

### STANDARD (по умолчанию)

```
Pipeline:
  texture: LBP + GLCM + gradient (fast)
  shift_model: single-scale
  pair_comparison: optional
  НЕ использует: Gabor, multi-scale frequency ratios
  Time: ~2s per image
```

### FORENSIC (this spec)

```
Pipeline:
  texture: LBP + GLCM + gradient + residual + patch_stats + contour
  shift_model: full multi-scale with quality compensation
  pair_comparison: mandatory (select best 3 pairs)
  Использует: ALL metric families
  Time: ~45s per image (без Gabor)
```

### EXPRESS (быстрый скрининг)

```
Pipeline:
  texture: только top-5 AUC metrics
  shift_model: none (raw z-score)
  pair_comparison: none
  Time: ~0.3s per image
```

---

## Структура forensic_mode_config.json

```json
{
  "mode": "FORENSIC",

  "enabled_metric_families": {
    "glcm": {
      "enabled": true,
      "angles": [0, 45, 90, 135],
      "distances": [1, 3, 5],
      "properties": ["dissimilarity", "homogeneity", "contrast", "energy"],
      "fast_mode": false
    },
    "lbp": {
      "enabled": true,
      "radius": [1, 3, 5],
      "n_points": [8, 16, 24],
      "method": "uniform"
    },
    "gradient": {
      "enabled": true,
      "kernels": ["sobel", "scharr", "prewitt"],
      "directions": 4
    },
    "residual": {
      "enabled": true,
      "scales": [1.5, 3.0, 6.0],
      "stats": ["std", "skewness", "kurtosis"]
    },
    "patch_stats": {
      "enabled": true,
      "n_patches": 64,
      "patch_size": 32,
      "metrics": ["mean", "std", "entropy"]
    },
    "contour": {
      "enabled": true,
      "approximation_epsilon": 0.02,
      "fourier_descriptors": 12
    },
    "hessian": {
      "enabled": true,
      "sigmas": [2.0, 4.0],
      "metrics": ["eigenvalue_ratio", "trace", "determinant"]
    },
    "color": {
      "enabled": true,
      "spaces": ["LAB", "YCrCb"],
      "aggregations": ["mean", "std", "skewness"]
    }
  },

  "gabor_excluded": true,

  "quality_compensation": {
    "mode": "full",           // "full" | "basic" | "none"
    "hf_metrics_discount": true,
    "robust_metrics_boost": true,
    "frequency_ratios": true,
    "quality_anomaly_detection": true,

    "thresholds": {
      "hf_discount": 0.6,
      "hf_zero": 0.4,
      "anomaly_sigma": 2.0,
      "min_quality_for_verdict": 0.35
    },

    "weights": {
      "q_overall": 0.40,
      "q_noise": 0.35,
      "q_blur": 0.25
    }
  },

  "pair_comparison": {
    "enabled": true,
    "max_pairs": 3,
    "selection_method": "top_score",  // "top_score" | "diversity" | "bucket_spread"
    "pair_score_threshold": 0.70,
    "fallback_to_single": true
  },

  "shift_scoring": {
    "method": "cohen_d_weighted",  // "cohen_d_weighted" | "auc_weighted" | "uniform"
    "include_frequency_ratios": true,
    "ratio_weight": 0.30,
    "sigmoid_temperature": 1.0
  },

  "verdict_thresholds": {
    "H1_prob_cutoff": 0.75,
    "H0_prob_cutoff": 0.75,
    "H_uncertain_max_confidence": 0.60,
    "confidence_lower_bound": 0.30
  },

  "output": {
    "include_raw_metrics": true,
    "include_shift_details": true,
    "include_pair_details": true,
    "include_reference_comparison": true,
    "verbose": true
  }
}
```

---

## Расширения относительно STANDARD

| Функция | STANDARD | FORENSIC |
|---|---|---|
| GLCM distances | [1, 3, 5] | [1, 3, 5, 7] |
| LBP radius | [3] | [1, 3, 5] |
| Patch stats | mean only | mean + std + entropy |
| Hessian scales | [4.0] | [2.0, 4.0, 6.0] |
| Frequency ratios | none | all pairwise |
| Pair comparison | optional | mandatory |
| Shift model | basic | full (with anomaly detection) |
| Output verbosity | minimal | full |

---

## Процесс активации

FORENSIC mode активируется когда:
1. `FORENSIC_PATCH` flag = true в запросе
2. Или: `photo_texture_evidence` возвращает H1 с prob > 0.5 (автоматический escalation)
3. Или: пользователь запросил `--deep-scan` в CLI

При активации:
- Переключаем quality_compensation mode → "full"
- Включаем все metric families (кроме Gabor)
- Запускаем pair_comparison (max 3 пары)
- Финальный verdict = median(pair verdicts) если pair_comparison доступен

---

## Валидация выхода FORENSIC mode

```python
def validate_forensic_output(output: dict) -> list[str]:
    errors = []

    required_keys = ["verdict", "confidence", "prob_silicone", "pair_comparison"]
    for k in required_keys:
        if k not in output:
            errors.append(f"Missing required key: {k}")

    if output.get("verdict") not in ["real", "silicone", "uncertain", "H0_SAME", "H1_SYNTHETIC"]:
        errors.append(f"Invalid verdict: {output['verdict']}")

    if output.get("confidence", 1.0) < 0.0 or output.get("confidence", 0.0) > 1.0:
        errors.append(f"Confidence out of range: {output['confidence']}")

    if output.get("pair_comparison"):
        if not isinstance(output["pair_comparison"], list):
            errors.append("pair_comparison must be a list")
        if len(output["pair_comparison"]) == 0 and output.get("verdict") == "silicone":
            errors.append("verdict=silicone but no pair comparison data")

    return errors
```