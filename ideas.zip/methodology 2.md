# Методология построения Stage 3 Texture Assets

## Философия

Stage 3 — калибровочный этап. Его задача: **построить референс** (cohort statistics,
noise model, shift coefficients) из размеченных данных (real skin + silicone mask),
чтобы Stage 4/5 мог выносить вердикт для новых фото без переобучения.

Ключевое отличие от supervised classification:
- Референс строится один раз на калибровочных данных
- Stage 4/5 работает в **open-set** режиме (новые фото, могут быть unseen conditions)
- shift_score — это отклонение от когортного референса, не классовая метка

---

## Метрики: отбор и иерархия

### Иерархия метрик по информативности (из clean_feature_leaderboard.csv)

**Tier 1: AUC ≥ 0.95** (практически идеальная сепарация)
```
glcm_dissimilarity_d5_a0     AUC=0.962, d=2.60
glcm_homogeneity_d5_a0      AUC=0.953, d=2.53
glcm_dissimilarity_d3_a0     AUC=0.952, d=2.45
glcm_dissimilarity_d5_a45    AUC=0.949, d=2.37
```

**Tier 2: AUC 0.90–0.95** (хорошая сепарация)
```
lbp_uniform_r5_std           AUC=0.941, d=2.19
grad_sobel_mag_skewness      AUC=0.936, d=2.28
glcm_dissimilarity_d5_a90   AUC=0.931, d=2.20
lbp_uniform_r3_entropy_mean AUC=0.930, d=2.01
```

**Tier 3: AUC 0.85–0.90** (умеренная сепарация)
```
patch_8_entropy_mean         AUC=0.888, d=1.65
contrast_michelson_mean      AUC=0.886, d=1.72
hessian_s4.0_ratio           AUC=0.882, d=1.58
```

**Tier 4: AUC < 0.85** (не используются для вердикта)

### Почему LBP/Patch/Contour уступают GLCM

GLCM (Gray-Level Co-occurrence Matrix) — статистика совместного распределения
яркостей на расстоянии d и направлении θ. Отражает **текстурную регулярность**:
- Real skin: микро-структуры (поры, морщины) создают high-frequency variation
- Silicone mask: однородная поверхность → low variation → low dissimilarity

LBP отражает локальные паттерны, но менее чувствителен к global texture regularity.
Patch stats слишком локальны, не улавливают макро-текстурные различия.

---

## Построение cohort statistics

```
Input: calibration photos (N_real + N_silicone)
       metrics per photo (592 metrics in unified_test)

For each cohort c in [real, silicone]:
    For each metric m in all_metrics:
        values_c[m] = [m value for photo in cohort c]

    cohort_stats[c]["mean"][m]   = mean(values_c[m])
    cohort_stats[c]["std"][m]    = std(values_c[m])
    cohort_stats[c]["median"][m]= median(values_c[m])
    cohort_stats[c]["p5"][m]     = percentile(values_c[m], 5)
    cohort_stats[c]["p95"][m]    = percentile(values_c[m], 95)
    cohort_stats[c]["n"][m]      = count(values_c[m])
```

**Правила:**
- n < 2 → метрика исключается (нельзя оценить variance)
- std < 1e-10 → метрика константная → исключается (не сепарирует классы)
- NaN values → excluded from computation, included in n as partial

---

## Shift model: Cohen's d как коэффициент

Идея: z-score отклонение от референса домножается на Cohen's d,
чтобы метрики с большей сепарацией вносили больший вклад.

```
raw_shift[m] = (value - cohort_mean) / cohort_std
weighted_shift[m] = raw_shift[m] * cohens_d[m]

shift_score = sum(weighted_shift) / sum(cohens_d)
```

Почему не AUC как вес? AUC — ранговая метрика (0.96 vs 0.95 разница минимальна),
Cohen's d — масштабируемая величина (2.60 vs 1.85 — реальная разница вSeparation).

---

## Quality compensation: Degradation-Aware Shift

### Problem: High-frequency metrics degrade under noise/blur

```
Clean photo:        GLCM_d5_dissimilarity = 1.83 (real)
Noisy photo (s5):   GLCM_d5_dissimilarity = 1.32 (looks like silicone!)
```

### Solution: Discount HF metrics based on effective_quality

```
effective_quality = w1*q_overall + w2*q_noise + w3*q_blur

if effective_quality >= 0.6:
    discount = 1.0
elif effective_quality >= 0.4:
    discount = (effective_quality - 0.4) / 0.2  # linear interpolation
else:
    discount = 0.0  # HF metrics unreliable, zero them
```

**Robust metrics** (color, contrast, hessian ratio) получают наоборот boost:
```
robust_shift[m] = raw_shift[m] * (1.0 + (1.0 - effective_quality) * 0.5)
```

### Why these thresholds?

- 0.6: Наблюдаемое начало деградации top-10 AUC (combo_s3 ≈ 0.94)
- 0.4: Порог полного коллапса (combo_s5 ≈ 0.922, близко к random)

---

## Frequency Ratios: Quality-Invariant Features

**Идея:** Отношения метрик разных масштабов инвариантны к качеству,
потому что шум одинаково влияет на numerator и denominator.

```
ratio_1 = residual_s3_std / glcm_d1_dissimilarity      # macro vs micro texture
ratio_2 = color_b_mean / entropy_w15_mean              # color vs entropy
ratio_3 = patch_32_std / patch_8_std                   # patch size invariance
```

**Валидация:** ratio_1 на combo_s5 сохраняет AUC ≥ 0.90 (проверено на stress_test)

---

## Noise model: epoch + bucket grouping

**Почему epoch:**
- Legacy photos (<2010): плёночные сканы, high grain, low resolution
- Recent photos (≥2010): digital, low noise, high resolution
- Если не учитывать epoch → смещение статистик

**Почему bucket:**
- Frontal photos: best quality (face centered, even lighting)
- Profile photos: motion blur, uneven lighting → worse quality
- Bucket-specific noise model корректирует ожидаемое качество

```
Expected_quality(epoch=e, bucket=b) = mean(quality_photos_in_(e,b))

Anomaly_score = (actual_q - Expected_quality) / std(quality_photos_in_(e,b))
```

Anomaly_score > 2 → фото аномально плохое для своего epoch+bucket → понижаем confidence.

---

## Pair comparison в FORENSIC mode

Когда FORENSIC mode активирован, Stage 4 делает попарное сравнение:

```
Для photo X:
    1. Найти top-3 calibration pairs с близким epoch+bucket
    2. Сравнить X с каждым членом пары:
       shift_score(X, reference_photo_i)
    3. Aggregate: median(shift_scores) → final verdict

Почему median, не mean:
    - median устойчив к outlier pairs (1 из 3 может быть нерепрезентативной)
```

---

## Validation pipeline

```
1. Build reference on calibration set (N=20 real + N=20 silicone)
2. Test on hold-out 20% of calibration (stratified split)
   Expected: accuracy >= 0.90

3. Test on stress_test_unified_metrics (320 images, 16 conditions)
   Expected:
     - clean accuracy >= 0.95
     - combo_s5 accuracy >= 0.85 (with quality compensation)
     - No H1_SYNTHETIC for real photos at q > 0.4

4. Cross-validation (LOO-CV on full calibration)
   Expected: AUC >= 0.98
```

---

## Known limitations

1. **Gabor filters excluded** — 21s per image слишком медленно. Возможно добавить
   опционально в FORENSIC mode если скорость не критична.

2. **Noise sigma stages не совпадают с реальным распределением** —
   sigma [0.005..0.080] выбраны произвольно, не из реальных данных.
   Реальное распределение шума可以从 reference_photos извлечь (но требует оценки).

3. **Cohen's d assumes normal distribution** — для сильно асимметричных метрик
   (напр. entropy) z-score может быть неточным. Можно заменить на
   Mann-Whitney U test statistic.

4. **Bucket coverage** — редкие bucket (left_profile, upturned) могут не иметь
   достаточно пар для статистики. Quality_anomaly detection может давать ложные
   срабатывания для редких bucket.