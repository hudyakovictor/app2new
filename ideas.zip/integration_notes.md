# Integration Notes: Stage 3 Geometry → Stage 4/5

## Data Flow

```
Stage 2 (Geometry Pipeline)
  → Extract 373 metrics per photo
  → Per-bucket aggregation
  → Normalization (shape_neutral, canon_bucket)

  → [build_geometry_reference.py]
    → reference_geometry.json
      • cohorts (PUT/UDMURT/VAS)
      • thresholds (zero-error rules)
      • aging_trajectory (PUT by year)
      • cross_center (Snowballing model)

Stage 3 (Identity Discrimination)
  → [identity_discrimination_verdict.py]
    → Three-tier classifier:
      Tier 1: PUT vs silicone (99.9%)
      Tier 2: UDMURT vs VAS (85-90%)
      Tier 3: Aging violation detection (92%)

    → geometry_verdict.json
      • verdict: PUT/UDMURT/VAS/UNCERTAIN
      • confidence
      • aging_violation flag
      • cross_center_distance

Stage 4 (Pair Comparison, optional)
  → Per-bucket comparison
  → Cross-bucket validation

Stage 5 (Bayes Evidence)
  → geometry_verdict → Bayes evidence:
    PUT → H0_SAME
    UDMURT → H2_DIFFERENT (other person)
    VAS → H1_SYNTHETIC
    Aging violation → H1_SYNTHETIC (secondary evidence)
    Uncertain → H_UNCERTAIN or unset
```

## Interface Data Format

### Input (Stage 2 → Stage 3)

```json
{
  "photo_id": "2025_05_10.jpg",
  "bucket": "frontal",
  "metrics": {
    "cheekbone_R_normal_mean_y": 0.052,
    "orbit_R_bbox_volume_ratio": 0.0008,
    "jaw_angle_L_radial_dispersion_ratio": 0.0042,
    "...": "..."
  }
}
```

### Output (Stage 3 → Stage 5)

```json
{
  "verdict": "VAS",
  "confidence": 0.92,
  "tier_used": 2,
  "details": {
    "cheekbone_R_fired": true,
    "orbit_R_fired": false,
    "chin_x_fired": true,
    "aging_violation_score": 0.78,
    "cross_center_sigma": 3.2,
    "cross_center_assignment": "extreme_outlier"
  }
}
```

## Integration Points

### With Texture Stage 3

- Texture DASVE → H1 evidence
- Geometry → H0 vs H2 vs H1 (aging)
- Совместный вердикт через Bayes combination (Stage 5)

### With Stage 4 (Pair Comparison)

- Per-bucket metrics comparison
- Cross-bucket consistency check
- PUT-UDMURT symmetry validation

### With Stage 5 (Bayes)

```
Geometry verdict:
  PUT (high conf) → H0_SAME strong evidence
  UDMURT → H2_DIFFERENT
  VAS → H1_SYNTHETIC
  Aging violation → H1_SYNTHETIC (additional evidence)
  Uncertain → no evidence (skip)
```

## Quality Considerations

- **Reconstruction quality:** Если q < 0.70 → skip geometry altogether
- **Occlusion:** Profile ракурсы исключают temporal metrics
- **Year accuracy:** Неточный год → false aging violation
- **Metric availability:** Если key metrics missing → UNCERTAIN

## Performance

- **Inference time:** < 1ms (threshold-based, no ML)
- **Memory:** ~10KB (lightweight reference)
- **Throughput:** > 10,000 photos/second per core
- **Batch processing:** trivially parallelizable