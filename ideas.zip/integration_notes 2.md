# Интеграционные заметки: Stage 3 Texture → Stage 4/5

## Входные контракты

### Stage 2 → Stage 3 (текстурная часть)
```
outputs/photo_{photo_id}/
  ├── info.json              # содержит: date.iso_date, bucket, quality (q_noise_level, q_blur_level, q_overall)
  ├── metrics_texture.csv    # плоский: metric_name, value
  └── skin_summary.json      # диагностика: mask_coverage, n_patches, effective_n_metrics
```

### Stage 3 → Stage 4 ( текстурная часть)
```
reference_texture.json       # cohorts + noise_model + shift_model
calibration_pairs.json       # пары для попарного сравнения
```

## Stage 3: Что делает для текстуры

```
1. build_texture_reference.py
   inputs:  calibration/photo_*/{info.json, face_mask.png, metrics_texture.csv}
   outputs: reference_texture.json

   a) Кластеризация по epoch: legacy (<2010) vs recent
   b) Для каждой когорты — статистики метрик: mean, std, median, p5, p95
   c) noise_model_by_epoch и noise_model_by_bucket
   d) shift_model coefficients (Cohen's d из leaderboard)
   e) Топ-20 метрик по AUC

2. select_calibration_pairs.py
   inputs:  calibration_metrics.csv + clean_feature_leaderboard.csv
   outputs: calibration_pairs.json

   Критерии отбора:
   - ≥5 метрик с AUC ≥ 0.85 в обоих фото
   - pair_quality = mean(q_overall) ≥ 0.70
   - Покрытие редких bucket/epoch
   - Diversity: ≤3 пар на одно фото
```

## Stage 4: Что делает для текстуры

```
quality_compensated_verdict.py
inputs:  metrics_texture.csv + quality (from info.json) + reference_texture.json
outputs: skin_verdict.json

{
  "verdict": "real|silicone|uncertain",
  "confidence": 0.0..1.0,
  "prob_silicone": 0.0..1.0,
  "prob_real": 0.0..1.0,
  "effective_quality": 0.0..1.0,
  "compensation_applied": bool,
  "hf_metrics_discounted": bool,
  "quality_anomaly": float,    # отклонение от ожидаемого для эпохи/bucket
  "shift_scores": {...},
  "frequency_ratios": {...},
  "used_metrics": [...],
  "n_used_metrics": int
}
```

## Stage 5: Bayes Evidence (пример для texture)

```python
def texture_evidence_to_bayes(skin_verdict: dict, reference: dict) -> dict:
    """
    Конвертировать текстурный вердикт Stage 4 в evidence для Stage 5 (Bayes).
    """
    prob = skin_verdict["prob_silicone"]
    confidence = skin_verdict["confidence"]

    # H1: silicone
    H1_score = prob * confidence
    # H0: real
    H0_score = (1 - prob) * confidence
    # H_UNCERTAIN
    H_uncertain = 1.0 - confidence

    return {
        "H1_texture": H1_score,
        "H0_texture": H0_score,
        "H_uncertain_texture": H_uncertain,
        "texture_anomaly_flag": skin_verdict.get("quality_anomaly", 0) > 2.0,
        "texture_compensation_applied": skin_verdict.get("compensation_applied", False),
        "hf_discounted": skin_verdict.get("hf_metrics_discounted", False),
    }
```

## Обработка edge cases

| Case | Handling |
|---|---|
| Фото недоступно в калибровочном датасете | Использовать global cohorts (real/silicone) |
| Метрика отсутствует в reference | Пропустить (не вносит вклад в shift_score) |
| Quality anomaly > 2σ | Flag → понизить confidence, но не отклонять |
| Empty metrics_texture.csv | status=insufficient_features → H_UNCERTAIN |
| Epoch unknown | Использовать "recent" как fallback |

## Валидация сквозного пути

После внедрения Stage 3→4→5 проверить:

```
1. На clean calibration фото: accuracy ≥ 0.95, prob_silicone ∈ [0, 0.1] для real
2. На stress test (combo_s5): accuracy ≥ 0.85
3. На hold-out set (20% calibration): accuracy не падает >5% vs train
4. Mean confidence коррелирует с реальным качеством (verify by eye)
```