# ТЗ — Этап 4 «PAIR & VERDICT»: попарное сравнение + вердикт по коже

Версия: 1.0. Продолжение `STAGE3_TZ.md`. Основано на анализе текущего `backend/` (NEWWAP),
`aboutplatform.txt`, `AGENTS.md`, `REFACTOR_PLAN.md`. Формат — самодостаточное инженерное ТЗ: цель,
границы, входы/выходы, пошаговый алгоритм, контракты данных, обработка ошибок,
критерии приёмки, тест-план, порядок переноса кода.

---

## 1. Цель этапа

Превратить готовые, откалиброванные метрики (Этапы 1–3) в два типа **форензик-значимых
свидетельств** (evidence), которые пойдут на вход байесовскому движку Этапа 5:

1. **Pairwise evidence** — для каждой пары фото `(photo_A, photo_B)`, принадлежащих
   одному ракурсу: численная оценка совпадения/различия геометрии лица (mesh evidence
   через ICP) и текстуры кожи, **с поправкой на калибровочный шум** из Этапа 3.
2. **Per-photo skin verdict** — для каждого отдельного фото: оценка вероятности,
   что кожа на фото — силиконовая маска (а не живая кожа), на основе текстурных
   признаков, сравнения с reference-когортами Этапа 3 и quality-compensated shift model.

Это первый этап, который **начинает принимать решения** (real/silicone/uncertain),
но — критически важно — **на уровне отдельного фото или пары**, не на уровне
«всей истории субъекта». Финальный синтез (H0_SAME / H1_SYNTHETIC / H2_DIFFERENT)
с учётом хронологии остаётся за Этапом 5.

---

## 2. Входы и выходы

### 2.1 Вход

```
# На каждое фото основного датасета (main):
storage/main/{photo_id}/
├── info.json                  # Этап 1: pose, bucket, date, quality, expression flags
├── reconstruction_v1.pkl      # Этап 1: канон-меш (vertices_canon)
├── face_mask.png              # Этап 1: RGBA-кроп кожи
└── metrics.csv                # Этап 2: сырые метрики geometry + texture

# Калибровочные модели (Этап 3):
storage/calibration/
├── reference_geometry.json    # модель шума геометрии
└── reference_texture.json     # модель шума текстуры + shift_model

# Список пар для сравнения:
pair_index.json                # какие photo_id с какими сравнивать
                               # (формируется на основе общего bucket + допустимый Δдаты)
```

**`pair_index.json`** — ключевой вход. Сравниваются **не все** 1700×1700 комбинаций,
а только пары, где:
- Оба фото в одном `pose_bucket` (нет смысла сравнивать frontal с profile);
- Дата фото А ≤ дата фото Б (хронологический порядок);
- Разница в датах ≥ 30 дней (два фото с одного мероприятия — неинформативная пара);
- Если `info.reconstruction.is_usable == False` для любого из пары → pair skipped для ICP,
  но skin verdict всё равно считается per-photo;
- Если `info.readiness.texture == "unavailable"` → skin verdict skipped для этого фото.

### 2.2 Выход

```
storage/results/
├── pairwise_evidence.jsonl    # по одной строке на каждую сравнённую пару
└── skin_verdicts.jsonl        # по одной строке на каждое фото с текстурным вердиктом
```

#### 2.2.1 `pairwise_evidence.jsonl` — схема строки

```json
{
  "pair_id": "main_2001_03_23__main_2003_10_05",
  "photo_a": {
    "photo_id": "main_2001_03_23",
    "date": "2001-03-23",
    "bucket": "frontal",
    "age_at_photo": 48.5
  },
  "photo_b": {
    "photo_id": "main_2003_10_05",
    "date": "2003-10-05",
    "bucket": "frontal",
    "age_at_photo": 51.0
  },
  "delta_days": 926,
  "geometry_evidence": {
    "status": "computed",
    "icp": {
      "shared_vertex_count": 2847,
      "rmse_mm": 0.42,
      "rmse_normalized": 0.087,
      "max_deviation_mm": 2.31,
      "convergence_iterations": 12,
      "inlier_ratio": 0.94
    },
    "mesh_zones": {
      "orbit_left": {
        "rmse_mm": 0.28,
        "rmse_vs_reference": 1.15,
        "zone_type": "bone",
        "verdict": "consistent"
      },
      "jaw_chin": {
        "rmse_mm": 0.91,
        "rmse_vs_reference": 3.40,
        "zone_type": "bone",
        "verdict": "anomalous",
        "anomaly_flags": ["exceeds_p95_by_2.1x"]
      }
    },
    "global_verdict": "minor_deviation",
    "global_rmse_vs_reference_z_score": 2.35
  },
  "texture_evidence": {
    "status": "both_available",
    "photo_a_skin_verdict_ref": "main_2001_03_23",
    "photo_b_skin_verdict_ref": "main_2003_10_05"
  },
  "calibration_applied": {
    "geometry_reference_version": "1.0",
    "texture_reference_version": "1.0",
    "epoch": "legacy",
    "bucket": "frontal",
    "noise_model_applied": true
  }
}
```

#### 2.2.2 `skin_verdicts.jsonl` — схема строки

```json
{
  "photo_id": "main_2001_03_23",
  "date": "2001-03-23",
  "bucket": "frontal",
  "epoch": "legacy",
  "verdict": {
    "skin_classification": "real",
    "prob_silicone": 0.12,
    "confidence": 0.72,
    "effective_quality": 0.68,
    "shift_score": -1.85,
    "verdict_basis": "quality_compensated_shift_model"
  },
  "top_signals": [
    {
      "metric": "glcm_dissimilarity_d5_a0",
      "value": 1.79,
      "reference_mean": 1.827,
      "reference_std": 0.198,
      "shift": -0.187,
      "weight_in_verdict": 0.15
    },
    {
      "metric": "color_b_mean",
      "value": 96.2,
      "reference_mean": 94.65,
      "reference_std": 10.14,
      "shift": 0.153,
      "weight_in_verdict": 0.12
    }
  ],
  "diagnostics": {
    "mask_integrity_ratio": 0.91,
    "skin_pixel_count": 28450,
    "hf_metrics_discounted": false,
    "quality_gate_passed": true
  }
}
```

---

## 3. Архитектура: два параллельных конвейера

```
                    ┌──────────────────────────┐
                    │      pair_index.json       │  список пар для сравнения
                    └──────────┬───────────────┘
                               │
               ┌───────────────┴────────────────┐
               │                                │
    ┌──────────▼──────────┐        ┌────────────▼────────────┐
    │  PAIRWISE COMPARE    │        │   SKIN VERDICT (per-photo)│
    │                      │        │                          │
    │  Для каждой пары:    │        │  Для каждого фото:       │
    │                      │        │                          │
    │  1. Загрузить        │        │  1. Загрузить face_mask  │
    │     reconstruction   │        │     + metrics.csv        │
    │     обоих фото       │        │     + info.json          │
    │                      │        │                          │
    │  2. Выровнять пару   │        │  2. Извлечь текстурные   │
    │     мешей (ICP)      │        │     признаки из метрик   │
    │                      │        │                          │
    │  3. Посчитать        │        │  3. Определить эпоху     │
    │     per-zone RMSE    │        │     фото (recent/legacy) │
    │                      │        │                          │
    │  4. Сравнить с       │        │  4. Выбрать reference-   │
    │     reference_       │        │     когорту по эпохе     │
    │     geometry.json    │        │                          │
    │                      │        │  5. Применить            │
    │  5. Выставить        │        │     quality-compensated  │
    │     per-zone verdict │        │     shift model          │
    │     (consistent/     │        │                          │
    │      anomalous)      │        │  6. Выставить вердикт:   │
    │                      │        │     real/silicone/       │
    │  6. Записать в       │        │     uncertain            │
    │     pairwise_        │        │                          │
    │     evidence.jsonl   │        │  7. Записать в           │
    │                      │        │     skin_verdicts.jsonl  │
    └──────────┬───────────┘        └────────────┬─────────────┘
               │                                │
               └───────────────┬────────────────┘
                               │
                    ┌──────────▼───────────┐
                    │   EvidenceValidator   │  кросс-проверка:
                    │                       │  - нет ли противоречий
                    │                       │    geometry vs texture
                    │                       │  - quality consistency check
                    │                       │  - дедупликация пар
                    └──────────────────────┘
```

**Критическое архитектурное решение** (из REFACTOR_PLAN.md): geometry pair compare
и skin verdict работают в одном этапе синхронно, потому что:
- Физически используют один набор входов (пара фото / reconstruction_v1.pkl / face_mask.png);
- Должны идти синхронно, чтобы в Этапе 5 можно было сопоставить geometry evidence и
  texture evidence на одном и том же фото/паре без рассинхрона версий данных;
- Это устраняет баг «H1_SYNTHETIC почти всегда 0 из-за рассинхрона канала текстуры
  и канала правил», обнаруженный в текущем коде.

---

## 4. Пошаговый алгоритм

### Часть A: Попарное сравнение геометрии (ICP + mesh zones)

#### Шаг A.1: Загрузка и подготовка пары

```
для каждой пары (photo_a, photo_b) из pair_index:
    загрузить reconstruction_v1.pkl для photo_a → mesh_a
    загрузить reconstruction_v1.pkl для photo_b → mesh_b
    загрузить info.json обоих фото → bucket, date, quality
    проверить: bucket_a == bucket_b (если нет → skip, записать в лог)
    проверить: is_usable == True для обоих (если нет → skip ICP, записать status=unavailable)
```

#### Шаг A.2: Выравнивание пары через ICP

Алгоритм ICP (Iterative Closest Point) — из `pipeline/icp.py` (🟢 перенос как есть):

```
1. Определить shared_vertex_indices — вершины, присутствующие в обоих мешах
   (одинаковые индексы в topology 3DDFA; обычно 3000-4000 вершин)

2. Начальное выравнивание: совместить центроиды shared-вершин
   translation = centroid(vertices_a[shared]) - centroid(vertices_b[shared])

3. ICP (KD-tree на vertices_b, scipy.spatial.cKDTree):
   - На каждой итерации: для каждой вершины A найти ближайшую вершину B
   - Вычислить optimal rotation (Kabsch algorithm / SVD)
   - Применить rotation + translation
   - Проверить сходимость: ΔRMSE < ε (1e-5 мм)
   - Max iterations = 50

4. После сходимости:
   - rmse_mm = RMSE по всем shared-вершинам после ICP
   - max_deviation_mm = максимальное расстояние среди shared-вершин
   - inlier_ratio = доля вершин с расстоянием < 2×median_distance
   - convergence_iterations = число итераций до сходимости
```

Сигнатура (из текущего кода, перенести):

```python
def icp_align_pair(
    vertices_a: np.ndarray,   # (N, 3)
    vertices_b: np.ndarray,   # (N, 3)
    shared_indices: np.ndarray,
    max_iterations: int = 50,
    tolerance: float = 1e-5
) -> ICPResult:
    """ICP alignment of two meshes with identical topology."""
```

#### Шаг A.3: Per-zone RMSE

После ICP-выравнивания всей пары, оценить качество совпадения **по каждой
анатомической зоне отдельно**:

```
для каждой zone в mesh_zones (из reference_geometry.json):
    zone_vertices = индексы вершин, принадлежащие этой зоне
    zone_shared = zone_vertices ∩ shared_vertex_indices
    если |zone_shared| < zone.min_vertices (50): skip зону
    zone_rmse_mm = RMSE(vertices_a[zone_shared], vertices_b[zone_shared])
```

#### Шаг A.4: Сравнение с reference (калибровочная поправка)

Это ключевой шаг — здесь применяется модель шума из Этапа 3:

```
для каждой zone:
    # Ожидаемая вариативность (шум) этой зоны в данном bucket/epoch:
    reference_std = reference_geometry.noise_model_by_bucket[bucket].zones[zone].std
    reference_mean = reference_geometry.noise_model_by_bucket[bucket].zones[zone].mean

    # Нормализованное отклонение:
    z_score = (zone_rmse_mm - reference_mean) / reference_std

    # Вердикт по зоне:
    если z_score < 1.0:   verdict = "consistent"
    если 1.0 ≤ z_score < 2.0: verdict = "minor_deviation"
    если 2.0 ≤ z_score < 3.0: verdict = "significant_deviation"
    если z_score ≥ 3.0:   verdict = "anomalous"

    # Вес зоны (костные > связочные > мягкотканные):
    zone_weight = reference_geometry.zone_weights[zone.zone_type]

    # Учитывать placeholder-зоны:
    если zone.is_placeholder: zone_weight = 0 (исключить из global)
```

#### Шаг A.5: Global pairwise verdict

```
# Взвешенный z-score по всем зонам:
global_z = Σ (z_score[zone] × zone_weight[zone]) / Σ zone_weight[zone]

# Global verdict:
если global_z < 1.0:   global_verdict = "consistent"
если 1.0 ≤ global_z < 2.0: global_verdict = "minor_deviation"
если 2.0 ≤ global_z < 3.0: global_verdict = "significant_deviation"
если global_z ≥ 3.0:   global_verdict = "anomalous"

# Дополнительный флаг:
prosthetic_modifier = False
если global_verdict ∈ {"minor_deviation", "consistent"}
   AND photo_a.skin_verdict == "silicone" XOR photo_b.skin_verdict == "silicone":
    prosthetic_modifier = True
    # Интерпретация: «геометрия почти совпадает, но текстура другая» —
    # ключевой сигнал для гипотезы «силиконовая маска на похожем черепе»
```

#### Шаг A.6: Запись в pairwise_evidence.jsonl

Одна строка JSON на пару (см. §2.2.1). Запись — append-only в JSONL-файл
с done-индексом (JSONL: каждая строка — отдельный JSON-объект, устойчиво
к падениям, поддерживает resume).

### Часть B: Per-photo skin verdict

#### Шаг B.1: Загрузка и валидация

```
для каждого photo_id из основного датасета (main):
    загрузить info.json → bucket, date, quality, readiness.texture
    если readiness.texture == "unavailable": skip, записать status=unavailable
    загрузить face_mask.png
    загрузить metrics.csv → только текстурные строки (metric_family ∈ texture_roi, spectral_zone)
```

#### Шаг B.2: Preprocessing маски

Повторить шаги из STAGE2_TZ.md §6.2 (текстурный блок Этапа 2 уже должен был это сделать,
но здесь перепроверка перед вердиктом):

```
1. Привести маску к рабочему разрешению
2. Отсечь exposure extremes (p2–p98 по luminance)
3. НЕ делать эрозию границ ([FORENSIC PATCH])
4. Отбросить мелкие несвязные фрагменты (< 5% от max компонента)
5. Проверить min_skin_pixel_count: если < 5000 → verdict = uncertain
6. Вычислить mask_integrity_ratio
7. Проверить mask_integrity_ratio: если < 0.85 → confidence понижается на 0.2
```

#### Шаг B.3: Определение эпохи и выбор reference-когорты

```
epoch = "legacy" if date.year < 2015 else "recent"
reference_cohort = reference_texture.cohorts[f"real_epoch_{epoch}"]
silicone_cohort  = reference_texture.cohorts["silicone_mask"]

# Для данного bucket:
bucket_ref = reference_cohort.by_bucket[bucket]
```

#### Шаг B.4: Вычисление shift относительно reference

```
для каждой метрики m из топ-20 дискриминативных (reference_texture.top_discriminative_metrics):
    если m отсутствует в метриках этого фото: skip
    value = metrics[m].value
    ref_mean = bucket_ref[m].mean
    ref_std  = bucket_ref[m].std
    shift[m] = (value - ref_mean) / ref_std
```

#### Шаг B.5: Quality-compensated shift model

Это ключевая инновация — применение Degradation-Aware Shift Model из Этапа 3:

```
# Из info.json:
q_noise  = quality.noise_index
q_blur   = quality.blur_index
q_overall = quality.overall_score

# Effective quality:
effective_quality = 0.40 × q_overall + 0.35 × (1 - q_noise) + 0.25 × (1 - q_blur)

# Классификация метрик на hf и robust:
hf_metrics     = reference_texture.shift_model.hf_metrics
robust_metrics = reference_texture.shift_model.robust_metrics

# Дисконтирование hf-метрик при низком качестве:
для каждой m в hf_metrics:
    если effective_quality < 0.6:
        shift[m] *= effective_quality / 0.6   # пропорциональное дисконтирование
    если effective_quality < 0.4:
        shift[m] = 0.0                        # полное исключение

# robust-метрики: без дисконтирования (оптические/цветовые признаки устойчивы к шуму)
```

#### Шаг B.6: Итоговый shift_score и вердикт

```
# Взвешенная сумма (веса метрик — из reference_texture):
shift_score = Σ shift[m] × weight[m]  для всех m

# Сигмоида:
prob_silicone = 1.0 / (1.0 + exp(-shift_score))

# Confidence:
confidence = effective_quality
если mask_integrity_ratio < 0.85: confidence -= 0.20
если confidence < 0: confidence = 0.05
если confidence > 1: confidence = 1.0

# Вердикт:
если prob_silicone > 0.65 AND confidence > 0.3:
    skin_classification = "silicone"
если prob_silicone < 0.35 AND confidence > 0.3:
    skin_classification = "real"
иначе:
    skin_classification = "uncertain"
```

#### Шаг B.7: Запись в skin_verdicts.jsonl

Одна строка JSON на фото (см. §2.2.2). Запись append-only в JSONL.

### Часть C: Кросс-валидация evidence

После вычисления всех pairwise evidence и skin verdicts:

```
1. Consistency check: для каждой пары где оба skin_verdict = "real",
   но geometry global_verdict = "anomalous" — пометить флагом
   `geometry_texture_contradiction`

2. Prosthetic detection: для каждой пары где geometry global_verdict ∈ {"consistent", "minor_deviation"}
   и один из skin_verdict = "silicone" — установить prosthetic_modifier = True
   (сигнал: «геометрия почти та же, но материал кожи другой» — ключевое для ТЗ)

3. Дедупликация: проверить, что каждая unordered пара {photo_a, photo_b}
   записана ровно один раз (JSONL done-индекс)
```

---

## 5. Контракты данных

### 5.1 Типы вердиктов

```python
class ZoneVerdict(str, Enum):
    CONSISTENT = "consistent"                    # z < 1.0
    MINOR_DEVIATION = "minor_deviation"           # 1.0 ≤ z < 2.0
    SIGNIFICANT_DEVIATION = "significant_deviation" # 2.0 ≤ z < 3.0
    ANOMALOUS = "anomalous"                      # z ≥ 3.0

class GlobalPairVerdict(str, Enum):
    CONSISTENT = "consistent"
    MINOR_DEVIATION = "minor_deviation"
    SIGNIFICANT_DEVIATION = "significant_deviation"
    ANOMALOUS = "anomalous"

class SkinClassification(str, Enum):
    REAL = "real"
    SILICONE = "silicone"
    UNCERTAIN = "uncertain"

class EvidenceStatus(str, Enum):
    COMPUTED = "computed"
    UNAVAILABLE = "unavailable"
    SKIPPED = "skipped"
```

### 5.2 `pair_index.json` — формат

```json
{
  "version": "1.0",
  "generated_at": "2026-07-07T12:00:00Z",
  "total_pairs": 45230,
  "pairs": [
    {
      "pair_id": "main_2001_03_23__main_2003_10_05",
      "photo_a": "main_2001_03_23",
      "photo_b": "main_2003_10_05",
      "bucket": "frontal",
      "delta_days": 926,
      "epoch_a": "legacy",
      "epoch_b": "legacy"
    }
  ],
  "coverage": {
    "buckets_with_pairs": 9,
    "total_photos_in_pairs": 1680,
    "orphan_photos": 95
  }
}
```

---

## 6. Обработка ошибок и граничные случаи

| Ситуация | Действие |
|----------|----------|
| ICP не сходится за 50 итераций | Записать с `convergence_iterations = 50`, `status = "did_not_converge"`, rmse на последней итерации |
| `shared_vertex_count` < 1000 (мало общих вершин) | ICP skip, `status = "insufficient_overlap"`, geometry_evidence не вычисляется |
| `inlier_ratio` < 0.5 (ICP застрял в локальном минимуме) | Пометить `icp_quality = "poor"`, per-zone verdicts считать, но с флагом `low_confidence_alignment` |
| Нет reference для данного bucket в данной эпохе | Использовать `real_pooled` как fallback, confidence понижается на 0.15 |
| Метрика отсутствует в reference (новая, не откалиброванная) | Исключить из shift_score, залогировать |
| `effective_quality` < 0.2 (очень плохое фото) | Skin verdict = `uncertain` независимо от prob_silicone |
| Фото без `face_mask.png` (hard-reject на Этапе 1) | `skin_verdict = {"status": "unavailable", "reason": "no_face_mask"}` |
| `mask_integrity_ratio` < 0.5 | Skin verdict принудительно `uncertain` (слишком фрагментированная маска) |
| В `pair_index` есть дубликат пары | Пропустить (done-индекс в JSONL защищает от дублей) |
| `prosthetic_modifier = True` для пары | Не менять verdict, но записать флаг; Это ключевой сигнал для Этапа 5 |

---

## 7. Порядок переноса кода (из REFACTOR_PLAN.md)

### 🟢 Перенести как есть

| Модуль | Комментарий |
|--------|-------------|
| `pipeline/icp.py` | Самостоятельный KD-tree ICP через scipy — алгоритмически корректен |
| `pipeline/compare.py` (`prepare_pair_alignment`, `shared_vertex_indices`, `ComparisonResult`) | 1159 строк, структурно опрятный, типизированный контракт `ComparisonResult`/`MeasurementResult`/`ResultStatus` |
| `core/contracts.py` (`MeasurementResult`, `ResultStatus`, `AdmissibilityDecision`) | Явные типизированные контракты результата — взять за основу для всех evidence-типов |
| `pipeline/blemish_tracking.py` | Самостоятельный модуль родинок по UV — опционально, не блокирует основной поток |
| `core/fuzzy_bayes/hypothesis_keys.py` | Канонические имена гипотез — нужны для маркировки evidence |
| `core/fuzzy_bayes/evidence_gates.py` | Гейты допустимости evidence — самостоятельный, перенести |

### 🟡 Перенести с рефакторингом

| Модуль | Комментарий |
|--------|-------------|
| `core/fuzzy_bayes/mesh_evidence.py` (`MeshEvidenceStore`, `build_mesh_evidence_cache`, JSONL done-index с resume) | 1080 строк, но инфраструктура resume/дедупликации по JSONL ценная. Бизнес-логику geom_ratio/SNR проверить построчно; 10 из 24 mesh_zones с 0% покрытия (placeholder) — чинить на уровне разметки зон, не здесь |
| `pipeline/verdict_v5_engine.py` (`compute_verdict_v5`, quality-gates, disable-limits) | Хорошая идея (физические диапазоны + пороги), но **два параллельных движка вердикта** (этот + fuzzy_bayes/rules.py). Решение: `verdict_v5_engine.py` становится per-photo skin детектором (Этап 4); его выход — один из входов в fuzzy_bayes evidence (Этап 5) |
| `core/fuzzy_bayes/pair_compare.py`, `reference_matching.py`, `reference_metric.py` | `prosthetic_modifier` детектор уже там — ключевой сигнал. Перенести, перепривязать к `reference_texture.json`/`reference_geometry.json` из Этапа 3 |
| `pipeline/texture.py`, `pipeline/texture_extended.py` | Разделить: «вычислить признаки текстуры» (ушло в Этап 2) и «вынести вердикт» (сейчас здесь). Строго убрать `from pipeline.verdict_v5_engine import compute_verdict_v5` из extract-функции — это архитектурная ошибка смешения слоёв |
| `pipeline/skin_authenticity/*` (blocks.py, calibration.py, fusion.py, patches.py, preprocess.py, scorer.py) | Хорошо декомпозированный пакет. Свести все `[FORENSIC PATCH]` в `forensic_mode_config.json` |
| `pipeline/scoring.py: extract_macro_bone_metrics` (1251 строка) | Декомпозировать по зонам (orbit/nose/jaw/zygomatic) при переносе |
| `pipeline/zones.py` (`EXCLUDED_ZONES`, `apply_expression_exclusion_mask`, `zone_bone_weight`, `compute_zone_metrics`) | Весовая модель зон — перенести |
| `pipeline/mesh_units.py` | Константы перевода mesh→мм |

### 🔴 Переписать заново / не переносить

| Модуль | Комментарий |
|--------|-------------|
| `core/analysis.py: extract_photo_bundle()` (2521 строки, моно-метод) | Не переносить как единое целое — логика распределяется по Этапам 1–6 |
| `core/summary_schema.py: build_flat_metrics`, `build_verdict_block` (1168 строк) | Перепроектировать как чистый сериализатор поверх Pydantic-моделей, а не как узел связанности |
| `core/fuzzy_bayes/rules.py` + `prob_logic.py` (параллельный вердикт-движок) | Оставить как input-фичи для Этапа 5, но не как независимый вердикт |

### Новое (не существует в текущем коде)

- `evidence/pairwise_builder.py` — оркестрация ICP + per-zone comparison
- `evidence/skin_verdict_builder.py` — quality-compensated shift model вердикт
- `evidence/validator.py` — кросс-проверка geometry vs texture, consistency check
- `evidence/pair_indexer.py` — построение `pair_index.json` из списка фото
- `evidence/contracts.py` — Pydantic-модели для всех evidence-типов

---

## 8. Критерии приёмки (Definition of Done)

1. **ICP convergence**: на тестовой выборке из 100 случайных пар одного ракурса ICP
   сходится за ≤ 30 итераций в ≥ 95% случаев; RMSE < 1.0 мм для ≥ 90% пар одного
   человека (калибровочный датасет автора).
2. **Zone coverage**: ≥ 14 из 24 mesh_zones имеют min_vertices ≥ 50 и дают
   осмысленный per-zone RMSE.
3. **Placeholder detection**: 10 placeholder-зон (с 2-3 вершинами) явно помечены
   в `pairwise_evidence.jsonl` как excluded с weight=0.
4. **Calibration reference applied**: каждая пара в `pairwise_evidence.jsonl` имеет
   заполненный блок `calibration_applied` с корректными reference-версиями, epoch и bucket.
5. **Skin verdict coverage**: ≥ 90% фото основного датасета с `readiness.texture != "unavailable"`
   получают skin verdict (real/silicone/uncertain).
6. **Quality compensation**: на синтетическом тесте: фото с высоким шумом (q_noise=0.7)
   и заведомо real-кожей **не** классифицируется как silicone (hf_metrics дисконтированы);
   то же фото с q_noise=0.7 и заведомо silicone-кожей — классифицируется как silicone
   (robust_metrics работают).
7. **Prosthetic modifier**: на calibration-парах (real vs silicone того же человека в том же
   ракурсе) prosthetic_modifier = True для ≥ 80% пар.
8. **Consistency**: нет противоречий «оба skin=real, geometry=anomalous» для калибровочных
   пар автора (где ground truth известен).
9. **Resume/idempotency**: повторный запуск с тем же `pair_index.json` не пересчитывает
   уже готовые пары (проверка по done-индексу в JSONL); время второго прогона — < 5%
   от первого.
10. **Performance**: полный pairwise compare для 45230 пар (оценка) завершается
    за ≤ 6 часов на CPU (M1 Max / эквивалент).

---

## 9. Тест-план

### 9.1 Юнит-тесты

- `icp_align_pair` — синтетический тест: два идентичных меша, один с известным
  поворотом на 5° + смещением на 2 мм. ICP должен восстановить трансформацию
  с точностью 0.01° и 0.01 мм.
- `compute_per_zone_rmse` — синтетический меш с 3 зонами, предсказуемые RMSE.
- `shift_model_discount` — параметризованный тест на effective_quality = [0.2, 0.4, 0.6, 0.8]:
  проверить корректное дисконтирование hf_metrics.
- `skin_classification_from_prob` — граничные значения prob_silicone (0.34, 0.35, 0.65, 0.66)
  и confidence (0.29, 0.30).
- `pair_indexer` — не генерирует дубликаты, не сравнивает фото из разных bucket,
  соблюдает минимальный Δдаты.

### 9.2 Интеграционные тесты

- Полный pairwise прогон на calibration-датасете (224 фото) — все пары одного
  bucket посчитаны, prosthetic_modifier корректен для known-silicone пар.
- Skin verdict на 10 заведомо real фото автора (эпоха recent, высокое качество) —
  все должны получить `real` с confidence > 0.6.
- Skin verdict на 10 заведомо silicone фото — все должны получить `silicone` или
  `uncertain`; ни одно не должно получить `real` с confidence > 0.5.
- Проверка: фото с `readiness.texture = "unavailable"` получает статус `unavailable`,
  а не падает с ошибкой.

### 9.3 Регрессионные / нагрузочные

- Полный прогон на 1700+ фото основного датасета — отсутствие падений, утечек памяти.
- Resume-тест: прервать после 1000 пар, перезапустить — первые 1000 не пересчитываются,
  оставшиеся досчитываются корректно.
- Проверка JSONL-формата: каждая строка — валидный JSON; общее число строк соответствует
  количеству обработанных пар/фото.

---

## 10. Что явно НЕ входит в Этап 4

- Байесовский синтез H0_SAME / H1_SYNTHETIC / H2_DIFFERENT — **Этап 5**.
- Хронологический анализ (кривая старения, «невозможные» скачки, PELT-breakpoints) — **Этап 5**.
- Построение reference-моделей — **Этап 3** (Этап 4 их только потребляет).
- Вычисление сырых метрик geometry/texture — **Этап 2**.
- Поза, 3D-реконструкция, выравнивание — **Этап 1**.
- Агрегация результатов в отчёт / персоны / эпохи — **Этап 6**.
- Исправление разметки mesh_zones (placeholder-зоны) — должно быть сделано **до**
  Этапа 4 на уровне `pipeline/zones.py`; Этап 4 лишь использует готовую разметку.

---

## 11. Зависимости от других этапов

```
Этап 1 (PREP)
    ↓ info.json, reconstruction_v1.pkl, face_mask.png
Этап 2 (METRICS)
    ↓ metrics.csv (geometry + texture)
Этап 3 (CALIBRATION)
    ↓ reference_geometry.json + reference_texture.json
Этап 4 (PAIR & VERDICT)      ← мы здесь
    ↓ pairwise_evidence.jsonl + skin_verdicts.jsonl
Этап 5 (BAYES & CHRONO)
    ↓ forensic verdict + timeline anomalies
Этап 6 (REPORT)
```

---

## 12. Приложение: выдержка из REFACTOR_PLAN.md — сквозные системные проблемы, релевантные Этапу 4

### 12.1 Два параллельных вердикт-движка кожи

**Проблема**: `verdict_v5_engine.py` и `fuzzy_bayes/rules.py+prob_logic.py` —
два независимых движка вердикта, не согласованных друг с другом.

**Решение в новой версии**: `verdict_v5_engine.py` (после рефакторинга) становится
**единственным** per-photo skin детектором на Этапе 4. Его выход — один из
**входов** в fuzzy_bayes evidence на Этапе 5. `rules.py+prob_logic.py` перестают
быть независимым вердиктом и становятся evidence-generator'ами для байесовского
синтеза.

### 12.2 [FORENSIC PATCH] комментарии

**Проблема**: в 6 файлах разбросаны намеренные отключения защит (quality_gate
пропускает «слишком гладкие» лица, preprocess не делает эрозию краёв маски).

**Решение**: все такие патчи вынесены в `forensic_mode_config.json` (см.
`stage3_texture_prep/INDEX.md` §8) с явным обоснованием каждого флага.
Этап 4 читает этот конфиг при инициализации.

### 12.3 Рассинхрон систем координат

**Проблема**: raw / canon_bucket / shape_neutral — путаница в metrics/.

**Решение**: Этап 4 работает **исключительно** с `canon_bucket`-пространством
(меши уже выровнены на Этапе 1). ICP и per-zone сравнение — в канон-пространстве.
Метрики из metrics.csv — только с `source_space = "canon_bucket"`.

---

*Версия: 1.0. Основано на REFACTOR_PLAN.md, STAGE1_TZ.md, STAGE2_TZ.md, STAGE3_TZ.md.*

---

## Дополнение: Правки из аудита аналитиков (applicable к Этапу 4)

### 🔴 П1-05: Единственный движок вердикта кожи
**Что**: Два независимых движка (`verdict_v5_engine.py` и `fuzzy_bayes/rules+prob_logic`) дают несогласованные результаты.
**Как**:
1. **Оставить только `verdict_v5_engine.py`** как единственный источник `SkinVerdict`
2. `fuzzy_bayes` **не считает** вердикт кожи сам — он **принимает** `SkinVerdict` на вход как evidence-поле
3. Убрать in-function import вердикта в `texture.py` (снимает смешение слоёв)
4. Добавить в `SkinVerdict` поле `v5_signal` для передачи в байесовский ввод

### 🟡 П2-14: Иерархический фильтр «Геометрия vs Текстура»
**Что**: Простое усреднение/перемножение доказательств приводит к размытым выводам.
**Как**: Внедрить логику «Доминирующего Свидетельства»:
```
Уровень 0: Если Геометрия (Жёсткие Якоря) → H2 (разные люди) → Вердикт H2 (текстура не смотрится)
Уровень 1: Если Геометрия → H0/H1 (один человек) → смотрим Текстуру
Уровень 2: Если Текстура → сильный сигнал силикона → Вердикт H1
            Если Текстура → естественная кожа → Вердикт H0
            Если оба канала конфликтуют → flag CONFLICT_DETECTION
```

### 🟡 П2-13 (часть): Evidence Log — Stage 4 output
На выходе Этапа 4 сохранять `evidence_stage4.json`:
```json
{
  "pair_id": "photoA_photoB",
  "geometry_snr": 3.2,
  "geometry_verdict": "H0",
  "texture_break": 0.45,
  "texture_silicone_prob": 0.78,
  "skin_verdict": "SYNTHETIC",
  "impossible_transformations": [],
  "hierarchical_filter_result": "H1_SUSPECTED"
}
```
