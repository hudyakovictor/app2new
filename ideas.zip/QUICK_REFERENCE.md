# QUICK_REFERENCE.md — Быстрый старт для AI

> **Читай ПЕРВЫМ при начале работы с проектом.**
> Для подробностей → ARCHITECTURE.md

---

## Что это за проект

NEWWAP — форензик-пайплайн: анализ фото для определения личности.
1700+ фото Путина (1998–2026) + двойники (UDMURT, VAS в масках).

## 6 стадий

```
s1_extraction  →  Извлекает face, quality (по face_mask!), pose, mesh
s2_metrics     →  Считает метрики (geometry + texture)
s3_identity    →  Предварительно: PUT/UDMURT/VAS? real/silicone?
s4_compare     →  Сравнивает пары + хронология + кластеры
s5_verdict     →  ФИНАЛЬНО: H0/H1/H2
s6_report      →  Отчёт
```

## Ключевое правило

**s3 ≠ s5:**
- s3 = гипотеза (одно фото, ограниченные данные)
- s5 = факт (все данные, все evidence)

## Структура папок

```
s{N}_{name}/
├── modules/       ← код
├── configs/       ← настройки (YAML)
├── tests/         ← unit-тесты
└── test_ui/       ← Streamlit (калибровка + верификация)
```

## Запуск

```bash
python main_runner.py                    # полный
python main_runner.py --from-stage 3     # со Stage 3
python main_runner.py --stage 3 --only   # только Stage 3
python main_runner.py --from-stage 3 -n 10  # 10 фото
```

## Калибровочные данные

- Текстура: 91 фото, top-20 метрик, AUC 0.9912
- Геометрия: PUT/UDMURT/VAS, 3 метрики → 99.99%

## Где что лежит

| Что | Где |
|-----|-----|
| Полная архитектура | `ARCHITECTURE.md` |
| Протокол сессии | `SESSION_2026-07-07.md` |
| Текстурные скрипты | `stage3_texture_prep/scripts/` |
| Геометрические скрипты | `stage3_geomety_info/scripts/` |
| Топ-20 метрик кожи | `unified_test/clean_feature_leaderboard.csv` |
| Топ-10 метрик геометрии | `stage3_geomety_info/geometry_leaderboard_top10.csv` |
| Приоритеты правок | `analytics/plan.txt` |
| Старые STAGE TZ | `STAGE1_TZ.md` – `STAGE6_TZ.md` |

---

*Если потерял контекст — читай ARCHITECTURE.md*
