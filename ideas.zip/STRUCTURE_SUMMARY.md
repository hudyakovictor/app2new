# Итоговая структура: 7-этапный пайплайн DEEPUTIN

## Архитектура

```
DEEPUTIN Pipeline v2.0
├── s1_extraction    → Извлечение данных (InsightFace)
├── s2_metrics       → Вычисление метрик (геометрия + текстура + качество)
├── s3_identity      → Идентификация (PUT/UDMURT/VAS) + классификация кожи
├── s4_compare       → Pairwise сравнение фото
├── s5_verdict       → Forensic вердикт (Байес + правила)
├── s6_report        → Отчёт (эры + персоны + документы)
└── s7_public        → Публикация (контент + монетизация)
```

## Структура файлов

```
deeputin/
├── __init__.py                          ← Пакет
├── run.py                               ← Точка входа (CLI)
│
├── shared/                              ← Общий модуль
│   ├── __init__.py
│   ├── logging.py                       ← PipelineLogger (эмодзи, цвет, прогресс)
│   └── schemas.py                       ← Pydantic-схемы + Enums
│
├── s1_extraction/
│   ├── __init__.py                      ← Stage1Engine
│   ├── extraction.py                    ← Stage1Engine (главный движок)
│   ├── config/
│   │   └── config.yaml                  ← Конфиг детекции лиц
│   ├── modules/
│   │   ├── face_extractor.py            ← FaceExtractor (InsightFace)
│   │   ├── quality_estimator.py         ← QualityEstimator
│   │   └── pose_estimator.py            ← PoseEstimator (9 buckets)
│   └── tests/
│       └── test_basic.py                ← Smoke-тесты
│
├── s2_metrics/
│   ├── __init__.py                      ← Stage2Engine
│   ├── metrics.py                       ← Stage2Engine (главный движок)
│   ├── config/
│   │   └── config.yaml                  ← Конфиг метрик
│   ├── modules/
│   │   ├── geometry/
│   │   │   ├── __init__.py
│   │   │   └── calculator.py            ← GeometryCalculator
│   │   ├── texture/
│   │   │   ├── __init__.py
│   │   │   └── calculator.py            ← TextureCalculator (20 метрик)
│   │   └── quality/
│   │       ├── __init__.py
│   │       └── calculator.py            ← QualityCalculator
│   └── tests/
│       └── test_basic.py                ← Smoke-тесты
│
├── s3_identity/
│   ├── __init__.py                      ← Stage3Engine
│   ├── identity.py                      ← Stage3Engine (главный движок)
│   ├── config/
│   │   └── config.yaml                  ← Пороги детекторов
│   ├── modules/
│   │   ├── __init__.py
│   │   ├── detect_person.py             ← PersonDetector (PUT/UDMURT/VAS)
│   │   └── classify_skin.py             ← SkinClassifier (real/silicone)
│   └── tests/
│       └── test_basic.py                ← Smoke-тесты
│
├── s4_compare/
│   ├── __init__.py                      ← Stage4Engine
│   ├── compare.py                       ← Stage4Engine (главный движок)
│   ├── config/
│   │   └── config.yaml                  ← Конфиг сравнения
│   ├── modules/
│   │   ├── __init__.py
│   │   ├── pairwise_geometry.py         ← GeometryComparator (Mahalanobis)
│   │   └── pairwise_skin.py             ← SkinComparator (texture shift)
│   └── tests/
│       └── test_basic.py                ← Smoke-тесты
│
├── s5_verdict/
│   ├── __init__.py                      ← Stage5Engine
│   ├── verdict.py                       ← Stage5Engine (главный движок)
│   ├── config/
│   │   └── config.yaml                  ← Priors, пороги
│   ├── modules/
│   │   ├── __init__.py
│   │   ├── bayes_engine.py              ← BayesEngine (постериоры)
│   │   ├── hypothesis_rules.py          ← HypothesisRules (H0/H1/H2/H_UNC)
│   │   └── confidence_scorer.py         ← ConfidenceScorer
│   └── tests/
│       └── test_basic.py                ← Smoke-тесты
│
├── s6_report/
│   ├── __init__.py                      ← Stage6Engine
│   ├── report.py                        ← Stage6Engine (главный движок)
│   ├── config/
│   │   └── config.yaml                  ← Конфиг эр и отчётов
│   ├── modules/
│   │   ├── __init__.py
│   │   ├── era_detector.py              ← EraDetector (5 эпох)
│   │   ├── persona_builder.py           ← PersonaBuilder
│   │   ├── document_generator.py        ← DocumentGenerator
│   │   └── export_manager.py            ← ExportManager (JSON/PDF/DOCX)
│   └── tests/
│       └── test_basic.py                ← Smoke-тесты
│
└── s7_public/
    ├── __init__.py                      ← Stage7Engine
    ├── publication.py                    ← Stage7Engine (главный движок)
    ├── config/
    │   └── config.yaml                  ← Конфиг публикации
    ├── modules/
    │   ├── __init__.py
    │   ├── content_factory.py           ← ContentFactory (Twitter/Instagram/LinkedIn)
    │   ├── crypto_monetization.py       ← CryptoMonetizer (IPFS/Token)
    │   ├── fomo_arch.py                 ← FOMOArchitect (countdown/tiers)
    │   └── nft_mint.py                  ← NFTMinter
    └── tests/
        └── test_basic.py                ← Smoke-тесты
```

## Запуск

```bash
# Все этапы
python run.py

# Конкретные этапы
python run.py --stages s1 s2 s3

# С конкретной папкой фото
python run.py --photos /path/to/photos

# С выходной папкой
python run.py --output /path/to/output
```

## Ключевые решения

| Решение | Описание |
|---------|----------|
| s3 ≠ s5 | s3 = гипотеза (одно фото), s5 = вердикт (все данные) |
| Качество = face_mask | Оценка на вырезанном лице, не на всём фото |
| Компенсаторная система | Нет single point of failure |
| 4 гипотезы | H0_SAME, H1_SYNTHETIC, H2_DIFFERENT, H_UNCERTAIN |
| Каждый этап | `engine.py` + `modules/` + `config/` + `tests/` |

## Тесты

Все smoke-тесты проходят:
- S1 ✅ (импорт, конфиг, инициализация)
- S2 ✅ (импорт, конфиг, инициализация)
- S3 ✅ (импорт, детекция PUT/UDMURT, классификация кожи)
- S4 ✅ (импорт, сравнение одинаковых/разных фото)
- S5 ✅ (импорт, вердикт SAME/SILICONE)
- S6 ✅ (импорт, генерация отчёта)
- S7 ✅ (импорт, публикация)

## Монетизация (s7)

| Уровень | Цена | Доступ |
|---------|------|--------|
| Free | $0 | Посты с задержкой 2 мес |
| Supporter | $50 | Без задержки + спойлеры |
| NFT Holder | $100+ | Уникальные NFT |
| Premium | $1,000 | Полные спойлеры |
| Ultra | $10,000 | Всё и сразу |
| **EXCLUSIVE** | **$26,102,023** | **Полные права на всё** |

---

*Создано: 2026-07-07*
*Обновлено: 2026-07-07*
