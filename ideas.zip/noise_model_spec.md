# noise_model_spec.md — Модель шума по эпохам и ракурсам

## Контекст

Stage 3 создаёт модель шума, которая предсказывает ожидаемое распределение
качества (noise_level, blur_level, overall) для фото заданной эпохи и bucket.
Эта модель используется для:
1. Нормализации текстурных метрик — вычитание ожидаемого шума
2. Определения "аномальности" качества конкретного фото (outlier detection)
3. Принятия решения "фото слишком плохое для анализа" (quality gate)

---

## Структура noise_model

```json
{
  "by_epoch": {
    "recent": {
      "q_noise_level": {"mean": 0.25, "std": 0.05, "p5": 0.15, "p95": 0.38},
      "q_blur_level":  {"mean": 0.42, "std": 0.12, "p5": 0.20, "p95": 0.65},
      "q_overall":     {"mean": 0.80, "std": 0.08, "p5": 0.65, "p95": 0.93}
    },
    "legacy": {
      "q_noise_level": {"mean": 0.55, "std": 0.15, "p5": 0.28, "p95": 0.82},
      "q_blur_level":  {"mean": 0.65, "std": 0.18, "p5": 0.35, "p95": 0.90},
      "q_overall":     {"mean": 0.60, "std": 0.14, "p5": 0.38, "p95": 0.78}
    }
  },

  "by_bucket": {
    "frontal": {
      "q_noise_level": {"mean": 0.30, "std": 0.08, "p5": 0.18, "p95": 0.45},
      "q_blur_level":  {"mean": 0.35, "std": 0.10, "p5": 0.18, "p95": 0.55}
    },
    "right_profile": {
      "q_noise_level": {"mean": 0.42, "std": 0.12, "p5": 0.22, "p95": 0.68},
      "q_blur_level":  {"mean": 0.58, "std": 0.15, "p5": 0.32, "p95": 0.82}
    }
  },

  "cross_epoch_bucket": {
    // Для эпоха+bucket комбинаций, где данных достаточно
  }
}
```

---

## Определение эпохи

Эпоха определяется по году фото (извлекается из `info.json` или имени файла):

| Год | Эпоха    | Характеристика |
|-----|----------|----------------|
| <1995 | `vintage` | Плёночная съёмка, низкое разрешение, высокий grain |
| 1995–2009 | `legacy` | Цифровая early-era, JPEG compression artifacts |
| 2010–2019 | `mid` | Стандартное цифровое фото |
| 2020+ | `recent` | Высокое разрешение, RAW, низкий шум |

При отсутствии года в данных — эпоха определяется по косвенным признакам
(размер файла, quality_index, compression level).

---

## Как строится

```
Input: calibration_photos (known epoch + bucket)

For each (epoch, bucket) group:
    measurements = [q_noise_level, q_blur_level, q_overall] per photo

    stats = compute_percentiles(measurements, [5, 50, 95])
    model[epoch][bucket] = {
        mean: stats["p50"],
        std: std(measurements),
        p5: stats["p5"],
        p95: stats["p95"]
    }
```

---

## Использование в вердикте

```python
def quality_anomaly_score(quality: dict, epoch: str, bucket: str, model: dict) -> float:
    """
    Насколько качество фото отличается от ожидаемого для его эпохи/bucket.
    > 0  — фото лучше ожидаемого
    < 0  — фото хуже ожидаемого (аномально низкое качество)
    """
    epoch_model = model["by_epoch"].get(epoch, {})
    bucket_model = model["by_bucket"].get(bucket, {})

    # Combined expected mean
    expected_noise = np.mean([
        epoch_model.get("q_noise_level", {}).get("mean", 0.3),
        bucket_model.get("q_noise_level", {}).get("mean", 0.3)
    ])
    expected_blur = np.mean([
        epoch_model.get("q_blur_level", {}).get("mean", 0.4),
        bucket_model.get("q_blur_level", {}).get("mean", 0.4)
    ])

    actual_noise = quality["q_noise_level"]
    actual_blur = quality["q_blur_level"]

    # Z-score deviation
    noise_dev = (actual_noise - expected_noise) / max(epoch_model.get("q_noise_level", {}).get("std", 0.1), 0.01)
    blur_dev = (actual_blur - expected_blur) / max(epoch_model.get("q_blur_level", {}).get("std", 0.1), 0.01)

    # Composite anomaly: положительное = фото аномально шумное/размытое для своей эпохи
    return (noise_dev + blur_dev) / 2.0

def quality_adaptive_threshold(base_threshold: float, anomaly: float) -> float:
    """При аномально плохом качестве — сдвигаем порог вердикта ближе к 0.5."""
    return base_threshold + anomaly * 0.1
```

---

## Outlier detection

Фото считается **quality outlier** если:
```
|quality_anomaly_score| > 2.0  (отклонение > 2 sigma от ожидаемого)
```

При outlier:
- Confidence вердикта снижается (но не обнуляется)
- Flag `quality_anomaly` = true в输出
- Такие фото не используются для построения noise_model (исключаются из обучающей выборки)