# NEWWAP Pipeline — Data Flow & Stage Integration

## Overview

Stage 3 (CALIBRATION) outputs feed directly into Stages 4, 5, 6, 7. This document shows exactly where each file flows.

---

## Pipeline Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│ Stage 1: DATA COLLECTION                                           │
│ Input: raw photo archives                                          │
│ Output: photo_*/{info.json, face_mask.png}                        │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Stage 2: METRICS EXTRACTION                                        │
│ Input: photos from Stage 1                                         │
│ Output:                                                            │
│   texture: metrics_texture.csv, skin_summary.json                  │
│   geometry: metrics_geometry.csv, mesh_summary.json                │
│   quality: info.json → quality.json (q_noise, q_blur, q_overall)  │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Stage 3: CALIBRATION ← ← ← THIS IS WHERE WE ARE                  │
│                                                                     │
│ Input: calibration photos (real + silicone) + metrics from Stage 2 │
│                                                                     │
│ OUTPUT FILES (ready):                                               │
│                                                                     │
│ ┌──────────────────────────────┐  ┌──────────────────────────────┐ │
│ │ TEXTURE                       │  │ GEOMETRY                      │ │
│ │ reference_texture.json        │  │ reference_geometry.json        │ │
│ │ calibration_pairs.json       │  │ calibration_pairs.json       │ │
│ │                               │  │                               │ │
│ │ • cohorts (real/silicone)     │  │ • cohorts (PUT/UDM/VAS)       │ │
│ │ • shift_coefficients (Cohen d)│  │ • thresholds (0.048, 0.001)  │ │
│ │ • noise_model (epoch+bucket)  │  │ • aging_trajectory (PUT)     │ │
│ │ • hf_metrics/robust_lists     │  │ • cross_center (PUT=center)  │ │
│ └──────────────────────────────┘  └──────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
                              │
            ┌─────────────────┼─────────────────┐
            ▼                                   ▼
┌──────────────────────────────┐  ┌──────────────────────────────┐
│ Stage 4: PAIR & VERDICT      │  │ Stage 4: GEOMETRY VERDICT    │
│                               │  │                               │
│ Input:                        │  │ Input:                        │
│   metrics_texture.csv         │  │   metrics_geometry.csv        │
│   quality.json                │  │   reference_geometry.json      │
│   reference_texture.json      │  │   cross_center_id_reference  │
│   calibration_pairs.json      │  │   calibration_pairs.json       │
│                               │  │                               │
│ Process:                      │  │ Process:                      │
│   quality_compensated_        │  │   identity_discrimination_   │
│   verdict.py                  │  │   verdict.py                  │
│   (DASVE engine)              │  │   (3-tier classifier)         │
│                               │  │                               │
│ Output:                       │  │ Output:                       │
│   skin_verdict.json           │  │   geometry_verdict.json        │
│   • verdict: real/silicone    │  │   • verdict: PUT/UDM/VAS      │
│   • confidence                │  │   • confidence                 │
│   • prob_silicone             │  │   • aging_violation (bool)    │
│   • shift_scores              │  │   • cross_center_distance     │
│   • effective_quality         │  │   • tier_used (1/2/3)          │
└──────────────────────────────┘  └──────────────────────────────┘
            │                                   │
            └─────────────────┬─────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Stage 5: BAYES EVIDENCE                                             │
│                                                                     │
│ Input:                                                              │
│   skin_verdict.json (from texture Stage 4)                          │
│   geometry_verdict.json (from geometry Stage 4)                     │
│   reference_texture.json (for confidence weighting)                 │
│   reference_geometry.json (for aging evidence)                      │
│                                                                     │
│ Process:                                                            │
│   prob_logic.py:                                                     │
│     • photo_texture_evidence → H1_SYNTHETIC (from skin_verdict)     │
│     • photo_geometry_evidence → H0/H1/H2 (from geometry_verdict)    │
│     • chronology_evidence → year-based scoring                      │
│     • cross_era_reference → multi-era comparison                    │
│                                                                     │
│ Output:                                                             │
│   verdict.json:                                                      │
│     • H0_SAME (real)                                                 │
│     • H1_SYNTHETIC (synthetic/silicone)                              │
│     • H2_DIFFERENT (other person)                                    │
│     • H_UNCERTAIN                                                    │
│     • confidence: 0.0-1.0                                            │
│     • evidence_log: {...}                                            │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Stage 6: CROSS-REFERENCE                                            │
│                                                                     │
│ Input:                                                              │
│   verdict.json (from Stage 5)                                       │
│   external databases (if available)                                 │
│                                                                     │
│ Process:                                                            │
│   • Check against known persons database                            │
│   • Cross-reference with historical photos                          │
│   • Verify aging trajectory consistency                             │
│                                                                     │
│ Output:                                                             │
│   final_verdict.json:                                               │
│     • verdict (confirmed)                                            │
│     • confidence (adjusted)                                          │
│     • cross_reference_results                                        │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│ Stage 7: FINAL REPORT                                               │
│                                                                     │
│ Input:                                                              │
│   final_verdict.json                                                │
│   All intermediate results                                          │
│                                                                     │
│ Output:                                                             │
│   report.pdf / report.json:                                         │
│     • Photo analysis summary                                        │
│     • Persona identification result                                 │
│     • Confidence metrics                                            │
│     • Evidence chain                                                 │
│     • Recommendations                                                │
└─────────────────────────────────────────────────────────────────────┘
```

---

## File Dependencies (what Stage 3 produces → what Stages 4-7 consume)

### Texture Files

| File | Created In | Used In | Purpose |
|------|-----------|---------|---------|
| `reference_texture.json` | Stage 3 | Stage 4, Stage 5 | Cohorts, shift coefficients, noise model |
| `calibration_pairs.json` | Stage 3 | Stage 4 | Optimal pairs for pairwise comparison |
| `quality_compensated_verdict.py` | Stage 3 scripts | Stage 4 | DASVE engine for quality-aware verdict |
| `configs/quality_compensation_engine.yaml` | Stage 3 configs | Stage 4 | Engine parameters (thresholds, weights) |
| `configs/shift_model_config.yaml` | Stage 3 configs | Stage 4 | Shift scoring configuration |

### Geometry Files

| File | Created In | Used In | Purpose |
|------|-----------|---------|---------|
| `reference_geometry.json` | Stage 3 | Stage 4, Stage 5 | Cohorts, thresholds, aging, cross-center |
| `calibration_pairs.json` | Stage 3 | Stage 4 | Optimal pairs for comparison |
| `identity_discrimination_verdict.py` | Stage 3 scripts | Stage 4 | 3-tier PUT/UDM/VAS classifier |
| `cross_center_id_reference.json` | Stage 3 | Stage 4, 5 | Snowballing center model |
| `configs/identity_discrimination_engine.yaml` | Stage 3 configs | Stage 4 | 3-tier classifier parameters |
| `configs/aging_model_config.yaml` | Stage 3 configs | Stage 4, 5 | PUT aging vs silicone violation |

---

## Stage 4 Details

### Texture Verdict (quality_compensated_verdict.py)

```
Input:
  metrics_texture.csv  ← Stage 2 output
  quality.json         ← Stage 2 output (from info.json)
  reference_texture.json ← Stage 3 output

Process:
  1. Compute z-score shifts for each metric
  2. Apply quality compensation:
     - effective_quality = 0.40*q_overall + 0.35*(1-q_noise) + 0.25*(1-q_blur)
     - HF metrics discounted at q < 0.6
     - HF metrics zeroed at q < 0.4
     - Robust metrics boosted by (1.0 - eq) * 0.5
  3. Compute frequency ratios (invariant to quality)
  4. Aggregate: shift_score = Σ(shift[m]×coef[m]) + Σ(ratios[r]×ratio_coef[r])
  5. Sigmoid: prob_silicone = sigmoid(shift_score)
  6. Classify: real/silicone/uncertain

Output: skin_verdict.json → Stage 5
```

### Geometry Verdict (identity_discrimination_verdict.py)

```
Input:
  metrics_geometry.csv  ← Stage 2 output
  reference_geometry.json ← Stage 3 output
  cross_center_id_reference.json ← Stage 3 output

Process:
  Tier 1: PUT vs silicone (threshold-based)
    - cheekbone_R_normal_mean_y > 0.048 → DOUBLE (99.9%)
    - orbit_R_bbox_volume_ratio < 0.001 → NOT_PUT (96%)
  Tier 2: UDM vs VAS (majority voting)
    - chin_normal_mean_x > 0.016 → VAS (75%)
    - jaw_R_normal_mean_z > 0.033 → UDMURT (84%)
  Tier 3: Aging violation (deviation from PUT trajectory)
    - z-score > 2.5 → synthetic_aging

Output: geometry_verdict.json → Stage 5
```

---

## Stage 5 Details

### Bayes Evidence Combination

```
Input:
  skin_verdict.json (texture) → H1_SYNTHETIC evidence
  geometry_verdict.json (geometry) → H0/H1/H2 evidence
  reference_texture.json → confidence weighting
  reference_geometry.json → aging evidence

Process (prob_logic.py):
  photo_texture_evidence(skin_verdict) → {
    "H1_SYNTHETIC": prob_silicone × confidence,
    "H0_SAME": prob_real × confidence,
    "H_UNCERTAIN": 1.0 - confidence
  }

  photo_geometry_evidence(geometry_verdict) → {
    "H0_SAME": if verdict == "PUT",
    "H2_DIFFERENT": if verdict == "UDMURT",
    "H1_SYNTHETIC": if verdict == "VAS",
    "H_UNCERTAIN": if verdict == "UNCERTAIN"
  }

  chronology_evidence(year) → {
    "H1_SYNTHETIC": increased if synthetic_aging detected
  }

  cross_era_reference(metrics, year) → {
    "H1_SYNTHETIC": if metrics inconsistent with year
  }

  Final: Bayes combination of all evidence → verdict.json
```

---

## Stage 6 Details

### Cross-Reference (optional, if external data available)

```
Input:
  verdict.json (from Stage 5)
  external_persons_database (if exists)

Process:
  1. Check persona against known database
  2. Cross-reference with historical photos
  3. Verify aging trajectory consistency
  4. Adjust confidence based on external evidence

Output: final_verdict.json
```

---

## Stage 7 Details

### Final Report Generation

```
Input:
  final_verdict.json
  All intermediate results (Stage 2-6)

Process:
  1. Summarize photo analysis
  2. Compile persona identification result
  3. List confidence metrics
  4. Show evidence chain
  5. Provide recommendations

Output: report.pdf / report.json
```

---

## Calibration Data Flow

```
Calibration Data (Stage 3)
  │
  ├── reference_texture.json ──────────┐
  ├── calibration_pairs.json ──────────┤
  ├── quality_compensated_verdict.py ──┤
  └── configs/ ────────────────────────┤
                                       │
                                       ▼
Stage 4: VERDICT ──────────────────────┤
  │ skin_verdict.json ─────────────────┤
  │ geometry_verdict.json ─────────────┤
  │                                    │
  └── Stage 5: BAYES ──────────────────┤
       │ verdict.json ─────────────────┘
       │
       └── Stage 6: CROSS-REFERENCE
            │
            └── Stage 7: REPORT
```

---

## Key Integration Points

| Stage | Input from Stage 3 | Output to Next Stage |
|-------|-------------------|---------------------|
| Stage 3 | calibration data | reference files |
| Stage 4 | reference + metrics | skin_verdict.json |
| Stage 5 | skin_verdict + geometry_verdict | verdict.json |
| Stage 6 | verdict.json | final_verdict.json |
| Stage 7 | final_verdict.json | report |

---

## Recalibration Instructions

If accuracy drops below threshold:

1. **Stage 3 recalibration:**
   - Update `reference_texture.json` with new calibration data
   - Update `reference_geometry.json` with new calibration data
   - Recalibrate thresholds in `configs/`

2. **Stage 4 recalibration:**
   - Adjust quality thresholds in `configs/quality_compensation_engine.yaml`
   - Adjust 3-tier thresholds in `configs/identity_discrimination_engine.yaml`

3. **Stage 5 recalibration:**
   - Update evidence weights in `configs/prob_logic_config.yaml`

See `docs/recalibration_manual.md` for detailed instructions.