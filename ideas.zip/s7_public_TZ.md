# s7_public — ТЗ: Publication Management System

> **Проект:** DEEPUTIN (deep + putin — игра слов)
> **Статус:** Планирование (реализация по мере готовности s6_report)
> **Цель:** Управление публикациями, монетизация, автоматическая генерация контента
> **MCP Agent:** Интеграция для авто-генерации текстов

---

## 0. Заголовок проекта

```
From Conspiracy Theories and Memes to an Investigation 
into the Greatest Hoax in History

A 27-YEAR FACIAL CONTINUITY ANALYSIS BASED ON 1,800+ IMAGES (1999–2026)

Can a large-scale forensic pipeline evaluate the long-standing 
"Putin doubles" hypothesis using chronology, craniofacial geometry, 
skin texture analysis and Bayesian evidence fusion?
```

---

## 1. Концепция

### Что это
**Не просто посты.** Это **система управления нарративом** — от черновика до монетизации.

### Философия
1. **Открытое расследование** — публикуем всё, не стесняясь
2. **Скептики = топливо** — чем больше споров, тем больше охват
3. **Монетизация через ценность** — люди платят не за информацию, а за ранний доступ
4. **Команда, не один человек** — нарратив "группы исследователей"

### Ценности
- **Прозрачность:** Всё можно проверить
- **Наука:** Метрики, статистика, доказательства
- **Драматургия:** Каждый пост — часть большого рассказа

---

## 2. Архитектура

```
s7_public/
├── content/
│   ├── drafts/              ← Черновики (авто-генерация)
│   ├── ready/               ← Готовые к публикации
│   ├── published/           ← Опубликованные
│   └── scheduled/           ← Запланированные
│
├── templates/
│   ├── post_templates.yaml  ← Шаблоны постов
│   ├── spoiler_templates.yaml ← Шаблоны спойлеров
│   ├── nft_templates.yaml   ← Шаблоны NFT
│   └── thread_templates.yaml ← Шаблоны тредов
│
├── monetization/
│   ├── tiers.yaml           ← Уровни доступа
│   ├── nft_collection.yaml  ← Коллекция NFT
│   └── pricing.yaml         ← Цены
│
├── schedule/
│   ├── calendar.yaml        ← Контент-план
│   ├── queue.yaml           ← Очередь публикаций
│   └── rules.yaml           ← Правила публикации
│
├── analytics/
│   ├── engagement.yaml      ← Вовлечённость
│   ├── revenue.yaml         ← Доходы
│   └── audience.yaml        ← Аудитория
│
├── modules/
│   ├── engine.py            ← Главный движок
│   ├── content_generator.py ← Генератор контента
│   ├── scheduler.py         ← Планировщик
│   ├── monetization.py      ← Монетизация
│   ├── mcp_agent.py         ← MCP Agent
│   └── analytics.py         ← Аналитика
│
├── testing/
│   ├── smoke/test_basic.py
│   └── app.py
│
└── configs/
    └── s7_config.yaml
```

---

## 3. Контент-план

### Структура серии (50 постов)

```
АКТ 1: ПРОЛОГ (Посты 1-5)
├── Пост 1: "Мы начали расследование"
│   Тип: intro
│   Цель: Зацепить аудиторию
│   Спойлер: Нет
│   
├── Пост 2: "Почему именно фото Путина?"
│   Тип: context
│   Цель: Объяснить мотивацию
│   Спойлер: Нет
│   
├── Пост 3: "Как работает наш метод"
│   Тип: methodology
│   Цель: Показать научный подход
│   Спойлер: Частичный (без деталей)
│   
├── Пост 4: "Первые результаты"
│   Тип: teaser
│   Цель: Показать, что есть что
│   Спойлер: Нет
│   
└── Пост 5: "Что нас ждёт дальше"
    Тип: roadmap
    Цель: Запланировать ожидания
    Спойлер: Нет

АКТ 2: РАССЛЕДОВАНИЕ (Посты 6-20)
├── Посты 6-10: Геометрия лица
│   Тип: deep_dive
│   Цель: Детали геометрического анализа
│   Спойлер: Частичный
│   
├── Посты 11-15: Текстура кожи
│   Тип: deep_dive
│   Цель: Детали текстурного анализа
│   Спойлер: Нет
│   
└── Посты 16-20: Хронология
    Тип: timeline
    Цель: Показать эволюцию
    Спойлер: Нет

АКТ 3: ОТКРОВЕНИЯ (Посты 21-40)
├── Посты 21-25: Аномалии
│   Тип: revelation
│   Цель: Показать находки
│   Спойлер: Да (с задержкой)
│   
├── Посты 26-30: Двойники
│   Тип: revelation
│   Цель: Раскрыть информацию о двойниках
│   Спойлер: Да (с задержкой)
│   
├── Посты 31-35: Силиконовые маски
│   Тип: bombshell
│   Цель: Главное откровение
│   Спойлер: Да (только для premium)
│   
└── Посты 36-40: Итоги
    Тип: summary
    Цель: Подвести итоги
    Спойлер: Нет

АКТ 4: ЭПИЛОГ (Посты 41-50)
├── Посты 41-45: Реакция сообщества
│   Тип: community
│   Цель: Показать обратную связь
│   
└── Посты 46-50: Будущее
    Тип: future
    Цель: Что дальше
```

---

## 4. Монетизация

### Уровни доступа

```yaml
tiers:
  free:
    name: "Бесплатный"
    price: 0
    access:
      - "Посты с задержкой 2 месяца"
      - "Базовые спойлеры"
      - "Комментарии"
    
  supporter:
    name: "Поддержка"
    price: 50  # USD
    access:
      - "Посты без задержки"
      - "Расширенные спойлеры"
      - "Приоритет в комментариях"
      - "Благодарности в постах"
    
  nft_holder:
    name: "Владелец NFT"
    price: 100  # USD (минимум)
    access:
      - "Всё из supporter"
      - "Уникальные NFT (часть улик)"
      - "Голосование за контент"
      - "Эксклюзивные данные"
    
  premium:
    name: "Premium"
    price: 1000  # USD
    access:
      - "Всё из nft_holder"
      - "Полные спойлеры ДО публикации"
      - "Личные консультации"
      - "Сырые данные"
    
  ultra:
    name: "Ultra"
    price: 10000  # USD
    access:
      - "Всё из premium"
      - "Ранний доступ ко ВСЕМУ"
      - "Участие в расследовании"
      - "Имя в титрах"
      
  exclusive:
    name: "EXCLUSIVE RIGHTS"
    price: 26102023  # USD — историческая цена
    description: "Полные права на всё расследование"
    access:
      - "Всё из ultra"
      - "Исключительные права на публикацию"
      - "Все данные в сыром виде"
      - "Права на документальный фильм"
      - "Права на книгу"
      - "Права на эксклюзивные интервью"
      - "Имя создателя/продюсера"
      - "Первые 24 часа — только вы"
    use_cases:
      - "СМИ想要 эксклюзив"
      - "Документальные фильмы"
      - "Книжные издательства"
      - "Продюсерские компании"
      - "Исследовательские институты"
    note: "Историческая ценность оправдывает цену. 
           Это не просто данные — это доказательство 
           величайшего обмана в истории."
```

### NFT Коллекция

```yaml
nft_collection:
  name: "DEEPUTIN Evidence"
  description: "Уникальные артефакты из расследования DEEPUTIN"
  project: "DEEPUTIN (deep + putin — игра слов)"
  
  categories:
    photo_artifact:
      name: "Фото-артефакт"
      description: "Уникальная обработка одного из 1900 фото"
      count: 100  # избранные фото
      price_range: [50, 500]
      
    metric_card:
      name: "Метрическая карточка"
      description: "Визуализация ключевых метрик"
      count: 50
      price_range: [25, 200]
      
    anomaly_badge:
      name: "Знак аномалии"
      description: "NFT для обнаруженных аномалий"
      count: 30
      price_range: [100, 1000]
      
    evidence_fragment:
      name: "Фрагмент улики"
      description: "Часть цепочки доказательств"
      count: 20
      price_range: [200, 2000]
```

### Спойлеры

```yaml
spoilers:
  levels:
    teaser:
      name: "Тизер"
      content: "Общая информация"
      release_delay: "0 дней"
      tier: "free"
      
    hint:
      name: "Намёк"
      content: "Частичные детали"
      release_delay: "30 дней"
      tier: "supporter"
      
    reveal:
      name: "Раскрытие"
      content: "Полные детали"
      release_delay: "60 дней"
      tier: "nft_holder"
      
    bombshell:
      name: "Бомба"
      content: "Главные откровения"
      release_delay: "90 дней"
      tier: "premium"
      
    full_spoiler:
      name: "Полный спойлер"
      content: "Всё и сразу"
      release_delay: "0 дней"
      tier: "ultra"
```

---

## 5. Генератор контента

### Шаблоны постов

```yaml
post_templates:
  intro:
    title: "Мы начали расследование"
    structure:
      - hook: "Что если всё, что вы знали — неправда?"
      - context: "Мы — команда исследователей..."
      - methodology: "Наш метод основан на..."
      - teaser: "Первые результаты шокируют..."
      - cta: "Подписывайтесь, чтобы не пропустить"
    hashtags: ["#расследование", "#анализ", "#нейросети"]
    
  deep_dive:
    title: "{metric_name}: Полный разбор"
    structure:
      - intro: "Сегодня разберём {metric_name}"
      - explanation: "Что это за метрика..."
      - visual: "[График/таблица]"
      - findings: "Наши результаты показывают..."
      - implications: "Что это значит..."
    hashtags: ["#метрики", "#анализ", "#данные"]
    
  revelation:
    title: "⚠️ ВНИМАНИЕ: {finding}"
    structure:
      - warning: "Это может шокировать"
      - finding: "Мы обнаружили..."
      - evidence: "Доказательства..."
      - implications: "Что это значит..."
      - spoiler: "Полные детали — для подписчиков"
    hashtags: ["#находка", "#расследование", "#сенсация"]
```

### MCP Agent

```yaml
mcp_agent:
  capabilities:
    - "Генерация текстов по шаблонам"
    - "Форматирование для разных платформ"
    - "Автоматическое хэштегирование"
    - "A/B тестирование заголовков"
    
  prompts:
    generate_post: |
      Сгенерируй пост по шаблону {template}.
      Данные: {data}
      Тон: {tone}
      Длина: {length}
      Платформа: {platform}
      
    generate_spoiler: |
      Сгенерируй спойлер уровня {level}.
      Контент: {content}
      Целевая аудитория: {audience}
      
    adapt_platform: |
      Адаптируй текст для {platform}.
      Оригинал: {text}
      Ограничения: {constraints}
```

---

## 6. Планировщик

### Правила публикации

```yaml
rules:
  frequency:
    posts_per_day: 1
    min_interval_hours: 8
    max_posts_per_week: 5
    
  timing:
    best_times:
      - "09:00"  # Утро
      - "13:00"  # Обед
      - "19:00"  # Вечер"
    timezone: "Europe/Moscow"
    
  content_mix:
    intro: 5%
    deep_dive: 30%
    revelation: 25%
    community: 20%
    other: 20%
    
  spoiler_release:
    teaser_delay: "0 дней"
    hint_delay: "30 дней"
    reveal_delay: "60 дней"
    bombshell_delay: "90 дней"
```

### Контент-план

```yaml
calendar:
  week_1:
    - day_1:
        post: "Пост 1: Вступление"
        tier: "free"
        spoiler: null
    - day_2:
        post: "Пост 2: Контекст"
        tier: "free"
        spoiler: null
    - day_3:
        post: "Пост 3: Методология"
        tier: "free"
        spoiler: "teaser"
    - day_4:
        post: "Пост 4: Первые результаты"
        tier: "free"
        spoiler: null
    - day_5:
        post: "Пост 5: Дорожная карта"
        tier: "free"
        spoiler: null
        
  week_2:
    - day_6:
        post: "Пост 6: Геометрия — Введение"
        tier: "free"
        spoiler: null
    # ... и так далее
```

---

## 7. Интерфейс

### Dashboard

```
┌─────────────────────────────────────────────────────────────┐
│  NEWWAP Publication Manager                                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │  45 постов   │  │  12 готово  │  │  3 запланир │        │
│  │  в плане     │  │  к публикации│  │  на сегодня │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Ближайшие публикации                               │   │
│  │                                                     │   │
│  │  19:00 — "Геометрия: Полный разбор" (free)         │   │
│  │  Завтра — "Аномалия #3" (supporter, спойлер)       │   │
│  │  3 дня — "Силиконовые маски" (premium)             │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Доходы                                             │   │
│  │                                                     │   │
│  │  Supporters: $2,500 (50 человек)                   │   │
│  │  NFT: $15,000 (30 продаж)                          │   │
│  │  Premium: $5,000 (5 человек)                       │   │
│  │  Ultra: $10,000 (1 человек)                        │   │
│  │  ─────────────────────                              │   │
│  │  ИТОГО: $32,500                                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Контент-менеджер

```
┌─────────────────────────────────────────────────────────────┐
│  Редактор постов                                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Шаблон: [deep_dive ▼]                                     │
│                                                             │
│  Заголовок:                                                │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  cheekbone_R: Полный разбор ключевой метрики        │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Текст:                                                    │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Сегодня разберём одну из ключевых метрик...        │   │
│  │                                                     │   │
│  │  [Место для данных из s6_report]                   │   │
│  │                                                     │   │
│  │  Наши результаты показывают:                        │   │
│  │  - PUT: 0.22 ± 0.03                               │   │
│  │  - UDMURT: 0.05 ± 0.02                            │   │
│  │  - VAS: 0.08 ± 0.02                               │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Спойлер: [hint ▼]                                         │
│  Доступ: [supporter ▼]                                     │
│  Платформа: [Telegram ▼]                                   │
│                                                             │
│  [Сгенерировать] [Предпросмотр] [Запланировать]           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. Интеграция

### Из s6_report

```python
# Авто-загрузка данных для постов
def load_report_data():
    report = load_json("s6_report/output/report.json")
    
    return {
        "statistics": report["statistics"],
        "timeline": report["timeline"],
        "anomalies": report["anomalies"],
        "evidence_chains": report["evidence_chains"]
    }
```

### В соцсети

```yaml
platforms:
  telegram:
    api: "Telegram Bot API"
    channel: "@newwap_investigation"
    features: ["posts", "threads", "polls"]
    
  twitter:
    api: "Twitter API v2"
    account: "@NEWWAP_Invest"
    features: ["tweets", "threads", "spaces"]
    
  youtube:
    api: "YouTube Data API v3"
    channel: "NEWWAP Investigation"
    features: ["videos", "shorts", "community"]
    
  github:
    api: "GitHub API"
    repo: "newwap/evidence"
    features: ["issues", "discussions", "wiki"]
```

---

## 9. Монетизация (детали)

### Доходы

```yaml
revenue_streams:
  subscriptions:
    name: "Подписки"
    platforms: ["Patreon", "Boosty", "Substack"]
    tiers: ["supporter", "premium", "ultra"]
    
  nft_sales:
    name: "Продажа NFT"
    platforms: ["OpenSea", "Rarible", "Blur"]
    categories: ["photo_artifact", "metric_card", "anomaly_badge"]
    
  donations:
    name: "Донаты"
    platforms: ["DonationAlerts", "StreamElements"]
    incentives: ["благодарности", "спойлеры", "голосование"]
    
  licensing:
    name: "Лицензирование"
    buyers: ["media", "researchers", "journalists"]
    price: "по запросу"
    
  exclusive_rights:
    name: "Исключительные права"
    price: 26102023  # USD
    buyers: ["СМИ", "продюсеры", "издательства"]
    access: "Полный доступ ко всему расследованию"
    note: "Историческая ценность"
```

### Антипиратство

```yaml
anti_piracy:
  watermarks:
    enabled: true
    type: "invisible"
    content: "user_id + timestamp"
    
  tracking:
    enabled: true
    method: "unique_links"
    
  takedowns:
    enabled: true
    auto: true
    platforms: ["all"]
    
  legal:
    enabled: true
    terms: "CC BY-NC-ND 4.0"
```

---

## 10. MCP Agent

### Промпты

```yaml
prompts:
  generate_post:
    system: |
      Ты — копирайтер для расследования DEEPUTIN.
      Пиши научно-популярным языком.
      Используй данные из s6_report.
      Добавляй интригу, но сохраняй точность.
      
    user: |
      Сгенерируй пост:
      Тип: {post_type}
      Тема: {topic}
      Данные: {data}
      Платформа: {platform}
      Тон: {tone}
      
  generate_spoiler:
    system: |
      Ты — создатель спойлеров.
      Пиши максимально интригующе.
      Не раскрывай всё сразу.
      
    user: |
      Сгенерируй спойлер:
      Уровень: {level}
      Контент: {content}
      Аудитория: {audience}
      
  respond_to_skeptic:
    system: |
      Ты — эксперт по расследованию.
      Отвечай скептикам вежливо, но твёрдо.
      Используй данные и факты.
      
    user: |
      Скептик написал: {comment}
      Ответь, используя: {evidence}
```

---

## 11. Файлы

### s7_config.yaml

```yaml
# s7_public/configs/s7_config.yaml

# === Проект ===
project:
  name: "DEEPUTIN"
  tagline: "From Conspiracy Theories and Memes to an Investigation into the Greatest Hoax in History"
  
# === Публикации ===
publishing:
  posts_per_day: 1
  timezone: "Europe/Moscow"
  auto_generate: true
  
# === Монетизация ===
monetization:
  enabled: true
  platforms:
    - "boosty"
    - "patreon"
  nft_enabled: true
  
# === MCP Agent ===
mcp_agent:
  enabled: true
  model: "gpt-4"
  temperature: 0.7
  
# === Платформы ===
platforms:
  telegram:
    enabled: true
    channel: "@newwap_investigation"
  twitter:
    enabled: true
    account: "@NEWWAP_Invest"
  youtube:
    enabled: false
    
# === Антипиратство ===
anti_piracy:
  watermarks: true
  tracking: true
```

---

*Последнее обновление: 2026-07-07*
*Статус: Планирование*
