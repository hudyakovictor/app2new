# reference_texture.json — Спецификация

## Назначение

`reference_texture.json` — эталонный файл Stage 3 (CALIBRATION) для текстурной части.
Построен из калибровочного датасета (real skin + silicone mask) и используется
для:
1. Computing shift scores (отклонение метрик от когортного reference)
2. Quality-aware verdict compensation в Stage 4/5
3. Вычисления noise_model_by_epoch и noise_model_by_bucket

**Этот файл — для текстуры. Для геометрии аналогичный `reference_geometry.json`.**

---

## Структура (Pydantic-like)

```json
{
  "version": "string",           // семантическая версия, напр. "1.0"
  "built_at": "ISO8601",          // когда построен
  "n_calibration_samples": int,  // число фото в калибровке

  "cohorts": {
    "real": {
      "description": "string",
      "n": int,
      "metrics": {
        "<metric_name>": {
          "mean": float,
          "std": float,
          "median": float,
          "p5": float,
          "p95": float,
          "n": int
        }
      }
    },
    "silicone": { ... }
  },

  "cohorts_by_epoch": {
    "recent": {
      "real": { "n": int, "metrics": {...} },
      "silicone": { "n": int, "metrics": {...} }
    },
    "legacy": {
      "real": { "n": int, "metrics": {...} },
      "silicone": { "n": int, "metrics": {...} }
    }
  },

  "noise_model_by_epoch": {
    "recent": {
      "q_noise_level_mean": float,
      "q_noise_level_std": float,
      "q_blur_level_mean": float,
      "q_blur_level_std": float,
      "q_overall_mean": float,
      "n": int
    },
    "legacy": { ... }
  },

  "noise_model_by_bucket": {
    "<bucket_name>": {
      "q_noise_level_mean": float,
      "q_noise_level_std": float,
      "q_blur_level_mean": float,
      "q_blur_level_std": float,
      "n": int
    }
  },

  "shift_model": {
    "hf_metrics": ["glcm_dissimilarity_d5_a0", ...],
    "robust_metrics": ["color_b_mean", ...],
    "quality_weights": {
      "q_overall": 0.40,
      "q_noise": 0.35,
      "q_blur": 0.25
    },
    "hf_discount_threshold": 0.6,
    "hf_zero_threshold": 0.4,
    "coefficients": {
      "<metric_name>": float  // Cohen's d как вес
    }
  },

  "top_metrics_by_auc": ["glcm_dissimilarity_d5_a0", ...],

  "buckets": ["frontal", "right_threequarter", ...],
  "epochs": ["recent", "legacy"]
}
```

---

## Поля

### `cohorts`

Для каждого класса (real/silicone) — статистики по метрикам:
- **mean, std** — MLE оценки по когорте
- **median, p5, p95** — робастные квантили (для асимметричных распределений)
- **n** — число валидных наблюдений (≥2 для вычисления std)

Ключ `metrics` содержит ВСЕ метрики, которые когда-либо были извлечены из
калибровочного датасета. Метрики с n < 2 или std < 1e-10 опускаются.

### `cohorts_by_epoch`

То же, но разбито по эпохам (recent/legacy). Epoch определяется по году:
- **legacy**: год < 2010
- **recent**: год ≥ 2010

Это нужно, чтобы различать плёночные сканы (шумные, низкое разрешение) от
современных цифровых фото (чистые, высокое разрешение).

### `noise_model_by_epoch`

Для каждой эпохи — параметры распределения качества:
- mean/std noise_level, blur_level, overall
- Это позволяет при вердикте знать "какое качество ожидаемо для этой эпохи"

### `noise_model_by_bucket`

Для каждого bucket — аналогичные параметры.
Используется для учёта систематического шума ракурса
(профильные фото размытее фронтальных и т.д.).

### `shift_model`

Параметры для Degradation-Aware Shift Verdict Model (quality_compensated_verdict.py):
- **hf_metrics** — высокочастотные метрики (чувствительны к шуму)
- **robust_metrics** — устойчивые метрики (нечувствительны к шуму)
- **quality_weights** — веса компонентов effective_quality
- **hf_discount_threshold** — ниже этого quality HF-метрики дисконтируются
- **hf_zero_threshold** — ниже этого quality HF-метрики = 0
- **coefficients** — вес каждой метрики в финальном shift_score

---

## Требования

1. **version** — строка, формат "MAJOR.MINOR". Минор меняется при добавлении метрик,
   мажор — при изменении схемы.
2. **n_calibration_samples** — сумма всех n по когортам real + silicone
3. Все статистики — float, nan не допускаются (если статистика не вычислена —
   ключ отсутствует, не nan)
4. Пустой `metrics` объект ({}) допускается, если когорта пуста

---

## Валидация

При загрузке `reference_texture.json` должен проходить следующие проверки:

```python
def validate_reference(ref: dict) -> list[str]:
    errors = []
    if ref["n_calibration_samples"] <= 0:
        errors.append("n_calibration_samples must be > 0")
    for cohort_name in ["real", "silicone"]:
        if cohort_name not in ref["cohorts"]:
            errors.append(f"Missing cohort: {cohort_name}")
        cohort = ref["cohorts"][cohort_name]
        if cohort["n"] <= 0:
            errors.append(f"Empty cohort: {cohort_name}")
    for epoch in ["recent", "legacy"]:
        if epoch not in ref.get("cohorts_by_epoch", {}):
            errors.append(f"Missing epoch: {epoch}")
    if not ref.get("shift_model", {}).get("coefficients"):
        errors.append("shift_model.coefficients is empty")
    return errors
```

---

## Пример значений

```json
{
  "version": "1.0",
  "built_at": "2026-07-07T01:30:00+00:00",
  "n_calibration_samples": 91,
  "cohorts": {
    "real": {
      "n": 50,
      "metrics": {
        "glcm_dissimilarity_d5_a0": {
          "mean": 1.827, "std": 0.198, "median": 1.79, "p5": 1.44, "p95": 2.23, "n": 48
        },
        "color_b_mean": {
          "mean": 94.65, "std": 10.14, "median": 93.1, "p5": 75.3, "p95": 115.4, "n": 50
        }
      }
    },
    "silicone": {
      "n": 41,
      "metrics": {
        "glcm_dissimilarity_d5_a0": {
          "mean": 1.323, "std": 0.189, "median": 1.28, "p5": 0.95, "p95": 1.70, "n": 39
        }
      }
    }
  },
  "shift_model": {
    "hf_metrics": ["glcm_dissimilarity_d5_a0", "lbp_uniform_r5_std"],
    "robust_metrics": ["color_b_mean", "contrast_michelson_mean", "hist_cv"],
    "quality_weights": {"q_overall": 0.40, "q_noise": 0.35, "q_blur": 0.25},
    "hf_discount_threshold": 0.6,
    "hf_zero_threshold": 0.4,
    "coefficients": {
      "glcm_dissimilarity_d5_a0": 2.60,
      "glcm_homogeneity_d5_a0": 2.53,
      "color_b_mean": 2.29
    }
  }
}
```